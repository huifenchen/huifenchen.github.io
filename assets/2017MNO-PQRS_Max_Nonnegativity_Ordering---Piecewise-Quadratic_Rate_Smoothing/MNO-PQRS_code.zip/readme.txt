
Written by Huifen Chen and Bruce Schmeiser, May 15, 2017.


The files MNOPQRS.for, MNOPQRS.c, and MNOPQRS.m are Fortran, C, and
MATLAB stand-alone source codes for the rate-fitting algorithm
MNOPQRS. Individual subprograms from these files could be used as
wished within applications, with inputs and outputs determined by the
user. Here we describe the identical input and output formats provided
by the driver programs in the three files.

The output echoes the input values of \lambda_1,..., \lambda_k, and
(depending upon the context) the provided end-point rates \lambda_0
and \lambda_{k+1}. These are followed by the results of PQRS, both the
computed coefficient values and the computed integrals.  Finally, the
results of MNO--PQRS are outputted, both the computed coefficient
values and the computed integrals. The computed Integrals are output
only to show that they match the provided \lambda values. The Matlab
code also graphs the resulting PQRS and MNO--PQRS rate functions.

Five example input files follow, one each for Contexts 0, 1, 2, 3,
and 4. Always, the first line contains only the number of intervals,
k. Always, the second line contains only the integral values
\lambda_1,...\lambda_k. Always, the third line contains only the
context number. For Contexts 1, 2, and 3, the fourth line contains one
or both end-point rates \lambda_0 and \lambda_{k+1}.

--------------------------

Input for Context 0:

13
68.6  126  140.2  139.4  125.2  115  126.8  140.2  140  119.4  100.6  70.4  70.2
0

--------------------------

Input for Context 1:

13
68.6  126  140.2  139.4  125.2  115  126.8  140.2  140  119.4  100.6  70.4  70.2
1
0 0 

--------------------------

Input for Context 2:

13
68.6  126  140.2  139.4  125.2  115  126.8  140.2  140  119.4  100.6  70.4  70.2
2
0 

--------------------------

Input for Context 3:

13
68.6  126  140.2  139.4  125.2  115  126.8  140.2  140  119.4  100.6  70.4  70.2
3
0 

--------------------------

Input for Context 4:

13
68.6  126  140.2  139.4  125.2  115  126.8  140.2  140  119.4  100.6  70.4  70.2
4



