#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int PQRSfit(int icontxt, int k, double* rates, double rate0, double ratekp1, 
            double** a, double** b, double** c);
int Mcell(int k, int irow, int jcolumn, double* cell);
int Scell(int n, int i, int j, double* cell);
int pqfit0(int k, double* rates, double** a, double** b);
int pqfit1(int k, double* rates, double rate0, double ratekp1,
           double** a, double** b);
int pqfit2(int k, double* rates, double rate0, double** a, double** b);
int pqfit3(int k, double* rates, double ratekp1, double** a, double** b);
int pqfit4(int k, double* rates, double** a, double** b);
int MNOfit(int icontxt, int k, double* rates, double rate0, double ratekp1, 
           double* a, double* b, double* c, double** aplus, double** bplus, 
           double** cplus);
int pqcase(int k, double* rates, double* a, double* b, double* c, 
           int** icase);
int MNOfit4(int icontxt, int k, double* rates, double rate0, double ratekp1, 
            int* icase, int i, double* a, double* b, double* c, double** aplus, 
            double** bplus, double** cplus);
int MNOfit2(int icontxt, int k, double* rates, double rate0, double ratekp1, 
            int* icase, int i, double* a, double* b, double* c, double** aplus, 
            double** bplus, double** cplus);
int MNOfit3(int icontxt, int k, double* rates, double rate0, double ratekp1, 
            int* icase, int i, double* a, double* b, double* c, double** aplus, 
            double** bplus, double** cplus);
int MNOfit1(int icontxt, int k, double* rates, double rate0, double ratekp1, 
            int* icase, int i, double* a, double* b, double* c, double** aplus, 
            double** bplus, double** cplus);
int MNOfit0(int icontxt, int k, double* rates, double rate0, double ratekp1, 
            int* icase, int i, double* a, double* b, double* c, double** aplus, 
            double** bplus, double** cplus);
int qmaxint(double a, double b, double c, double* qrate);
int qpartit(double a, double b, double c, double* alpha, double* beta, double* gamma);
double fmax(double a, double b);
double fmin(double a, double b);

int main(int argc, char* argv)
{
        /*
         Huifen Chen and Bruce Schmeiser, March 8, 2015.
         Driver Program: MNO-PQRS
         Max Nonnegativity Option---Piecewise-Quadratic Rate Smoothing
         Purpose:  Fit the nonnegative rate function   
         max{0, a_i x^2 + b_i x + c+i} to each interval, i=1,2,...,k.  
         Maintain the k means rates_i, end-point continuities,  
         end-point first derivatives, and maybe end rates.
        */
        int maxint = 10000;
        int k;
        int icontxt;
        int* time = NULL;
        double qrate;
        double rate0;
        double ratekp1;
        double* a = NULL;
        double* b = NULL;
        double* c = NULL;
        double* aplus = NULL;
        double* bplus = NULL;
        double* cplus = NULL;
        double* rates = NULL;
        double* t = NULL;
        double* y = NULL;
        double* yplus = NULL;

        int i; /*Var for for loop*/

        /*..get number of intervals*/
        printf("enter the number of intervals ( 1 to %d ).\n", maxint);
        scanf("%d",&k);

        /* ..get rate for each interval*/
        rates = (double*)malloc(sizeof(double)*k);
        printf("enter the %d nonnegative constant rates.\n", k);
        for (i = 0; i < k; i++){
            scanf("%lf",&rates[i]);
        }
        
        /*   ..get context information*/
        printf(" enter the context: 0,1,2,3, or 4.\n");
        printf("   0: cyclic.\n");
        printf("   1: finite horizon, two end-point rates specified.\n");
        printf("   2: finite horizon, left end-point rate specified\n");
        printf("   3: finite horizon, right end-point rate specified.\n");
        printf("   4: finite horizon, no end-point rate specified.\n");

        scanf("%d", &icontxt);

        rate0 = -1;
        ratekp1 = -1;
        if (icontxt == 1){
            printf(" enter the left and right end-point rates.\n");
            scanf("%lf", &rate0);
            scanf("%lf", &ratekp1);
        }else if(icontxt == 2){
            printf(" enter the left end-point rates.\n");
            scanf("%lf", &rate0);
        }else if(icontxt == 3){
            printf(" enter the right end-point rates.\n");
            scanf("%lf", &ratekp1);
        }
                
        /*..echo input*/
        printf("\n");
        printf(" Problem parameters...\n");
        printf("   interval i, rates(i)\n");
        for (i = 0; i < k; i++){
            printf("%d \t %lf.\n",i+1,rates[i]);
        }
        printf("   context   = %d \n",icontxt);
        printf("   end-point rates = %lf \t %lf\n",rate0,ratekp1);

        /*..compute and report the unconstrained fit*/
        PQRSfit(icontxt, k, rates, rate0, ratekp1, &a, &b, &c);
        printf("\n");
        printf(" PQRS fit (piecewise quadratic)...\n");
        printf("   i,\t a(i),\t b(i),\t c(i),\t qrate\n");
        for (i = 0; i < k; i++){
            qrate = (a[i]/3) + (b[i]/2) + c[i];
            printf("%d \t %lf \t %lf \t %lf \t %lf \t\n",i,a[i],b[i],c[i],qrate);
        }
        /*..compute and report the MNO "max" nonnegative fit*/
        MNOfit(icontxt, k, rates, rate0, ratekp1, a, b, c, &aplus, &bplus, &cplus);
        printf("\n");
        printf(" MNO fit (piecewise-quadratic nonnegative)...\n");
        printf("   i,\t a(i),\t b(i),\t c(i),\t integral\n");
        for (i = 0; i < k; i++){
            qmaxint(aplus[i], bplus[i], cplus[i], &qrate);
            printf("%d \t %lf \t %lf \t %lf \t %lf \t\n",i,aplus[i],bplus[i],cplus[i],qrate);
        }


        /*Release memory*/
        free(a);
        free(b);
        free(c);
        free(aplus);
        free(bplus);
        free(cplus);

        free(rates);
        free(time);

        return 0;
}


int PQRSfit(int icontxt, int k, double* rates, double rate0, double ratekp1, 
            double** a, double** b, double** c)
{
        /*
         Huifen Chen and Bruce Schmeiser, March 14, 2015.
         Call the appropriate unconstrained fitting routine.
         input: 
           icontxt = horizon type in {0,1,2,3,4}
           k       = number of intervals
           rates   = specified rates, i=1,...,k
           rate0   = left end-point rate
           ratekp1 = right end-point rate
         output:
           (a,b,c) = piecewise-quadratic coefficients
        */

        int i ;    /*var for for loop*/

        *a = (double*)malloc(sizeof(double)*k);
        *b = (double*)malloc(sizeof(double)*k);
        *c = (double*)malloc(sizeof(double)*k);

        if (icontxt == 0){
            /*   ..context 0: cyclic */
            pqfit0(k, rates, a, b);
        }else if (icontxt == 1){
            /*   ..context 1: finite horizon, two end point rates */
            pqfit1(k, rates, rate0, ratekp1, a, b);
        }else if (icontxt == 2){
            /*   ..context 2: finite horizon, only left end-point rate */
            pqfit2(k, rates, rate0, a, b);
        }else if (icontxt == 3){
            /*   ..context 3: finite horizon, only right end-point rate */
            pqfit3(k, rates, ratekp1, a, b);
        }else if (icontxt == 4){
            /*   ..context 4: finite horizon, no end-point rate*/
            pqfit4(k, rates, a, b);
        }
        
        /*..given (a, b), compute c*/
        for (i = 0; i < k; i++){
            (*c)[i] = rates[i] - ( (*a)[i]/3 ) - ( (*b)[i]/2 );
        }
        return 0;
}


int Mcell(int k, int irow, int jcolumn, double* cell)
{
         /*
          Huifen Chen and Bruce Schmeiser, March 14, 2015
          Compute (closed-form) the (irow, icolumn) cell of
            the cyclic-horizon (3k x 3k) M0 inverse. 
          input: 
            k = number of intervals, (k>1)
            (irow, jcolumn) = matrix-inverse indices
          output:
            cell = M0^{-1} (irow, jcolumn) 
        */

        int iindex;
        int jindex;
        int m;
        int khalf;
        int keven;

        double twopidk;
        double rj;
        double cosj;
        double factor;
        double rAj;
        double cosjm;
        double cosjmp1;

        int j;   /*var for for loop*/

        /*..get equivalent cell indices (iindex, jindex) from rows 1,2,3*/
        iindex = irow - 3*((irow-1)/3);
        jindex = jcolumn - (irow - iindex);
        if (jindex < 1){
            jindex = jindex + 3*k;
        }

        /* ..get block number m and column jindex (=1,2,3) within the block */
        m = (jindex - 1) / 3;
        jindex = jindex - 3*m;

        /* ..compute the value of M0 inverse's (irow, icolumn) cell*/
        twopidk = 6.2831853071796 / k;
        *cell  = 0;
        khalf = k / 2;
        keven = 0;
        if (k == 2*khalf){
            keven = 1;
        }
        for (j = 0; j <= khalf; j++){
            rj = j * twopidk;
            cosj = cos(rj);
            factor = -1.5 / (2 + cosj);
            if (iindex == 1){
                cosjm = cos( m * rj);
                if (jindex == 1) rAj =  4 * (1 - cosj)       * cosjm;
                if (jindex == 2) rAj =  2 * (cos( (m+1)*rj ) - cosjm);
                if (jindex == 3) rAj = -    (cos( (m+1)*rj ) + cosjm);
            }else if (iindex == 2){
                cosjmp1 = cos( (m+1)*rj);
                if (jindex == 1) rAj =  4 *   (cosjmp1 - cos( m*rj ));
                if (jindex == 2) rAj = -4 *    cosjmp1;
                if (jindex == 3) rAj =  2 * (2*cosjmp1 + cos( m*rj )) / 3;
            }else{
                cosjmp1 = cos( (m+1)*rj);
                if (jindex == 1) rAj = -2 * (  cosjmp1 + cos( m*rj ));
                if (jindex == 2) rAj =  2 * (2*cosjmp1 + cos( m*rj )) / 3;
                if (jindex == 3) rAj = -       cosjmp1                / 3;
            }
            if (j == 0 || (j == khalf && keven == 1)) rAj = rAj / 2;
            *cell = *cell + factor * rAj;
        }
        *cell = *cell / k;
        return 0;
}


int Scell(int n, int i, int j, double* cell)
{
        /*
         Huifen Chen and Bruce Schmeiser, March 14, 2015
         Purpose: compute the (i,j) cell of S^{-1}, where S is 
               the (3n x 3n) partitioned matrix with n blocks:
                    S = [S1 S2  0 0 ... 0   0]
                        [0  S1 S2 0 ... 0   0]
                         .                  .
                        [0 ...          0   S1] ,
               where each block matrix is 3x3 with
                      S1 = [1/3 1/2 1; 1 1  1; 2  1 0], 
                      S2 = [0   0   0; 0 0 -1; 0 -1 0], 
               and the other entries are 0.  
         input:
           n = number of blocks
           (i,j) = indices from S inverse
         output: 
           cell = the (i,j) cell of S inverse
        */

        int n3;
        double cell0;
        double denom1;
        
        double cell1;
        double cell2;
        double cell3j;
        double cell3n3;
        double rEinvij;
        double rEinvin3;
        double rEinv2j;
        double rEinv2n3;
        double denom2;

        n3 = 3 * n;

        /*..compute denominator */
        Mcell( n, 3, n3-1, &cell0);
        denom1 = 1 + cell0;

        /*..compute cell (i,j) of E inverse*/
        Mcell( n, i, j,    &cell1  );
        Mcell( n, i, n3-1, &cell2  );
        Mcell( n, 3, j,    &cell3j );
        rEinvij = cell1 - (cell2 * cell3j / denom1);

        /*..compute cell (i,n3) of E inverse*/
        Mcell( n, i, n3,        &cell1 );
        Mcell( n, 3, n3,        &cell3n3 );
        rEinvin3 = cell1 - (cell2 * cell3n3 / denom1);

        /*..compute cell (2,j) of E inverse*/
        Mcell( n, 2, j,    &cell1 );
        Mcell( n, 2, n3-1, &cell2 );
        rEinv2j = cell1 - (cell2 * cell3j / denom1);

        /*..compute cell (2,n3) of E inverse*/
        Mcell( n, 2, n3,   &cell1 );
        rEinv2n3 = cell1 - (cell2 * cell3n3 / denom1);

        /*..compute the (i,j) cell of S inverse*/
        denom2 = 1 + rEinv2n3;
        *cell = rEinvij - (rEinvin3 * rEinv2j / denom2);
        return 0;
}


int pqfit0(int k, double* rates, double** a, double** b)
{
        /*
         Huifen Chen and Bruce Schmeiser, March 14, 2105.
         PQRS Context: 0. Cyclic.
         Fit unconstrained rates; i.e., ignore negativity.
         Method:  Maintain k means, k continuity points, and
                  k first derivatives. Rows 1 and 2 of M0 inverse.
         input: 
                k     = number of intervals
                rates = specified rates, i=1,...,k
         output:
                (a,b) = second- and first-order quadratic coefficients
        */

        int jindex;
        int jrotate;
        double cell1j;
        double cell2j;

        int i,m; /*var for for loop*/

        /*..initialize */
        for (i = 0; i < k; i++){
            (*a)[i] = 0;
            (*b)[i] = 0;
        }

        /*..compute (a,b), block 0 to block k-1*/
        for (m = 0; m < k; m++){
            jindex = 3*m + 1;
            Mcell( k, 1, jindex, &cell1j );
            Mcell( k, 2, jindex, &cell2j );
            for (i = 1; i <= k; i++){
                 jrotate = m + i;
                 if (jrotate > k) jrotate = jrotate - k;
                 (*a)[i-1] = (*a)[i-1] + cell1j * rates[jrotate-1];
                 (*b)[i-1] = (*b)[i-1] + cell2j * rates[jrotate-1];
            }
        }
        return 0;
}


int pqfit1(int k, double* rates, double rate0, double ratekp1,
           double** a, double** b)
{
        /*
         Huifen Chen and Bruce Schmeiser, March 14, 2015.
         PQRS Context: 1. Finite horizon, two end-point rates.
         Fit unconstrained rates; i.e., ignore negativity.
         Method:  Maintain k means, k-1 continuity, k-1 first
                  derivatives, and two end-point rates. 
         input: 
           k     = number of intervals
           rates = specified rates, i=1,...,k
           rate0 = left end-point rate
           ratekp1 = right end-point rate
         output:
           (a,b) = second- and first-order quadratic coefficients  
        */

        int k3;
        int iindex;
        int jindex;
        double p;
        double q;
        double d1;
        double rMuli3;
        double rMuli4;
        double rMulij;
        double rMul3j;
        double celli3;
        double celli4;
        double rMuri0;
        double rMuri1;
        double rMurik;
        double ckm1;
        double ck;

        int i, ioffset, j; /*var for for loop*/

        if (k == 1){
           (*a)[0] = 3*(rate0 + ratekp1) - 6*rates[0];
           (*b)[0] = ratekp1 - rate0 - (*a)[0];
           return 1;
        }
        /*..initialize*/
        k3   = 3 * k ;

        /*..get constants p, q, and d1*/
        Scell( k-1, 3, k3-3, &p);
        Scell( k-1, 3, k3-4, &q);
        d1 = 4*p - q;

        /*..compute (ai,bi), i=1,..,k-1*/
        for (i = 0; i < k; i++){
            (*a)[i] = 0;
            (*b)[i] = 0;
        }
        for (i = 1; i < k; i++){
            for (ioffset = 0; ioffset <=1; ioffset++){
                iindex = 3*i - 2 + ioffset;
                Scell( k-1, iindex, k3-3, &rMuli3 );
                Scell( k-1, iindex, k3-4, &rMuli4 );
                for (j = 1; j < k; j++){
                    jindex = 3*j-2;
                    /*..G11, the upper-left corner of M1inv*/
                    Scell( k-1, iindex, jindex, &rMulij );
                    Scell( k-1, 3,      jindex, &rMul3j );
                    rMulij = rMulij - ((4*rMuli3 - rMuli4)*rMul3j) / d1;
                    if (ioffset == 0) (*a)[i-1] = (*a)[i-1] + rMulij * rates[j-1];
                    if (ioffset == 1) (*b)[i-1] = (*b)[i-1] + rMulij * rates[j-1];
                }
                /*..G12, the upper-right corner of M1inv*/
                Scell( k-1, iindex, k3-3, &celli3 );
                Scell( k-1, iindex, k3-4, &celli4 );
                rMuri0 =    (4*celli3 -   celli4) / d1;
                rMuri1 =  2*(q*celli3 - p*celli4) / d1;
                rMurik = -6*(q*celli3 - p*celli4) / d1;
                if (ioffset == 0){
                   (*a)[i-1] = (*a)[i-1] + rates[k-1] * rMurik;
                   (*a)[i-1] = (*a)[i-1] + rate0      * rMuri0;
                   (*a)[i-1] = (*a)[i-1] + ratekp1    * rMuri1;
                }else{
                   (*b)[i-1] = (*b)[i-1] + rates[k-1] * rMurik;
                   (*b)[i-1] = (*b)[i-1] + rate0      * rMuri0;
                   (*b)[i-1] = (*b)[i-1] + ratekp1    * rMuri1;
                }
            }
        }
        /*..compute (ak, bk)*/
        ckm1 = rates[(k-1)-1] - (*a)[(k-1)-1]/3 - (*b)[(k-1)-1]/2;
        ck   = (*a)[(k-1)-1] + (*b)[(k-1)-1] + ckm1;
        (*b)[k-1] = 2*(*a)[(k-1)-1] + (*b)[(k-1)-1];
        (*a)[k-1] = 3*(rates[k-1] - (*b)[k-1]/2 - ck);
        return 0;
}


int pqfit2(int k, double* rates, double rate0, double** a, double** b)
{
        /*
         Huifen Chen and Bruce Schmeiser, March 14, 2015.
         PQRS Context: 2. Finite horizon, only left end-point rate.
         Fit unconstrained rates; i.e., ignore negativity.
         Method:  Minimize sum_i=1^k a_i^2, subject to k means, 
                  k continuity, and k-1 first derivatives.
                  a(k) is the free variable.
         input: 
           k     = number of intervals
           rates = specified rates, i=1,...,k
           rate0 = left end-point rate
         output:
           (a,b) = second- and first-order quadratic coefficients
        */
        
        int k3;
        int iindex;
        int jindex;
        double bottom;
        double top;
        double p;
        double q;
        double d2;
        double celli3;
        double celli4;
        double cellij;
        double cell3j;
        double rMulij;
        double rMuri2;
        double rMuri1;
        double gammai;
        double ab;

        int i,j,ioffset ; /*var for for loop*/

        if (k == 1){
           (*a)[0] = 0;
           (*b)[0] = 2 * (rates[0] - rate0);
           return 1;
        }

        /*   ..initialize*/
        k3 = 3 * k;
        bottom = 0;
        top = 0;
        /*..use Q22, the lower-right (2x2) corner of sM2inv*/
        Scell(k-1, 3, k3-3, &p);
        Scell(k-1, 3, k3-4, &q);
        d2 = (q/2) - p;

        /*..begin computing bi, i=1,..,k-1, using rows 2,5,... of Q11*/
        for (i = 0; i < k; i++){
            (*b)[i] = 0;
        }
        for (i = 1; i <= (k-1); i++){
            iindex = 3*i - 1;
            Scell(k-1, iindex, k3-3, &celli3);
            Scell(k-1, iindex, k3-4, &celli4);
            for (j = 1; j <= (k-1); j++){
                jindex = 3*j - 2;
                Scell(k-1, iindex, jindex, &cellij);
                Scell(k-1,      3, jindex, &cell3j);
                rMulij = cellij + ( (celli3-celli4/2)*cell3j )/d2;
                (*b)[i-1] = (*b)[i-1] + rMulij * rates[j-1];
            }
        }

        /*
           ..begin computing ak using Q11, the upper-left corner of sM2inv
           ..begin computing ai, i=1,..,k-1, using rows 1, 4,... of Q11
        */
        for (i = 0; i < k; i++){
            (*a)[i] = 0;
        }
        for (i = 1; i <= (k-1); i++){
            iindex = 3*i - 2;
            Scell(k-1, iindex, k3-3, &celli3);
            Scell(k-1, iindex, k3-4, &celli4);
            rMuri2 = (q*celli3 - p*celli4  ) / d2;
            rMuri1 = ( -celli3 +   celli4/2) / d2;
            gammai = rMuri1 * rate0 + rMuri2 * rates[k-1];
            for (j = 1; j <= (k-1); j++){
                jindex = 3*j - 2;
                Scell(k-1, iindex, jindex, &cellij);
                Scell(k-1,      3, jindex, &cell3j); 
                rMulij = cellij + ((celli3 - celli4/2)*cell3j) / d2;
                (*a)[i-1] = (*a)[i-1] + rMulij * rates[j-1];
                gammai = gammai + rMulij * rates[j-1];
            }
            top    = top    + rMuri2 * gammai;
            bottom = bottom + pow(rMuri2,2);
        }

        /*..finish computing ak*/
        bottom = 3 + (bottom / 3);
        (*a)[k-1]   = top / bottom;
        /*..finish computing (ai, bi), i=1,...,k-1 using Q12*/
        for (i = 1; i <= (k-1); i++){
            for (ioffset = 0; ioffset <= 1; ioffset++){
                iindex = 3*i - 2 + ioffset;
                Scell(k-1, iindex, k3-3, &celli3);
                Scell(k-1, iindex, k3-4, &celli4);
                rMuri2 = (q*celli3 - p*celli4  ) / d2;
                rMuri1 = ( -celli3 +   celli4/2) / d2;
                ab = rMuri2 * (rates[k-1] - (*a)[k-1]/3) + rMuri1 * rate0;
                if (ioffset == 0) (*a)[i-1] = (*a)[i-1] + ab;   
                if (ioffset == 1) (*b)[i-1] = (*b)[i-1] + ab;   
            }
        }
        /*..compute bk*/
        (*b)[k-1] = 2*(*a)[(k-1)-1] + (*b)[(k-1)-1];
        return 0;
}


int pqfit3(int k, double* rates, double ratekp1, double** a, double** b)
{
        /*
         Huifen Chen and Bruce Schmeiser, March 14, 2015.
         PQRS Context: 3. Finite horizon, only right end-point rate.
         Fit unconstrained rates; i.e., ignore negativity.
         Method:  Time reverse Context 2.
         input: 
           k     = number of intervals
           rates = specified rates, i=1,...,k
           ratekp1 = right end-point rate
         output:
           (a,b) = second- and first-order quadratic coefficients
        */

        int khalf;
        double rate0;

        int i; /*var for for loop*/

        khalf = k/2;
        /*..reverse time for input rates*/
        rate0 = ratekp1;

        /*  (C Code Warning)
         This action will actually change the content of rates in upper layer,
         But we will undo this action after perform pqfit2 again
        */
        for (i = 1; i <= khalf; i++){
            double temp      = rates[(i)-1];
            rates[(i)-1]     = rates[(k-i+1)-1]    ;           
            rates[(k-i+1)-1] = temp;
        }

        /*..call context 2 fitting*/
        pqfit2(k, rates, rate0, a, b);

        /*
           ..convert coefficients to x from 1-x
             these coefficients are for interval k
        */
        for (i = 1; i <= k; i++){
            (*b)[i-1] = -2*(*a)[i-1] - (*b)[i-1];
        }
        /*..reverse time for the input rates and results*/
        for (i = 1; i <= khalf; i++){
            double temp     = rates[(i)-1];
            rates[(i)-1] = rates[(k-i+1)-1];
            rates[(k-i+1)-1] = temp;
            temp                = (*a)[(i)-1];
            (*a)[(i)-1] = (*a)[(k-i+1)-1];
            (*a)[(k-i+1)-1] = temp;
            temp     = (*b)[(i)-1];
            (*b)[(i)-1] = (*b)[(k-i+1)-1];
            (*b)[(k-i+1)-1] = temp;
        }
        return 0;
}


int pqfit4(int k, double* rates, double** a, double** b)
{
        /*
         Huifen Chen and Bruce Schmeiser, March 14, 2015.
         PQRS Context: 4. Finite horizon, no end-point rates.
         Fit unconstrained rates; i.e., ignore negativity.
         Method:  Minimize sum_i=1^k a_i^2, subject to k means, 
                  k-1 continuity, and k-1 1st derivatives.
                  a(1) and a(k) are the free variables.
         input: 
           k     = number of intervals
           rates = specified rates, i=1,...,k
         output:
           (a,b) = second- and first-order quadratic coefficients
        */
        
        int k3;
        int iindex;
        int jindex;
        double alpha;
        double beta;
        double phi;
        double eta;
        double xi;

        double w1;
        double w2;
        double w3;
        double w4;
        double d4;

        double rMlr55;
        double rMlr54;
        double rMlr53;
        double rMlr52;
        double rMlr45;
        double rMlr44;
        double rMlr43;
        double rMlr42;
        double rMlr35;
        double rMlr34;
        double rMlr33;
        double rMlr32;
        double rMlr25;
        double rMlr24;
        double rMlr23;
        double rMlr22;

        double celli6;
        double celli7;
        double rMuri5;
        double rMuri4;
        double rMuri3;
        double rMuri2;

        double p;
        double q;
        double r;

        double cellij;
        double cell2j;
        double cell3j;
        double rMulij;

        double denom;
        double factor2;
        double factor3;
        double factor4;
        double factor5;

        double rMll3j;
        double rMll5j;

        double ab;
        
        int i,j,ioffset; /*var for for loop*/

        if (k == 1){
           (*a)[0] = 0;
           (*b)[0] = 0;
           return 1;
        }else if (k == 2){
           (*a)[0] = 0;
           (*a)[1] = 0;
           (*b)[0] = rates[1] - rates[0];
           (*b)[1] = (*b)[0];
           return 2;
        }

        /*..k > 2, so initialize*/
        for (i = 0; i < k; i++){
           (*a)[i] = 0;
           (*b)[i] = 0;
        }

        k3 = 3*k;
        alpha = 1;
        beta = 0;
        phi = 0;
        eta = 1;
        xi = 0;

        /*..compute R22, the 4x4 lower-right corner of rM4inv*/
        Scell(k-2, 3, k3-6, &w1);
        Scell(k-2, 3, k3-7, &w2);
        Scell(k-2, 2, k3-6, &w3);
        Scell(k-2, 2, k3-7, &w4);
        d4 = w1 - w2/2 - w3/2 + w4/4;
        rMlr55 =  (-w2 + w4/2)            / d4;
        rMlr54 =   1                      / d4;
        rMlr53 =  -1                      / d4;
        rMlr52 =     0.5                  / d4;
        rMlr45 =  (w1 - w3/2)             / d4;
        rMlr44 =    -0.5                  / d4;
        rMlr43 =     0.5                  / d4;
        rMlr42 =    -0.25                 / d4;
        rMlr35 =  (w1*w4 - w2*w3)         / d4;
        rMlr34 =  (w3 - w4/2)             / d4;
        rMlr33 =  (-w3 + w4/2)            / d4;
        rMlr32 =  (w1 - w2/2)             / d4;
        rMlr25 =  ((w2*w3 - w1*w4)/2)     / d4;
        rMlr24 =  (w1 - w2/2 - w3 + w4/2) / d4;
        rMlr23 =  (w3/2 - w4/4)           / d4;
        rMlr22 =  (w2/4 - w1/2)           / d4;

        /*..compute a1 and ak*/
        for (i = 1; i <= (k-2); i++){
            iindex = 3*i - 2;
            /*..using R12, the upper-right-corner of rM4inv*/
            Scell(k-2, iindex, k3-6, &celli6);
            Scell(k-2, iindex, k3-7, &celli7);
            rMuri5 = rMlr55*celli6 + rMlr45*celli7;
            rMuri4 = rMlr54*celli6 + rMlr44*celli7;
            rMuri3 = rMlr53*celli6 + rMlr43*celli7;
            rMuri2 = rMlr52*celli6 + rMlr42*celli7;
            p = -rMuri4 / 3 - rMuri3 - 2*rMuri2;
            q = -rMuri5 / 3;
            r =  rMuri4 * rates[0] + rMuri5*rates[(k)-1];
            for (j = 2; j <= (k-1); j++){
                /*..using R11, the upper-left-corner of rM4inv*/
                jindex = 3*j - 5;
                Scell(k-2, iindex, jindex, &cellij);
                Scell(k-2,      2, jindex, &cell2j);
                Scell(k-2,      3, jindex, &cell3j);
                rMulij = cellij + ((2*celli6-celli7)*(cell2j-2*cell3j))/(4*d4);
                r = r + rMulij * rates[(j)-1];
            }
            alpha = alpha + pow(p,2);
            beta  = beta  + p*q;
            phi   = phi   + p*r;
            eta   = eta   + pow(q,2);
            xi    = xi    + q*r;
        }
        denom = pow(beta,2) - alpha*eta;
        (*a)[0]  = (eta*phi  - beta*xi ) / denom;
        (*a)[k-1]  = (alpha*xi - beta*phi) / denom;
        factor2 =                        - 2*(*a)[0];
        factor3 =                        -   (*a)[0];
        factor4 = rates[0]        -   (*a)[0]/3;
        factor5 = rates[k-1]-   (*a)[k-1]/3;
        /*
           ..compute b1 and bk using rows k3-3 and k3-5 of M4inv
           ....from R22, the lower-right corner of M4inv
        */
        (*b)[0]                =             rMlr32 * factor2 + rMlr33 * factor3;
        (*b)[0]                = (*b)[0]   + rMlr34 * factor4 + rMlr35 * factor5;
        (*b)[k-1]        =             rMlr52 * factor2 + rMlr53 * factor3;
        (*b)[k-1]        = (*b)[k-1] + rMlr54 * factor4 + rMlr55 * factor5;
        /*....from R21, the lower-left corner of M4inv*/
        for (j = 2; j <= (k-1); j++){
            jindex = 3*j - 5;
            Scell(k-2, 2, jindex, &cell2j);
            Scell(k-2, 3, jindex, &cell3j);
            rMll3j = rMlr33 * cell3j + rMlr32 * cell2j;
            rMll5j = rMlr53 * cell3j + rMlr52 * cell2j;
            (*b)[0]                = (*b)[0]        + rMll3j * rates[(j)-1];
            (*b)[k-1]        = (*b)[k-1] + rMll5j * rates[(j)-1];   
        }
        /*..compute (ai,bi), i=2,...,k-1*/
        for (i = 2; i <= (k-1); i++){
            for (ioffset = 0; ioffset <= 1; ioffset++){
                iindex = i*3 - 5 + ioffset;
                Scell(k-2, iindex, k3-6, &celli6);
                Scell(k-2, iindex, k3-7, &celli7);
                /*....use R12, the upper-right corner of M4inv*/
                rMuri5 = celli6*rMlr55 + celli7*rMlr45;
                rMuri4 = celli6*rMlr54 + celli7*rMlr44;
                rMuri3 = celli6*rMlr53 + celli7*rMlr43;
                rMuri2 = celli6*rMlr52 + celli7*rMlr42;
                ab=rMuri5*factor5+rMuri4*factor4+rMuri3*factor3+rMuri2*factor2;
                if (ioffset == 0) (*a)[(i)-1] = ab; 
                if (ioffset == 1) (*b)[(i)-1] = ab; 
                /*....use R11, the upper-left corner of M4inv*/
                for (j = 2; j <= (k-1); j++){
                    jindex = 3*j - 5;
                    Scell(k-2, iindex, jindex, &cellij);
                    Scell(k-2,      2, jindex, &cell2j);
                    Scell(k-2,      3, jindex, &cell3j);
                    rMulij = cellij+((2*celli6-celli7)*(cell2j-2*cell3j))/(4*d4);
                    if (ioffset == 0) (*a)[(i)-1] = (*a)[(i)-1] + rMulij * rates[(j)-1];
                    if (ioffset == 1) (*b)[(i)-1] = (*b)[(i)-1] + rMulij * rates[(j)-1];
                }
            }
        }
        return 0;
}


int MNOfit(int icontxt, int k, double* rates, double rate0, double ratekp1, 
           double* a, double* b, double* c, double** aplus, double** bplus, 
           double** cplus)
{
        /*
         Fen Chen and Bruce Schmeiser, Feb 14, 2015.
         For each interval, modify the quadratic ax^2+bx+c to
         max{0, aplus x^2 + bplus x + cplus}, so then no negative rate.
         input:
           icontxt = context \in {0,1,2,3,4}
           k = number of intervals
           rates = specified rates, i=1,...,k
           rate0, ratekp1 = time-zero and time-k specified rates
           (a,b,c) = PQRS quadratic coefficients
         output:
           (aplus, bplus, cplus) = updated quadratic coefficients    
        */
        double epsilon = 1e-10;

        int* icase;
                           
        int i ; /*var for for loop*/

        /*   ..set default values*/
        *aplus = (double*)malloc(sizeof(double)*k);
        *bplus = (double*)malloc(sizeof(double)*k);
        *cplus = (double*)malloc(sizeof(double)*k);
        for (i = 0; i < k; i++){
                (*aplus)[i] = a[i];
                (*bplus)[i] = b[i];
                (*cplus)[i] = c[i];
        }
        /*..determine the initial negativity case for each interval*/
        pqcase(k, rates, a, b, c, &icase);
        /*..MNO update in specific case order*/
        for (i = 1; i <= k; i++){
            MNOfit4(icontxt, k, rates, rate0, ratekp1, icase, i, a, b, c, 
                    aplus, bplus, cplus);
        }
        for (i = 1; i <= k; i++){
            MNOfit3(icontxt, k, rates, rate0, ratekp1, icase, i, a, b, c, 
                    aplus, bplus, cplus);
        }
        for (i = 1; i <= k; i++){
            MNOfit2(icontxt, k, rates, rate0, ratekp1, icase, i, a, b, c, 
                    aplus, bplus, cplus);
        }
        for (i = 1; i <= k; i++){
            MNOfit1(icontxt, k, rates, rate0, ratekp1, icase, i, a, b, c, 
                    aplus, bplus, cplus);
        }
        MNOfit0(icontxt, k, rates, rate0, ratekp1, icase, 1, a, b, c, 
                aplus, bplus, cplus);
        MNOfit0(icontxt, k, rates, rate0, ratekp1, icase, k, a, b, c, 
                aplus, bplus, cplus);
        /*..override with zero-rate values*/
        for (i = 1; i <= k; i++){
            if (rates[i-1] < epsilon){
                    (*aplus)[i-1] = 0;
                    (*bplus)[i-1] = 0;
                    (*cplus)[i-1] = 0;
            }
        }

        free(icase);
        return 0;
}


int pqcase(int k, double* rates, double* a, double* b, double* c, int** icase)
{
        /*
         Fen Chen and Bruce Schmeiser, Feb 14, 2015.
         For each interval, determine the negativity case.
         input:
           k = number of intervals
           rates = specified rates, i=1,...,k
           (a,b,c) = PQRS quadratic coefficients
         output:
           icase = the negativity case for i=1,...,k
        */

        double q0;
        double q1;
        double qmin;
        double xstar;

        int i ; /*var for for loop*/

        *icase = (int*)malloc(sizeof(int)*k);

        for (i = 1; i <= k; i++){
            /*..compute qmin = min{ ax^2 + bx + c : x \in [0,1] }*/
            q0 = c[i-1];
            q1 = a[i-1] + b[i-1] + c[i-1];
            qmin = fmin(q0,q1);
            if (a[i-1] > 0){
                xstar = -b[i-1] / (2*a[i-1]);
                if (xstar > 0 && xstar < 1){
                    qmin = c[i-1] - (pow(b[i-1],2) / (4*a[i-1]));
                }
            }
            /*..compute negativity cases*/
            (*icase)[i-1] = 0;
            if (qmin < 0){ 
                if (q0 >= 0 && q1 >= 0){
                    (*icase)[i-1] = 4;
                }else if (q0 >= 0 && q1 < 0){
                    (*icase)[i-1] = 3;
                }else if (q0 < 0 && q1 >= 0){
                    (*icase)[i-1] = 2;
                }else{
                    (*icase)[i-1] = 1;        
                }
            }
        }
        return 0;
}


int MNOfit4(int icontxt, int k, double* rates, double rate0, double ratekp1, 
            int* icase, int i, double* a, double* b, double* c, double** aplus, 
            double** bplus, double** cplus)
{
        /*
         Fen Chen and Bruce Schmeiser, Feb 14, 2015
         MNO update: max{ 0, aplus x^2 + bplus x + cplus }
                     Case 4---negative rates; 2 nonnegative end-point rates
         input:
            icontxt = context \in {0,1,2,3,4}
            k = number of intervals
            rates = specified rates, i=1,...,k
            rate0, ratekp1 = time-zero and time-k specified rates
            icase = negativity case {0,1,2,3,4}
            (a,b,c) = PQRS quadratic coefficients
         output:
            (aplus, bplus, cplus) = MNO quadratic coefficients 
        */

        double epsilon = 1e-10;

        double qrate;
        double q0;
        double q1;
        double aold;
        double bold;
        double qintold;
        double a2;
        double qintnew;
                           
        if (icase[i-1] == 4)
        {
            qrate = rates[i-1];
            q0    = c[i-1];
            q1    = a[i-1] + b[i-1] + c[i-1];
            (*cplus)[i-1] = c[i-1];

            /*..use secant method.*/
            aold = a[i-1];
            bold = q1 - (*cplus)[i-1] - aold;
            qmaxint(aold, bold, q0, &qintold);
            a2 = a[i-1] + 0.10*fabs(a[i-1]); /*aplus > a, always*/
            qintnew = qrate + 10*epsilon + 1; /*always 1st-time failure*/
            while(fabs(qintnew - qrate) > epsilon){
                (*aplus)[i-1] = a2;
                (*bplus)[i-1] = q1 - q0 - (*aplus)[i-1];
                qmaxint((*aplus)[i-1], (*bplus)[i-1], q0, &qintnew);
                if (qintnew != qintold){
                    a2 = (*aplus)[i-1] - ((*aplus)[i-1]-aold)*(qintnew-qrate)/(qintnew-qintold);
                    aold = (*aplus)[i-1];
                    qintold = qintnew;
                }else{
                        qintnew = qrate;
                }
            }
        }
        return 0;
}


int MNOfit2(int icontxt, int k, double* rates, double rate0, double ratekp1, int* icase, int i, 
            double* a, double* b, double* c, double** aplus, double** bplus, double** cplus)
{

        /*
         Fen Chen and Bruce Schmeiser, Feb 14, 2015
         MNO update: max{ 0, aplus x^2 + bplus x + cplus }
                     Case 2---negative rates; only right nonnegative end-point rate
         input:
            icontxt = context \in {0,1,2,3,4}
            k = number of intervals
            rates = specified rates, i=1,...,k
            rate0, ratekp1 = time-zero and time-k specified rates
            icase = negativity case {0,1,2,3,4}
            (a,b,c) = PQRS quadratic coefficients
         output:
            (aplus, bplus, cplus) = MNO quadratic coefficients
        */

        int inext;
        double qrate;
        double q1;
        double q1p;
        double term1;
        double term2;

        if (icase[i-1] == 2){
            qrate = rates[i-1];
            q1 = a[i-1] + b[i-1] + c[i-1];

            /*..if there is a next interval, use it for q1p*/
            if (icontxt > 0 && i == k){
                q1p = 2*a[i-1] + b[i-1];
            }else{
                if (i < k){
                    inext = i + 1;
                }else if (icontxt == 0){
                    inext = 1;
                }
                q1p = (*bplus)[inext-1];
            }

            /*..case 2 is closed form. */
            term1 = -q1 * (4*pow(q1,2) - 9*q1p*qrate);
            term2 = 2*pow((2*pow(q1,2) - 3*q1p*qrate),3);
            (*aplus)[i-1]  = (term1 - sqrt( term2 ) ) / (18*pow(qrate,2))   ;       
            (*bplus)[i-1]  = q1p - 2*(*aplus)[i-1];
            (*cplus)[i-1]  = q1 - q1p + (*aplus)[i-1];
        }
        return 0;
}


int MNOfit3(int icontxt, int k, double* rates, double rate0, double ratekp1, int* icase, int i, 
            double* a, double* b, double* c, double** aplus, double** bplus, double** cplus)
{
        /*
         Fen Chen and Bruce Schmeiser, Feb 14, 2015
         MNO update: max{ 0, aplus x^2 + bplus x + cplus }
                     Case 3---negative rates; only left nonnegative end-point rate
         input:
            icontxt = context \in {0,1,2,3,4}
            k = number of intervals
            rates = specified rates, i=1,...,k
            rate0, ratekp1 = time-zero and time-k specified rates
            icase = negativity case {0,1,2,3,4}
            (a,b,c) = PQRS quadratic coefficients
         output:
            (aplus, bplus, cplus) = MNO quadratic coefficients 
        */

        int iprev;
        double qrate;
        double q0;
        double q0p;
        double term1;
        double term2;

        if (icase[i-1] == 3){
            qrate = rates[i-1];
            q0 = c[i-1];

            /*..if there is a previous interval, use it for q0p*/
            if (icontxt > 0 && i == 1){
                q0p = b[i-1];
            }else{
                if (i > 1){
                        iprev = i - 1;
                }else if (icontxt == 0){
                        iprev = k;
                }
                q0p = 2 * (*aplus)[iprev-1] + (*bplus)[iprev-1];
            }

            /*..case 3 is closed form. */
            term1 = -q0 * (4*pow(q0,2) + 9*q0p*qrate);
            term2 = 2*pow((2*pow(q0,2) + 3*q0p*qrate),3);
            (*aplus)[i-1] = (term1 - sqrt( term2 ) ) / (18*pow(qrate,2))   ;       
            (*bplus)[i-1] = q0p;
            (*cplus)[i-1] = c[i-1];
        }
        return 0;
}


int MNOfit1(int icontxt, int k, double* rates, double rate0, double ratekp1, int* icase, int i, 
            double* a, double* b, double* c, double** aplus, double** bplus, double** cplus)
{
        /*
         Fen Chen and Bruce Schmeiser, Feb 14, 2015
         MNO update: max{ 0, aplus x^2 + bplus x + cplus }
                     Case 1---negative rates; no nonnegative end-point rate
         input:
            icontxt = context \in {0,1,2,3,4}
            k = number of intervals
            rates = specified rates, i=1,...,k
            rate0, ratekp1 = time-zero and time-k specified rates
            icase = negativity case {0,1,2,3,4}
            (a,b,c) = PQRS quadratic coefficients
         output:
            (aplus, bplus, cplus) = MNO quadratic coefficients  
        */

        double epsilon = 1e-10;

        double qrate;
        double q0;
        double q1;
        double aold;
        double bold;
        double qintold;
        double a2;
        double qintnew;
                           
        if (icase[i-1] == 1){
            qrate = rates[i-1];
            q0    = c[i-1];
            q1    = a[i-1] + b[i-1] + c[i-1];
            (*cplus)[i-1] = c[i-1];

            /*..use secant method.*/
            aold = a[i-1];
            bold = q1 - (*cplus)[i-1] - aold;
            qmaxint(aold, bold, q0, &qintold);
            a2 = a[i-1] + 0.10*fabs(a[i-1]);     /* aplus > a, always */

            /* for the future:a < aplus < (q0 + q1) - 2sqrt(q0q1) < 0 */
            qintnew = qrate + 10*epsilon + 1;    /* always 1st-time failure */
            while(fabs(qintnew - qrate) > epsilon){
                  (*aplus)[i-1] = a2;
                  (*bplus)[i-1] = q1 - q0 - (*aplus)[i-1];
                  qmaxint((*aplus)[i-1], (*bplus)[i-1], q0, &qintnew);
                  if (qintnew != qintold){
                      a2 = (*aplus)[i-1] - ((*aplus)[i-1]-aold)*(qintnew-qrate)/(qintnew-qintold);
                      aold = (*aplus)[i-1];
                      qintold = qintnew;
                  }else{
                      qintnew = qrate;
                  }
            }
        }
        return 0;
}


int MNOfit0(int icontxt, int k, double* rates, double rate0, double ratekp1, int* icase, int i, 
            double* a, double* b, double* c, double** aplus, double** bplus, double** cplus)
{
        /*
         Fen Chen and Bruce Schmeiser, Feb 14, 2015
         MNO update: max{ 0, aplus x^2 + bplus x + cplus }
                     Case 0---no negative rates; finite horizon, context 2, 3, 4
                              interval {1,k} adjacent to an updated case-4 interval
         input:
            icontxt = context \in {0,1,2,3,4}
            k = number of intervals
            rates = specified rates, i=1,...,k
            rate0, ratekp1 = time-zero and time-k specified rates
            icase = negativity case {0,1,2,3,4}
            (a,b,c) = PQRS quadratic coefficients
         output:
            (aplus, bplus, cplus) = MNO quadratic coefficients
        */

        double qrate;
        double q1;
        double q1p;
        double q0;
        double q0p;

        if (i == 1){
            if (icontxt == 4 || icontxt == 3){
                /*..first interval  */
                if (icase[0] == 0 && icase[1] == 4){
                    qrate = rates[0];
                    q1  = (*cplus)[1];
                    q1p = (*bplus)[1];
                    (*cplus)[0] = 3*qrate -2*q1 + q1p/2;
                    (*bplus)[0] = 2*(q1 - (*cplus)[0]) - q1p;
                    (*aplus)[0] = (q1p - (*bplus)[0]) / 2;
                    pqcase( k, rates, *aplus, *bplus, *cplus, &icase ); 

                    /*..re-update if interval 1's case changed*/
                    i = 1;
                    if (icase[0] == 2){
                        MNOfit2(icontxt, k, rates, rate0, ratekp1, icase, i, a, b, c, 
                                aplus, bplus, cplus);
                    }else if (icase[0] == 4){
                        MNOfit4(icontxt, k, rates, rate0, ratekp1, icase, i, a, b, c, 
                                aplus, bplus, cplus);
                    }
                }
            }
        }else if (i == k){
            if (icontxt == 4 || icontxt == 2){
                /*..last interval*/
                if (icase[k-1] == 0 && icase[(k-1)-1] == 4){
                    qrate = rates[k-1];
                    q0    = (*cplus)[k-1];
                    q0p   = 2*(*aplus)[(k-1)-1] + (*bplus)[(k-1)-1];
                    (*cplus)[k-1] = q0;
                    (*bplus)[k-1] = q0p;
                    (*aplus)[k-1] = 3*(qrate - (*bplus)[k-1]/2 - (*cplus)[k-1]);
                    pqcase( k, rates, *aplus, *bplus, *cplus, &icase ); /*Warning: Overwrite current icase*/
                    if (icase[k-1] == 3){
                        MNOfit3(icontxt, k, rates, rate0, ratekp1, icase, i, a, b, c, aplus, bplus, cplus);
                    }else if (icase[k-1] == 4){
                        MNOfit4(icontxt, k, rates, rate0, ratekp1, icase, i, a, b, c, aplus, bplus, cplus);
                    }
                }
            }
        }
        return 0;
}


int qmaxint(double a, double b, double c, double* qrate)
{
        /*
         Huifen Chen and Bruce Schmeiser. Feb 7, 2015
         purpose: integrate max{ 0, a x^2 + b x + c } over [0,1].
                   Known to be positive only on (alpha, beta) and (gamma, 1).
         input:
            a, b, c = quadratic coeffients
         output:
            qrate = integral value
        */

        double alpha;
        double beta;
        double gamma;

        qpartit(a, b, c, &alpha, &beta, &gamma);
        *qrate =    (a/3) * ( (pow(beta,3) - pow(alpha,3)) + (1 - pow(gamma,3)) ) 
              + (b/2) * ( (pow(beta,2) - pow(alpha,2)) + (1 - pow(gamma,2)) ) 
              +  c    * ( (beta   - alpha  ) + (1 - gamma  ) );
        return 0;
}


int qpartit(double a, double b, double c, double* alpha, double* beta, double* gamma)
{
        /*
         Huifen Chen and Bruce Schmeiser.  March 1, 2014
         purpose: Over [0,1], partition q(x) = ax^2 + bx + c 
                  into negative and non-negative intervals.
         input: a, b, c
         output: 
                (alpha, beta, gamma) = the sign-change points in [0,1].   
                  Always    q(0,    alpha) <  0.
                            q[alpha, beta] >= 0.
                            q(beta, gamma) <  0.
                            q[gamma,    1] >= 0.
                  The three values are not unique; we use
                  alpha = 0 when a > 0 and gamma = 1 when a < 0.
        */

        double root;
        double char_tmp;
        double schar_tmp;
        double root1;
        double root2;

        *alpha = 0;
        *beta = 0;
        *gamma = 1;
        if (a == 0){
            if (b == 0){
                if (c >= 0) *beta = 1;
            }else{
                root = -c/b;
                if (b < 0){
                    *beta = fmax(0.0, fmin(1.0, root));
                }else{
                    *gamma = fmax(0.0, fmin(1.0, root));
                }
            }
        }else{
            char_tmp  = pow(b,2) - 4*a*c;
            if (char_tmp < 0){
                if (a >= 0) *beta = 1;
            }else{
                schar_tmp = sqrt(char_tmp);
                root1 = (- b - schar_tmp) / (2*a)   ;  
                root2 = (- b + schar_tmp) / (2*a)   ;  
                *beta = fmax(0.0, fmin(1.0, root1));
                if (a < 0){
                    *alpha = fmax(0.0, fmin(1.0, root2));
                }else{
                    *gamma = fmax(0.0, fmin(1.0, root2));
                }
            }
        }
        return 0;
}


double fmax(double a, double b)
{
       /* Purpose: finding the maximan of a and b */ 
       if (a > b){
           return a;
       }else{
           return b;
       }
}

double fmin(double a, double b)
{
       /* Purpose: finding the minimum of a and b */ 
       if (a < b){
           return a;
       }else{
           return b;
       }
}

