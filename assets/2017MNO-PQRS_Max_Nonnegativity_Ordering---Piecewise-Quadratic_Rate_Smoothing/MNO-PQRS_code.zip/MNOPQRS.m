function varargout = mnopqrs
    %   Huifen Chen and Bruce Schmeiser, March 8, 2015.
    %   Driver Program: MNO-PQRS
    %   Max Nonnegativity Option---Piecewise-Quadratic Rate Smoothing
    %   Purpose:  Fit the nonnegative rate function   
    %   max{0, a_i x^2 + b_i x + c+i} to each interval, i=1,2,...,k.  
    %   Maintain the k means rates_i, end-point continuities,  
    %   end-point first derivatives, and maybe end rates.

    maxint = 10000;
    a = 0;
    b = 0;
    c = 0;
    aplus = 0;
    bplus = 0;
    cplus = 0;
    
    % Create file pointer
    infile = fopen('input.txt','r');
    outfile = fopen('output.txt','wt');
    %   ..get number of intervals
    fprintf(outfile,[' enter the number of intervals (1 to ' num2str(maxint) ').\n']);
    k = fscanf(infile, '%d',1);
    
    %   ..get rate for each interval
    rates = zeros(1,k); %(Initialization)
    fprintf(outfile,[' enter the ' num2str(k) ' nonnegative constant rates.\n']);
    for i = 1 : k
        rates(i) = fscanf(infile, '%lf',1);
    end
    %   ..get context information
    fprintf(outfile,' enter the context: 0,1,2,3, or 4.\n');
    fprintf(outfile,'   0: cyclic.\n');
    fprintf(outfile,'   1: finite horizon, two end-point rates specified.\n');
    fprintf(outfile,'   2: finite horizon, left end-point rate specified\n');
    fprintf(outfile,'   3: finite horizon, right end-point rate specified.\n');
    fprintf(outfile,'   4: finite horizon, no end-point rate specified.\n');
    
    icontxt = fscanf(infile, '%d',1);
    
    rate0 = -1;
    ratekp1 = -1;
    if icontxt == 1
        fprintf(outfile,' enter the left and right end-point rates.\n');
        rate0 = fscanf(infile, '%lf',1);
        ratekp1 = fscanf(infile, '%lf',1);
    elseif icontxt == 2
        fprintf(outfile,' enter the left end-point rates.\n');
        rate0 = fscanf(infile, '%lf',1);
    elseif icontxt == 3
        fprintf(outfile,' enter the right end-point rates.\n');
        ratekp1 = fscanf(infile, '%lf',1);
    end
    %   ..echo input
    fprintf(outfile,'\n');
    fprintf(outfile,' Problem parameters...\n');
    fprintf(outfile,'   interval i, rates(i)\n');
    for i = 1 : k
        fprintf(outfile,[ num2str(i) '     ' num2str(rates(i)) '.\n']);
    end
    fprintf(outfile,['   context   = ' num2str(icontxt) '\n']);
    fprintf(outfile,['   end-point rates = ' num2str(rate0) '     ' num2str(ratekp1) '\n']);
    %   ..compute and report the unconstrained fit
    [a,b,c] = PQRSfit(icontxt, k , rates, rate0, ratekp1, [], [], []);
    fprintf(outfile,'\n');
    fprintf(outfile,' PQRS fit (piecewise quadratic)...\n');
    fprintf(outfile,'   i, a(i), b(i), c(i), qrate\n');
    for i = 1 : k
        qrate = (a(i)/3) + (b(i)/2) + c(i);
        fprintf(outfile,[num2str(i,16) ' ' num2str(a(i),16) ' ' num2str(b(i),16) ' ' num2str(c(i),16) ' ' num2str(qrate) '\n']);
    end
    %   ..compute and report the MNO "max" nonnegative fit
    [aplus, bplus, cplus] = MNOfit( icontxt, k, rates, rate0, ratekp1, ... 
                            a, b, c, [], [], [] );
    fprintf(outfile,'\n');
    fprintf(outfile,' MNO fit (piecewise-quadratic nonnegative)...\n');
    fprintf(outfile,'   i, aplus(i), bplus(i), cplus(i), integral\n');
    for i = 1 : k
        qrate = qmaxint( aplus(i), bplus(i), cplus(i), [] );
        fprintf(outfile,[num2str(i,16) ' ' num2str(aplus(i),16) ' ' num2str(bplus(i),16) ' ' num2str(cplus(i),16) ' ' num2str(qrate) '\n']);
    end
    
    time = 0 : k;
    t = time(1):0.01:time(k+1);
    y = Q(k,a,b,c,t);
    yplus = Q2(k,aplus,bplus,cplus,t);
    figure
    hold all
    h1 = plot(t,y,'--','Color','blue','LineWidth',1.3);
    h2 = plot(t,yplus,'Color','red','LineWidth',1.3);
    xlabel('time t');
    ylabel('rate');
    xlim([0 k]);
%    ylim([-20 140]);
    SameAsPQRS = 1;
    for j = 1 : length(a)
        if (a(j) ~= aplus(j)) || (b(j) ~= bplus(j)) || (c(j) ~= cplus(j))
            SameAsPQRS = 0;  % MNO and PQRS are different 
            break;
        end
    end
    if SameAsPQRS == 1
        legend([h2],'PQRS  (= MNO--PQRS)');
%        legend([h1 h2],'PQRS  (= MNO--PQRS)','MNO--PQRS');
    else
        legend([h1 h2], 'PQRS','MNO--PQRS');
    end    
    
    fclose(outfile);
    fclose(infile);
    return
end

function [a, b, c] = PQRSfit( icontxt, k, rates, rate0, ratekp1, a, b, c )
    %   Huifen Chen and Bruce Schmeiser, March 14, 2015.
    %   Call the appropriate unconstrained fitting routine.
    %   input: 
    %    icontxt = horizon type in {0,1,2,3,4}
    %    k       = number of intervals
    %    rates   = specified rates, i=1,...,k
    %    rate0   = left end-point rate
    %    ratekp1 = right end-point rate
    %   output:
    %    (a,b,c) = piecewise-quadratic coefficients
    if icontxt == 0
        %   ..context 0: cyclic
        [a,b] = pqfit0( k, rates, [], [] );
    elseif icontxt == 1
        %   ..context 1: finite horizon, two end point rates
        [a,b] = pqfit1( k, rates, rate0, ratekp1, [], [] );
    elseif icontxt == 2
        %   ..context 2: finite horizon, only left end-point rate
        [a,b] = pqfit2( k, rates, rate0, [], [] );
    elseif icontxt == 3
        %   ..context 3: finite horizon, only right end-point rate
        [a,b] = pqfit3( k, rates, ratekp1, [], [] );
    elseif icontxt == 4
        %   ..context 4: finite horizon, no end-point rate
        [a,b] = pqfit4( k, rates, [], [] );
    end
    %   ..given (a, b), compute c
    for i = 1 : k
        c(i) = rates(i) - ( a(i)/3 ) - ( b(i)/2 );
    end
end

function cell = Mcell( k, irow, jcolumn, cell )
    %      Huifen Chen and Bruce Schmeiser, March 14, 2015
    %      Compute (closed-form) the (irow, icolumn) cell of
    %        the cyclic-horizon (3k x 3k) M0 inverse. 
    %      input: 
    %        k = number of intervals, (k>1)
    %        (irow, jcolumn) = matrix-inverse indices
    %      output:
    %        cell = M0^{-1} (irow, jcolumn) 
    
    %   ..get equivalent cell indices (iindex, jindex) from rows 1,2,3
    iindex = irow - 3*(floor((irow-1)/3));
    jindex = jcolumn - (irow - iindex);
    if jindex < 1
        jindex = jindex + 3*k;
    end
    %   ..get block number m and column jindex (=1,2,3) within the block
    m = floor((jindex - 1) / 3);
    jindex = jindex - 3*m;
    %   ..compute the value of M0 inverse's (irow, icolumn) cell
    twopidk = 6.2831853071796d0 / k;
    cell  = 0;
    khalf = floor(k / 2);
    keven = 0;
    if k == 2*khalf
        keven = 1;
    end
    for j = 0 : khalf
        rj     = j * twopidk;
        cosj   = cos( rj );
        factor = -1.5d0 / (2 + cosj);
        if iindex == 1
            cosjm   = cos( m*rj );
            if (jindex == 1)  rAj =  4 * (1 - cosj)       * cosjm;  end
            if (jindex == 2)  rAj =  2 * (cos( (m+1)*rj ) - cosjm); end
            if (jindex == 3)  rAj = -    (cos( (m+1)*rj ) + cosjm); end
        elseif iindex == 2
            cosjmp1 = cos( (m+1)*rj );
            if (jindex == 1) rAj =  4 *   (cosjmp1 - cos( m*rj ));      end
            if (jindex == 2) rAj = -4 *    cosjmp1;                     end
            if (jindex == 3) rAj =  2 * (2*cosjmp1 + cos( m*rj )) / 3;  end
        else
            cosjmp1 = cos( (m+1)*rj );
            if (jindex == 1) rAj = -2 * (  cosjmp1 + cos( m*rj ));      end
            if (jindex == 2) rAj =  2 * (2*cosjmp1 + cos( m*rj )) / 3;  end
            if (jindex == 3) rAj = -       cosjmp1                / 3;  end
        end
        if (j == 0 || ( j == khalf && keven == 1))  rAj = rAj / 2; end
        cell = cell + factor * rAj;
    end
    cell = cell / k;
    return
end

function cell = Scell( n, i, j, cell )
    %      Huifen Chen and Bruce Schmeiser, March 14, 2015
    %      Purpose: compute the (i,j) cell of S^{-1}, where S is 
    %           the (3n x 3n) partitioned matrix with n blocks:
    %                S = [S1 S2  0 0 ... 0   0]
    %                    [0  S1 S2 0 ... 0   0]
    %                     .                  .
    %                    [0 ...          0   S1] ,
    %           where each block matrix is 3x3 with
    %                  S1 = [1/3 1/2 1; 1 1  1; 2  1 0], 
    %                  S2 = [0   0   0; 0 0 -1; 0 -1 0], 
    %           and the other entries are 0.  
    %      input:
    %        n = number of blocks
    %        (i,j) = indices from S inverse
    %      output: 
    %        cell = the (i,j) cell of S inverse
    
    n3 = 3 * n;
    %   ..compute denominator
    cell0 = Mcell( n, 3 ,n3-1, [] );
    denom1 = 1 + cell0;
    %   ..compute cell (i,j) of E inverse
    cell1 =  Mcell( n, i, j,    [] );
    cell2 =  Mcell( n, i, n3-1, [] );
    cell3j = Mcell( n, 3, j,    [] );
    rEinvij = cell1 - (cell2 * cell3j / denom1);
    %   ..compute cell (i,n3) of E inverse
    cell1 = Mcell( n, i, n3,   [] );
    cell3n3 = Mcell( n, 3, n3, [] );
    rEinvin3 = cell1 - (cell2 * cell3n3 / denom1);
    %   ..compute cell (2,j) of E inverse
    cell1 = Mcell( n, 2, j,    [] );
    cell2 = Mcell( n, 2, n3-1, [] );
    rEinv2j = cell1 - (cell2 * cell3j / denom1);
    %   ..compute cell (2,n3) of E inverse
    cell1 = Mcell( n, 2, n3,   [] );
    rEinv2n3 = cell1 - (cell2 * cell3n3 / denom1);
    %   ..compute the (i,j) cell of S inverse
    denom2 = 1 + rEinv2n3;
    cell = rEinvij - (rEinvin3 * rEinv2j / denom2);
    return
end

function [a,b] = pqfit0( k, rates, a, b )
%      Huifen Chen and Bruce Schmeiser, March 14, 2105.
%      PQRS Context: 0. Cyclic.
%      Fit unconstrained rates; i.e., ignore negativity.
%      Method:  Maintain k means, k continuity points, and
%               k first derivatives. Rows 1 and 2 of M0 inverse.
%      input: 
%        k     = number of intervals
%        rates = specified rates, i=1,...,k
%      output:
%        (a,b) = second- and first-order quadratic coefficients

    %   ..initialize
    a = zeros(1,k);
    b = zeros(1,k);
    %   ..compute (a,b), block 0 to block k-1
    for m = 0 : (k-1)
        jindex = 3*m + 1;
        cell1j = Mcell( k, 1, jindex, [] );
        cell2j = Mcell( k, 2, jindex, [] );
        for i = 1 : k
            jrotate = m + i;
            if (jrotate > k) jrotate = jrotate - k; end
            a(i) = a(i) + cell1j * rates(jrotate);
            b(i) = b(i) + cell2j * rates(jrotate);
        end
    end
end

function [a,b] = pqfit1( k, rates, rate0, ratekp1, a, b )
%      Huifen Chen and Bruce Schmeiser, March 14, 2015.
%      PQRS Context: 1. Finite horizon, two end-point rates.
%      Fit unconstrained rates; i.e., ignore negativity.
%      Method:  Maintain k means, k-1 continuity, k-1 first
%               derivatives, and two end-point rates. 
%      input: 
%        k     = number of intervals
%        rates = specified rates, i=1,...,k
%        rate0 = left end-point rate
%        ratekp1 = right end-point rate
%      output:
%        (a,b) = second- and first-order quadratic coefficients  
    if k == 1
        a = 3*(rate0 + ratekp1) - 6*rates(1);
        b = ratekp1 - rate0 - a;
        return
    end
    %   ..initialize
    k3   = 3*k ;
    %   ..get constants p, q, and d1
    p = Scell( k-1, 3, k3-3, [] );
    q = Scell( k-1, 3, k3-4, [] );
    d1 = 4*p - q;
    %   ..compute (ai,bi), i=1,..,k-1
    a = zeros(1,k);
    b = zeros(1,k);
    for i = 1 : (k-1)
        for ioffset = 0 : 1
            iindex = 3*i - 2 + ioffset;
            rMuli3 = Scell( k-1, iindex, k3-3, [] );
            rMuli4 = Scell( k-1, iindex, k3-4, [] );
            for j = 1 : (k-1)
                jindex = 3*j-2;
                %   ..G11, the upper-left corner of M1inv
                rMulij = Scell( k-1, iindex, jindex, [] );
                rMul3j = Scell( k-1, 3,      jindex, [] );
                rMulij = rMulij - ((4*rMuli3 - rMuli4)*rMul3j) / d1;
                if (ioffset == 0) a(i) = a(i) + rMulij * rates(j); end
                if (ioffset == 1) b(i) = b(i) + rMulij * rates(j); end
            end
                %..G12, the upper-right corner of M1inv
            celli3 = Scell( k-1, iindex, k3-3, [] );
            celli4 = Scell( k-1, iindex, k3-4, [] );
            rMuri0 =    (4*celli3 -   celli4) / d1;
            rMuri1 =  2*(q*celli3 - p*celli4) / d1;
            rMurik = -6*(q*celli3 - p*celli4) / d1;
            if ioffset == 0
                a(i) = a(i) + rates(k) * rMurik;
                a(i) = a(i) + rate0    * rMuri0;
                a(i) = a(i) + ratekp1  * rMuri1;
            else
                b(i) = b(i) + rates(k) * rMurik;
                b(i) = b(i) + rate0    * rMuri0;
                b(i) = b(i) + ratekp1  * rMuri1;
            end
        end
    end
    %   ..compute (ak, bk)
    ckm1 = rates(k-1) - a(k-1)/3 - b(k-1)/2;
    ck   = a(k-1) + b(k-1) + ckm1;
    b(k) = 2*a(k-1) + b(k-1);
    a(k) = 3*(rates(k) - b(k)/2 - ck);
    return
end

function [a,b] = pqfit2( k, rates, rate0, a, b )
%      Huifen Chen and Bruce Schmeiser, March 14, 2015.
%      PQRS Context: 2. Finite horizon, only left end-point rate.
%      Fit unconstrained rates; i.e., ignore negativity.
%      Method:  Minimize sum_i=1^k a_i^2, subject to k means, 
%               k continuity, and k-1 first derivatives.
%               a(k) is the free variable.
%      input: 
%        k     = number of intervals
%        rates = specified rates, i=1,...,k
%        rate0 = left end-point rate
%      output:
%        (a,b) = second- and first-order quadratic coefficients
    if k == 1
        a = 0;
        b = 2*(rates(1) - rate0);
        return
    end
    %   ..initialize
    k3 = 3*k ;
    bottom = 0;
    top    = 0;
    %   ..use Q22, the lower-right (2x2) corner of sM2inv
    p = Scell( k-1, 3, k3-3, [] );
    q = Scell( k-1, 3, k3-4, [] );
    d2 = (q/2) - p;
    %   ..begin computing bi, i=1,..,k-1, using rows 2,5,... of Q11
    b = zeros(1,k);
    for i = 1 : (k-1)
        iindex = 3*i - 1;
        celli3 = Scell( k-1, iindex, k3-3, [] ) ;
        celli4 = Scell( k-1, iindex, k3-4, [] ) ;
        for j = 1 : (k-1)
            jindex= 3*j - 2;
            cellij = Scell( k-1, iindex, jindex, [] ) ;
            cell3j = Scell( k-1, 3, jindex, [] ) ;
            rMulij = cellij + ((celli3-celli4/2)*cell3j) / d2;
            b(i) = b(i) + rMulij * rates(j);
        end
    end
    %   ..begin computing ak using Q11, the upper-left corner of sM2inv
    %   ..begin computing ai, i=1,..,k-1, using rows 1, 4,... of Q11
    a = zeros(1,k);
    for i = 1 : (k-1)
        iindex = 3*i - 2 ;
        celli3 = Scell( k-1, iindex, k3-3, [] ) ;
        celli4 = Scell( k-1, iindex, k3-4, [] ) ;
        rMuri2 = (q*celli3 - p*celli4  ) / d2;
        rMuri1 = ( -celli3 +   celli4/2) / d2;
        gammai = rMuri1 * rate0 + rMuri2 * rates(k);
        for j = 1 : (k-1)
            jindex= 3*j - 2;
            cellij = Scell( k-1, iindex, jindex, [] ) ;
            cell3j = Scell( k-1,      3, jindex, [] ) ;
            rMulij = cellij + ((celli3 - celli4/2)*cell3j) / d2;
            a(i) = a(i) + rMulij * rates(j);
            gammai = gammai + rMulij * rates(j);
        end
        top    = top    + rMuri2 * gammai;
        bottom = bottom + rMuri2^2;
    end
    %   ..finish computing ak
    bottom = 3 + (bottom / 3);
    a(k)   = top / bottom;
    %   ..finish computing (ai, bi), i=1,...,k-1 using Q12
    for i = 1 : (k-1)
        for ioffset = 0:1
            iindex = 3*i - 2 + ioffset;
            celli3 = Scell( k-1, iindex, k3-3, [] );
            celli4 = Scell( k-1, iindex, k3-4, [] );
            rMuri2 = (q*celli3 - p*celli4  ) / d2;
            rMuri1 = ( -celli3 +   celli4/2) / d2;
            ab = rMuri2 * (rates(k) - a(k)/3) + rMuri1 * rate0;
            if (ioffset == 0) a(i) = a(i) + ab;   end
            if (ioffset == 1) b(i) = b(i) + ab;   end
        end
    end
    %   ..compute bk
    b(k) = 2*a(k-1) + b(k-1);
    return
end

function [a,b] = pqfit3( k, rates, ratekp1, a, b )
%      Huifen Chen and Bruce Schmeiser, March 14, 2015.
%      PQRS Context: 3. Finite horizon, only right end-point rate.
%      Fit unconstrained rates; i.e., ignore negativity.
%      Method:  Time reverse Context 2.
%      input: 
%        k     = number of intervals
%        rates = specified rates, i=1,...,k
%        ratekp1 = right end-point rate
%        
%      output:
%        (a,b) = second- and first-order quadratic coefficients
    khalf = floor( k/2 );
    %   ..reverse time for input rates
    rate0 = ratekp1;
    for i = 1 : khalf
        temp         = rates(i);
        rates(i)     = rates(k-i+1)     ;           
        rates(k-i+1) = temp;
    end
    %   ..call context 2 fitting
    [a,b] = pqfit2( k, rates, rate0, [], [] );
    %   ..convert coefficients to x from 1-x
    %   these coefficients are for interval k
    for i = 1 : k
        b(i) = -2*a(i) - b(i);
    end
    %   ..reverse time for the input rates and results
    for i = 1 : khalf
        temp     = rates(i);
        rates(i) = rates(k-i+1);
        rates(k-i+1) = temp;
        temp     = a(i);
        a(i)     = a(k-i+1);
        a(k-i+1) = temp;
        temp     = b(i);
        b(i)     = b(k-i+1);
        b(k-i+1) = temp;
    end
    return
end

function [a,b] = pqfit4( k, rates, a, b )
%      Huifen Chen and Bruce Schmeiser, March 14, 2015.
%      PQRS Context: 4. Finite horizon, no end-point rates.
%      Fit unconstrained rates; i.e., ignore negativity.
%      Method:  Minimize sum_i=1^k a_i^2, subject to k means, 
%               k-1 continuity, and k-1 1st derivatives.
%               a(1) and a(k) are the free variables.
%      input: 
%        k     = number of intervals
%        rates = specified rates, i=1,...,k
%      output:
%        (a,b) = second- and first-order quadratic coefficients
    if k == 1
        a = 0;
        b = 0;
        return
    elseif k == 2
        a = [0 0];
        b = [rates(2) - rates(1) b(1)];
        return
    end
    %   ..k > 2, so initialize
    a = zeros(1,k);
    b = zeros(1,k);
    
    k3    = 3*k ;
    alpha = 1;
    beta  = 0;
    phi   = 0;
    eta   = 1;
    xi    = 0;
    %   ..compute R22, the 4x4 lower-right corner of rM4inv
    w1 = Scell( k-2, 3, k3-6, [] );
    w2 = Scell( k-2, 3, k3-7, [] );
    w3 = Scell( k-2, 2, k3-6, [] );
    w4 = Scell( k-2, 2, k3-7, [] );
    d4 = w1 - w2/2 - w3/2 + w4/4;
    rMlr55 =  (-w2 + w4/2)            / d4;
    rMlr54 =   1                      / d4;
    rMlr53 =  -1                      / d4;
    rMlr52 =     0.5d0                / d4;
    rMlr45 =  (w1 - w3/2)             / d4;
    rMlr44 =    -0.5d0                / d4;
    rMlr43 =     0.5d0                / d4;
    rMlr42 =    -0.25d0               / d4;
    rMlr35 =  (w1*w4 - w2*w3)         / d4;
    rMlr34 =  (w3 - w4/2)             / d4;
    rMlr33 =  (-w3 + w4/2)            / d4;
    rMlr32 =  (w1 - w2/2)             / d4;
    rMlr25 =  ((w2*w3 - w1*w4)/2)     / d4;
    rMlr24 =  (w1 - w2/2 - w3 + w4/2) / d4;
    rMlr23 =  (w3/2 - w4/4)           / d4;
    rMlr22 =  (w2/4 - w1/2)           / d4;
    %   ..compute a1 and ak
    for i = 1 : (k-2)
        iindex = 3*i - 2;
        %   ..using R12, the upper-right-corner of rM4inv
        celli6 = Scell( k-2, iindex, k3-6, [] );
        celli7 = Scell( k-2, iindex, k3-7, [] );
        rMuri5 = rMlr55*celli6 + rMlr45*celli7;
        rMuri4 = rMlr54*celli6 + rMlr44*celli7;
        rMuri3 = rMlr53*celli6 + rMlr43*celli7;
        rMuri2 = rMlr52*celli6 + rMlr42*celli7;
        p = -rMuri4 / 3 - rMuri3 - 2*rMuri2;
        q = -rMuri5 / 3;
        r =  rMuri4 * rates(1) + rMuri5*rates(k);
        for j = 2 : (k-1)
            %   ..using R11, the upper-left-corner of rM4inv
            jindex = 3*j - 5;
            cellij = Scell( k-2, iindex, jindex, [] );
            cell2j = Scell( k-2, 2,      jindex, [] );
            cell3j = Scell( k-2, 3,      jindex, [] );
            rMulij = cellij + ((2*celli6-celli7)*(cell2j-2*cell3j))/(4*d4);
            r = r + rMulij * rates(j);
        end
        alpha = alpha + p^2;
        beta  = beta  + p*q;
        phi   = phi   + p*r;
        eta   = eta   + q^2;
        xi    = xi    + q*r;
    end
    denom = beta^2 - alpha*eta;
    a(1)  = (eta*phi  - beta*xi ) / denom;
    a(k)  = (alpha*xi - beta*phi) / denom;
    factor2 =          - 2*a(1);
    factor3 =          -   a(1);
    factor4 = rates(1) -   a(1)/3;
    factor5 = rates(k) -   a(k)/3;
    %   ..compute b1 and bk using rows k3-3 and k3-5 of M4inv
    %   ....from R22, the lower-right corner of M4inv
    b(1) =        rMlr32 * factor2 + rMlr33 * factor3;
    b(1) = b(1) + rMlr34 * factor4 + rMlr35 * factor5;
    b(k) =        rMlr52 * factor2 + rMlr53 * factor3;
    b(k) = b(k) + rMlr54 * factor4 + rMlr55 * factor5;
    %   ....from R21, the lower-left corner of M4inv
    for j = 2 : (k-1)
        jindex = 3*j - 5;
        cell2j = Scell( k-2, 2, jindex, [] );
        cell3j = Scell( k-2, 3, jindex, [] );
        rMll3j = rMlr33 * cell3j + rMlr32 * cell2j;
        rMll5j = rMlr53 * cell3j + rMlr52 * cell2j;
        b(1) = b(1) + rMll3j * rates(j);
        b(k) = b(k) + rMll5j * rates(j);   
    end
    %   ..compute (ai,bi), i=2,...,k-1
    for i = 2 : (k-1)
        for ioffset = 0 : 1
            iindex = i*3 - 5 + ioffset;
            celli6 = Scell( k-2, iindex, k3-6, [] );
            celli7 = Scell( k-2, iindex, k3-7, [] );
            %   ....use R12, the upper-right corner of M4inv
            rMuri5 = celli6*rMlr55 + celli7*rMlr45;
            rMuri4 = celli6*rMlr54 + celli7*rMlr44;
            rMuri3 = celli6*rMlr53 + celli7*rMlr43;
            rMuri2 = celli6*rMlr52 + celli7*rMlr42;
            ab=rMuri5*factor5+rMuri4*factor4+rMuri3*factor3+rMuri2*factor2;
            if (ioffset == 0) a(i) = ab; end
            if (ioffset == 1) b(i) = ab; end
            %   ....use R11, the upper-left corner of M4inv
            for j = 2 : (k-1)
                jindex = 3*j - 5;
                cellij = Scell( k-2, iindex, jindex, [] );
                cell2j = Scell( k-2, 2,      jindex, [] );
                cell3j = Scell( k-2, 3,      jindex, [] );
                rMulij = cellij+((2*celli6-celli7)*(cell2j-2*cell3j))/(4*d4);
                if (ioffset == 0) a(i) = a(i) + rMulij * rates(j); end
                if (ioffset == 1) b(i) = b(i) + rMulij * rates(j); end
            end
        end
    end
    return
end

function [aplus, bplus, cplus] = MNOfit( icontxt, k, rates, rate0, ratekp1, ...
                                        a, b, c, aplus, bplus, cplus)
%      Fen Chen and Bruce Schmeiser, Feb 14, 2015.
%      For each interval, modify the quadratic ax^2+bx+c to
%      max{0, aplus x^2 + bplus x + cplus}, so then no negative rate.
%      input:
%        icontxt = context \in {0,1,2,3,4}
%        k = number of intervals
%        rates = specified rates, i=1,...,k
%        rate0, ratekp1 = time-zero and time-k specified rates
%        (a,b,c) = PQRS quadratic coefficients
%      output:
%        (aplus, bplus, cplus) = updated quadratic coefficients    
    epsilon = 1d-10;
    %   ..set default values
    aplus = a;
    bplus = b;
    cplus = c;
    %   ..determine the initial negativity case for each interval
    icase = pqcase( k, rates, a, b, c, [] );
    %   ..MNO update in specific case order
    for i = 1 : k
        [aplus, bplus, cplus] = MNOfit4( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                a, b, c, aplus, bplus, cplus);
    end
    for i = 1 : k
        [aplus, bplus, cplus] = MNOfit3( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                a, b, c, aplus, bplus, cplus);
    end
    for i = 1 : k
        [aplus, bplus, cplus] = MNOfit2( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                a, b, c, aplus, bplus, cplus);
    end
    for i = 1 : k
        [aplus, bplus, cplus] = MNOfit1( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                a, b, c, aplus, bplus, cplus);
    end
    [aplus, bplus, cplus] = MNOfit0( icontxt, k, rates, rate0, ratekp1, icase, 1, ...
                                a, b, c, aplus, bplus, cplus);
    [aplus, bplus, cplus] = MNOfit0( icontxt, k, rates, rate0, ratekp1, icase, k, ...
                                a, b, c, aplus, bplus, cplus);
    %    ..override with zero-rate values
    for i = 1 : k
        if rates(i) < epsilon
          aplus(i) = 0;
          bplus(i) = 0;
          cplus(i) = 0;
        end
    end
    return
end

function [aplus, bplus, cplus] = MNOfit4( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                 a, b, c, aplus, bplus, cplus)
%      Fen Chen and Bruce Schmeiser, Feb 14, 2015
%      MNO update: max{ 0, aplus x^2 + bplus x + cplus }
%        Case 4---negative rates; 2 nonnegative end-point rates
%      input:
%        icontxt = context \in {0,1,2,3,4}
%        k = number of intervals
%        rates = specified rates, i=1,...,k
%        rate0, ratekp1 = time-zero and time-k specified rates
%        icase = negativity case {0,1,2,3,4}
%        (a,b,c) = PQRS quadratic coefficients
%      output:
%        (aplus, bplus, cplus) = MNO quadratic coefficients 
    
    epsilon = 1d-10;
    if icase(i) == 4
        qrate = rates(i);
        q0    = c(i);
        q1    = a(i) + b(i) + c(i);
        cplus(i) = c(i);
        %   ..use secant method.
        aold = a(i);
        bold = q1 - cplus(i) - aold;
        qintold = qmaxint( aold, bold, q0, [] );
        a2 = a(i) + 0.10*abs(a(i));       % aplus >= a, always
        qintnew = qrate + 10*epsilon + 1; % always 1st-time failure
        while  abs( qintnew - qrate ) > epsilon 
            aplus(i) = a2;
            bplus(i) = q1 - q0 - aplus(i);
            qintnew = qmaxint( aplus(i), bplus(i), q0, [] );
            if qintnew ~= qintold
                a2 = aplus(i) - (aplus(i)-aold)*(qintnew-qrate)/(qintnew-qintold);
                aold = aplus(i);
                qintold = qintnew;
            else
                qintnew = qrate;
            end
        end
    end
    return
end

function [aplus, bplus, cplus] = MNOfit2( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                 a, b, c, aplus, bplus, cplus)
%       Fen Chen and Bruce Schmeiser, Feb 14, 2015
%      MNO update: max{ 0, aplus x^2 + bplus x + cplus }
%        Case 2---negative rates; only right nonnegative end-point rate
%      input:
%        icontxt = context \in {0,1,2,3,4}
%        k = number of intervals
%        rates = specified rates, i=1,...,k
%        rate0, ratekp1 = time-zero and time-k specified rates
%        icase = negativity case {0,1,2,3,4}
%        (a,b,c) = PQRS quadratic coefficients
%      output:
%        (aplus, bplus, cplus) = MNO quadratic coefficients
    if icase(i) == 2
        qrate = rates(i);
        q1 = a(i) + b(i) + c(i);
        %   ..if there is a next interval, use it for q1p
        if (icontxt > 0 && i == k)
          q1p = 2*a(i) + b(i);
        else
          if i < k
            inext = i + 1;
          elseif icontxt == 0
            inext = 1;
          end
          q1p = bplus(inext);
        end
        %   ..case 2 is closed form. 
        term1 = -q1 * (4*q1^2 - 9*q1p*qrate);
        term2 = 2*(2*q1^2 - 3*q1p*qrate)^3;
        aplus(i)  = (term1 - sqrt( term2 ) ) / (18*qrate^2)   ;       
        bplus(i)  = q1p - 2*aplus(i);
        cplus(i)  = q1 - q1p + aplus(i);
    end
    return
end

function [aplus, bplus, cplus] = MNOfit3( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                 a, b, c, aplus, bplus, cplus)
%       Fen Chen and Bruce Schmeiser, Feb 14, 2015
%      MNO update: max{ 0, aplus x^2 + bplus x + cplus }
%        Case 3---negative rates; only left nonnegative end-point rate
%      input:
%        icontxt = context \in {0,1,2,3,4}
%        k = number of intervals
%        rates = specified rates, i=1,...,k
%        rate0, ratekp1 = time-zero and time-k specified rates
%        icase = negativity case {0,1,2,3,4}
%        (a,b,c) = PQRS quadratic coefficients
%      output:
%        (aplus, bplus, cplus) = MNO quadratic coefficients      
    if icase(i) == 3
        qrate = rates(i);
        q0 = c(i);
        %   ..if there is a previous interval, use it for q0p
        if (icontxt > 0 && i == 1) 
          q0p = b(i);
        else
          if i > 1 
            iprev = i - 1;
          elseif icontxt == 0
            iprev = k;
          end
          q0p = 2*aplus(iprev) + bplus(iprev);
        end
        %   ..case 3 is closed form. 
        term1 = -q0 * (4*q0^2 + 9*q0p*qrate);
        term2 = 2*(2*q0^2 + 3*q0p*qrate)^3;
        aplus(i) = (term1 - sqrt( term2 ) ) / (18*qrate^2)   ;       
        bplus(i) = q0p;
        cplus(i) = c(i);
    end
    return;
end                             


function [aplus, bplus, cplus] = MNOfit1( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                 a, b, c, aplus, bplus, cplus)
%       Fen Chen and Bruce Schmeiser, Feb 14, 2015
%      MNO update: max{ 0, aplus x^2 + bplus x + cplus }
%        Case 1---negative rates; no nonnegative end-point rate
%      input:
%        icontxt = context \in {0,1,2,3,4}
%        k = number of intervals
%        rates = specified rates, i=1,...,k
%        rate0, ratekp1 = time-zero and time-k specified rates
%        icase = negativity case {0,1,2,3,4}
%        (a,b,c) = PQRS quadratic coefficients
%      output:
%        (aplus, bplus, cplus) = MNO quadratic coefficients  
    epsilon = 1d-10;
    if icase(i) == 1
        qrate = rates(i);        % same as for case 4
        q0 = c(i);
        q1 = a(i) + b(i) + c(i);
        cplus(i) = c(i);
        %   ..use secant method.
        aold = a(i);
        bold = q1 - cplus(i) - aold;
        qintold = qmaxint( aold, bold, q0, [] );
        a2 = a(i) + 0.10*abs(a(i)) ; % aplus > a, always
            %for the future:a < aplus < (q0 + q1) - 2sqrt(q0q1) < 0
        qintnew = qrate + 10*epsilon + 1; % always 1st-time failure
        while  abs( qintnew - qrate ) > epsilon 
            aplus(i) = a2;
            bplus(i) = q1 - q0 - aplus(i);
            qintnew = qmaxint( aplus(i), bplus(i), q0, [] );
            if qintnew ~= qintold
                a2 = aplus(i) - (aplus(i)-aold)*(qintnew-qrate)/(qintnew-qintold);
                aold = aplus(i);
                qintold = qintnew;
            else
                qintnew = qrate;
            end
        end
    end
    return
end

function [aplus, bplus, cplus] = MNOfit0( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                 a, b, c, aplus, bplus, cplus)
%     Fen Chen and Bruce Schmeiser, Feb 14, 2015
%     MNO update: max{ 0, aplus x^2 + bplus x + cplus }
%       Case 0---no negative rates; finite horizon, context 2, 3, 4
%         interval {1,k} adjacent to an updated case-4 interval
%     input:
%       icontxt = context \in {0,1,2,3,4}
%       k = number of intervals
%       rates = specified rates, i=1,...,k
%       rate0, ratekp1 = time-zero and time-k specified rates
%       icase = negativity case {0,1,2,3,4}
%       (a,b,c) = PQRS quadratic coefficients
%     output:
%       (aplus, bplus, cplus) = MNO quadratic coefficients
    if i == 1
        if (icontxt == 4 || icontxt == 3)
            %   ..first interval    
            if (icase(1) == 0 && icase(2) == 4)
                qrate = rates(1);
                q1  = cplus(2);
                q1p = bplus(2);
                cplus(1) = 3*qrate -2*q1 + q1p/2;
                bplus(1) = 2*(q1 - cplus(1)) - q1p;
                aplus(1) = (q1p - bplus(1)) / 2;
                icase = pqcase( k, rates, aplus, bplus, cplus, [] );
                %   ..re-update if interval 1's case changed
                i = 1;
                if icase(1) == 2
                    [aplus, bplus, cplus] = MNOfit2( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                                    a, b, c, [], [], []);
                elseif icase(1) == 4
                    [aplus, bplus, cplus] = MNOfit4( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                                    a, b, c, [], [], []);
                end
            end
        end
    elseif i == k
        if (icontxt == 4 || icontxt == 2)
            %   ..last interval
            if (icase(k) == 0 && icase(k-1) == 4)
                qrate = rates(k);
                q0    = cplus(k);
                q0p   = 2*aplus(k-1) + bplus(k-1);
                cplus(k) = q0;
                bplus(k) = q0p;
                aplus(k) = 3*(qrate - bplus(k)/2 - cplus(k));
                icase = pqcase( k, rates, aplus, bplus, cplus, [] );
                %   ..re-update if interval k's case changed
                if icase(k) == 3
                    [aplus, bplus, cplus] = MNOfit3( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                                    a, b, c, [], [], []);
                elseif icase(k) == 4
                    [aplus, bplus, cplus] = MNOfit4( icontxt, k, rates, rate0, ratekp1, icase, i, ...
                                                    a, b, c, [], [], []);
                end
            end
        end
    end
    return
end

function icase = pqcase( k, rates, a, b, c, icase )
%      Fen Chen and Bruce Schmeiser, Feb 14, 2015.
%      For each interval, determine the negativity case.
%      input:
%        k = number of intervals
%        rates = specified rates, i=1,...,k
%        (a,b,c) = PQRS quadratic coefficients
%      output:
%        icase = the negativity case for i=1,...,k
    for i = 1 : k
        %   ..compute qmin = min{ ax^2 + bx + c : x \in [0,1] }
        q0 = c(i);
        q1 = a(i) + b(i) + c(i);
        qmin = min( q0, q1 );
        if  a(i) > 0 
          xstar = -b(i) / (2*a(i));
          if (xstar > 0 && xstar < 1)
            qmin = c(i) - (b(i)^2 / (4*a(i)));
          end
        end
        %   ..compute negativity cases
        icase(i) = 0;
        if (qmin < 0) 
          if (q0 >= 0 && q1 >= 0) 
            icase(i) = 4;
          elseif (q0 >= 0 && q1 < 0)
            icase(i) = 3;
          elseif (q0 < 0 && q1 >= 0)
            icase(i) = 2;
          else
            icase(i) = 1;        
          end
        end
    end
    return
end

function qrate = qmaxint( a, b, c, qrate )
%      Huifen Chen and Bruce Schmeiser. Feb 7, 2015
%      purpose: integrate max{ 0, a x^2 + b x + c } over [0,1].
%      Known to be positive only on (alpha, beta) and (gamma, 1).
%      input:
%        a, b, c = quadratic coeffients
%      output:
%        qrate = integral value
    [alpha, beta, gamma] = qpartit( a, b, c, [], [], [] );
    qrate =    (a/3) * ( (beta^3 - alpha^3) + (1 - gamma^3) ) ...
             + (b/2) * ( (beta^2 - alpha^2) + (1 - gamma^2) ) ...
             +  c    * ( (beta   - alpha  ) + (1 - gamma  ) );
    return
end

function [alpha,beta,gamma] = qpartit( a, b, c, alpha, beta, gamma )
%      Huifen Chen and Bruce Schmeiser.  March 1, 2014
%      purpose: Over [0,1], partition q(x) = ax^2 + bx + c 
%        into negative and non-negative intervals.
%      input: a, b, c
%      output: 
%        (alpha, beta, gamma) = the sign-change points in [0,1].   
%          Always    q(0,    alpha) <  0.
%                    q[alpha, beta] >= 0.
%                    q(beta, gamma) <  0.
%                    q[gamma,    1] >= 0.
%          The three values are not unique; we use
%          alpha = 0 when a > 0 and gamma = 1 when a < 0.
    alpha = 0;
    beta  = 0;
    gamma = 1;
    if a == 0
        if b == 0       
          if (c >= 0) beta = 1; end
        else
          root = - c / b   ;
          if b < 0 
            beta  = max( 0d0, min( 1d0, root ) );
          else
            gamma = max( 0d0, min( 1d0, root ) );
          end
        end
      else
        char = b^2 - 4*a*c;
        if (char < 0) 
          if (a >= 0) beta = 1; end
        else
          schar = sqrt( char )   ;
          root1 = (- b - schar) / (2*a)    ;  
          root2 = (- b + schar) / (2*a)   ;   
          beta  = max( 0d0, min( 1d0, root1 ) );
          if a < 0 
            alpha = max( 0d0, min( 1d0, root2 ) );
          else           
            gamma = max( 0d0, min( 1d0, root2 ) );
          end
        end
    end
    return
end

function y = Q(k,a,b,c,t)  
% Huifen Chen, Bruce Schmeiser, Chien-Hua Wu, November 24, 2013 
% Purpose: Compute the function value of the piecewise-quadratic function
%          (a_i x^2 + b_i x + c+i)*I(i-1<= x <= i), i=1,..., k, where
%          I() is an indicator function.
% Input:
%   k: number of intervals
%   a: 1xk vector, where a(i) is the 2nd-order coefficient for the ith quadratic function 
%   b: 1xk vector, where b(i) is the 1st-order coefficient for the ith quadratic function
%   c: 1xk vector, where c(i) is the intercept for the ith quadratic function
%   t: time to evaluate its function value
% Output:
%   y: function value at time t
%
   int_t = floor(t);
   x = t - int_t;     % compute the fractional part of t  
   i = int_t + 1;     % the piece number where t locates
   j = find(i > k);
   i(j) = k; 
   x(j) = 1;
   y = a(i).*x.*x+ b(i).*x + c(i);
   return;
end

function y = Q2(k,a,b,c,t)  
% Huifen Chen, Bruce Schmeiser, Chien-Hua Wu, November 24, 2013 
% Purpose: Compute the function value of the piecewise-quadratic function
%          (a_i x^2 + b_i x + c+i)*I(i-1<= x <= i), i=1,..., k, where
%          I() is an indicator function.
% Input:
%   k: number of intervals
%   a: 1xk vector, where a(i) is the 2nd-order coefficient for the ith quadratic function 
%   b: 1xk vector, where b(i) is the 1st-order coefficient for the ith quadratic function
%   c: 1xk vector, where c(i) is the intercept for the ith quadratic function
%   t: time to evaluate its function value
% Output:
%   y: function value at time t
%
   int_t = floor(t);
   x = t - int_t;     % compute the fractional part of t  
   i = int_t + 1;     % the piece number where t locates
   j = find(i > k);
   i(j) = k; 
   x(j) = 1;
   y = a(i).*x.*x+ b(i).*x + c(i);
   y(y < 0) = 0;
   return;
end
    