#include <stdio.h>
#include <math.h>

void  retro();
void  search();
float ybar();
float yi();

void retro(gamma,se_x,iseed,xhat,se_xhat,nobs)
       long   *iseed;
       int    *nobs;
       float  gamma,se_x;
       float  *xhat,*se_xhat;

/*  purpose:   root-finding by bounding retrospective approximation. */
/*  authors:   huifen chen, department of industrial engineering,    */
/*               da-yeh institute of technology, chang-hwa, taiwan.  */
/*             bruce schmeiser                                       */
/*               school of industrial engineering                    */
/*               purdue university                                   */
/*               west lafayette, in  47907-1287                      */
/*             converted to C by huifen chen and chung-gong jeng,    */
/*               in november, 1994.                                  */
/*  reference:                                                       */
/*             huifen chen.  stochastic root finding in system       */
/*             design.  phd dissertation.  school of industrial      */
/*             engineering,  purdue university.  1994.               */
/*  input:                                                           */
/*    gamma:   desired function value                                */
/*    se_x:    desired standard error of xhat                        */
/*    iseed:   random-number seed                                    */
/*  output:                                                          */
/*    iseed:   random-number seed                                    */
/*    xhat:    estimated root                                        */
/*    se_xhat: estimated standard error of xhat                      */
/*    nobs:    number of observations y                              */
/*  called by:                                                       */
/*    main:    a user-written driver program                         */
/*  function called                                                  */
/*    search:  a deterministic regula-falsi line search              */


{
      float x0 = 1. ,          /*  set algorithm parameters.  */
            delta1 = 0.0001 ,  /*  step size */
            c1 = 2.0,          /*  m(i+1) = c1 * m(i) */
            c2 = 1.0;          /*  for seting delta */
      int   m1 = 2;            /*  initial sample size */

      /* initialize bounding retrospective approximation. */
      int   m       = m1,
            k           ,
            i       = 0 ,
            summ    = 0 ;
      float fm      = m1,
            delta   = delta1,
            sigma_1 = 0.0,
            sigma   = 0.0,
            summx   = 0.0,
            summx2  = 0.0,
            v            ;

       *xhat   = x0;            /* initilize iterative variables */
       *nobs   = 0;
       *se_xhat=0.0;

       while(1)                 /* begin bounding RA iterations. */
       {
           i++;
           search( gamma,m,iseed,delta,xhat,&sigma_1,&k );

           /* ...compute the root estimator as a weighted average. */
           summ   = summ  + m;
           summx  = summx + m * (*xhat);
           summx2 = summx2 + m * (*xhat)*(*xhat);
           *xhat   = summx / summ;

           /* ...estimate the standard error of the root estimator.  */
           if (i > 1)
               sigma = sqrt( (summx2 - summ*(*xhat)*(*xhat))/(i-1) );
           *se_xhat = sigma / sqrt( (double) summ );

           *nobs = *nobs + m*k;
           printf("  i = %d  xhat = %f  se_xhat = %f\n", i, *xhat, *se_xhat);

           if( i >= 4 && *se_xhat <= se_x)
               return;  /* return to main() and print i,xhat,se_xaht */

           fm    = fm * c1;      /* update m. */
           m     = (int)fm;

           /* estimate standard deviation of xhat - x*(i). */
           v     = sigma * sqrt( 1.0/summ + 1.0/m );
           if ( (i > 1) && (v != 0.) )
               delta = c2 * v;       /* update delta. */
       }

}


void  search( gamma,m,iseed0,delta0,x,sigma,k )
               long    *iseed0;
               int     m, *k;
               float   gamma, delta0;
               float   *x, *sigma;

/*  purpose: approximate the root via numerical search               */
/*           using a fixed random-number string for all              */
/*           function estimates.                                     */
/*  authors:   huifen chen and bruce schmeiser                       */
/*             school of industrial engineering                      */
/*             purdue university                                     */
/*             west lafayette, in  47907-1287                        */
/*  reference:                                                       */
/*             huifen chen.  stochastic root finding in system       */
/*             design.  phd dissertation.  school of industrial      */
/*             engineering,  purdue university.  1994.               */
/*  input:                                                           */
/*    gamma :  desired function value                                */
/*    m :      number of evaluations of function value               */
/*    iseed0:  random-number seed                                    */
/*    delta0:  initial increment/decrement                           */
/*    x:       initial guess                                         */
/*  output:                                                          */
/*    iseed0:  random-number seed                                    */
/*    x:       approximated root                                     */
/*    sigma:   asymptotic constant                                   */
/*    k:       number of x values considered                         */
/*  called by:                                                       */
/*    retro:   a bounding retrospective approximation algorithm      */
/*  function called:                                                 */
/*    ybar:    a monte carlo estimator of g(x)                       */
/*                                                                   */
/*                                                                   */

{
       /*  set parameters for numerical root finding  */
       float   err = 0.0000001;
       int     maxitr = 50;

       /*    initialize    */
       long    iseed;                  
       float   gl    = gamma + 1.0,
               gu    = gamma - 1.0,
               xl    = *x ,
               xu    = *x ,
               delta = delta0,
               ghat,
               se_g,
               gdiff,
               gslope,
               error,
               se_gl,
               se_gu,
               se_groot;

       *k=0;
       *sigma =0.0;

       /*  start search for bounds [xl,xu] bracketing root        */
       while(1)
       {
          *k    = *k + 1;
          iseed = *iseed0;

          /* ...compute function estimate at x. */
          ghat = ybar(m, *x, &iseed, &se_g ) ;

          printf("                m,x,ghat = %d %f %f\n", m,*x,ghat);  

          error = ghat - gamma;
          if(( fabs((double)error) < err) && (*sigma != 0.0))
          {
              *iseed0 = iseed;
              return;
          }

          if (error < 0.0)              /*   ...move up or down */
          {
              xl    = *x;
              gl    = ghat;
              se_gl = se_g;
              *x    = *x + delta;
           }
           else
           {
              xu    = *x;
              gu    = ghat;
              se_gu = se_g;
              *x    = *x - delta;
           }

           /*  ...if bounds are not found, double delta and continue.  */

           if (*k > maxitr)
           {
               /*  stop execution.  */
               printf("Exceed the maximal number of iterations.\n");
               exit(0);
           }
           if ( ((gu-gamma) * (gl-gamma)) >= 0.0)
           {
                /* ...update delta and look at a new point x.  */
                delta = delta + delta;
                continue;
           }

           /* ...otherwise, end search.       */
           /*                                 */
           /* ...compute asymptotic constant  */
           gdiff  = gu - gl;
           gslope = gdiff / (xu - xl);           /* estimate ghat'(x*) */
           se_groot = (sqrt((double) m) * ((gamma - gl) * se_gu
                        + (gu - gamma) * se_gl ) ) / gdiff;
           *sigma    = se_groot / fabs( (double)gslope );
                                                 /* estimate sigma[ Y(x*) */

           /* ...don't return if all points are identical  */
           if (*sigma <= 0.0)
           {
                *x= ( xl + xu ) / 2.0;
                continue;
           }

           /*   take linear combination of the function estimates at
                the bounds. */
           *x = xl + (xu - xl) * (gamma - gl) / (gu - gl);
           *iseed0 = iseed;
           return;
       }
}


float   ybar( m, x, iseed, se_g )
             long    *iseed;
             int     m;
             float   x, *se_g;

/*  purpose: estimate function value at x with m observations        */
/*  authors:   huifen chen and bruce schmeiser                       */
/*             school of industrial engineering                      */
/*             purdue university                                     */
/*             west lafayette, in  47907-1287                        */
/*  reference:                                                       */
/*             huifen chen.  stochastic root finding in system       */
/*             design.  phd dissertation.  school of industrial      */
/*             engineering,  purdue university.  1994.               */
/*  input:                                                           */
/*    m:        sample size                                          */
/*    x:        point to evaluate                                    */
/*    iseed:    random-number seed                                   */
/*  output:                                                          */
/*    ybar:     function estimate at x                               */
/*    iseed:    random-number seed                                   */
/*    se_g:     standard error of ybar at x                          */
/*                                                                   */
/*  called by:                                                       */
/*    search:   a deterministic regula-falsi line search             */
/*  function called:                                                 */
/*    yi:       one monte carlo observation to estimate  g(x)        */
/*                                                                   */

{
    int     i;
    float   ybarv,
            tmp,
            y;
    double  sum  = 0.0,
            sum2 = 0.0;

    for(i=1;i <= m;i++)
    {
       y    = yi(iseed,x);
       sum  = sum  + y;
       sum2 = sum2 + y*y;
    }

    ybarv = sum / m;
    *se_g = 0.0;
    tmp  = sum2 / m - ybarv*ybarv;
    if (tmp > 0.0)
       *se_g = sqrt( (double) (tmp / (m-1)) ) ;
    return(ybarv);

}


