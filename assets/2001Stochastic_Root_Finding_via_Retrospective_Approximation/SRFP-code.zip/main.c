/*********************************************************************
c     main program to illustrate bounding retrospective approximation.
c
c     implicit real    (a-h, o-z)
c     implicit integer (i-n)
c
*********************************************************************/

#include <stdio.h>
#include <math.h>

void  retro();

main()
{
      long  iseed;
      int   i, nrep, nobs, tnobs;
      float gamma, se_x, xhat, se_xhat, xhat_bar, sum, s2=0., se; 
      
/*
**    ...set desired function value gamma.
*/
      gamma  = .9;
/*
**    ...set desired standard error of the estimated root.
*/
      se_x   = .01;
/*
**    ...set the initial random number.
*/
      iseed  = 123456789;

/*
**    ...set the number of replications, and the total number of
**         samples generated.
*/
      nrep   = 2;
      tnobs  = 0;

      sum    = 0;
      for(i= 1; i <= nrep; i++)
      {
         printf("\nReplication number %d\n", i);

         retro( gamma,se_x,&iseed,&xhat,&se_xhat,&nobs );
         sum      = sum + xhat;
         xhat_bar = sum / (float)i;
         if (i > 1)  
            s2 = (i - 2)*s2/(i-1) + 2.*(xhat_bar-xhat)*(xhat_bar-xhat)/(i-1);
         se    = sqrt(s2/i);
         tnobs = tnobs + nobs;
         printf("\n");
         printf("current estimated root                     = %f\n", xhat_bar);
         printf("estimated standard error                   = %f\n", se);
         printf("cumulative number of function evaluations  = %d\n", tnobs);
     }
}


