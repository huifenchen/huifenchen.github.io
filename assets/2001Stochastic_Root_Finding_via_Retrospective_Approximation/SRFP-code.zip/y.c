#include <stdio.h>
#include <math.h>

#define TRUE  1
#define FALSE 0

void   data();
void   jdata();
void   jnormal();
float  urand();
float  ppnd();

int    i, ifault, test, fast, once=1, input=1;
int    n, itype;
float  gam, del, xlam, xi, alpha;

float yi( iseed, rk )
      long   *iseed;
      float rk;

/*.....purpose: Estimate the function value that is defined in the
**              Thiokol project.  Given sample size n, minimal 
**              reliability alpha, distribution shapes of random 
**              variable W, and the one-sided tolerance factor rk,
**              the function value at rk is 
**                    P      { P (Wbar - k*S < W) > alpha }
**                     Wbar,S   W
*/
{

      float y, wbar, ws, wlow, p, z, finv;

      data( iseed, &wbar, &ws );
      wlow = wbar - rk * ws; 
      p    = 1. - alpha;
      z    = ppnd( p, &ifault );
      jnormal( itype,gam,del,xlam,xi,z,&finv );
      y    = 0.;
      if ( wlow < finv ) y = 1.;
      return(y);
}


void data( iseed, xbar, xs )
     long   *iseed;
     float  *xbar, *xs;
{

      int  ianti=0;                 /* antithetic indicator */
      char john[5][10]              /* johnson distribution types */
           ={{"lognormal"},{"unbounded"},
             {"bounded"},{"normal"},{"bernoulli"}};
    
      if (input)
      {
         input = 0;
/*       ...input the tolerance parameters: n, alpha, and johnson 
**       distribution parameters (mean and variance are arbitrary)--
**       itype,gam,del,xlam,xi.
*/
         printf("enter sample size n and the minimum reliability alpha\n");
         scanf("%d %f", &n, &alpha);
         printf("enter the johnson parameters:itype,gam,del,xlam,xi\n");
         scanf("%d %f %f %f %f", &itype, &gam, &del, &xlam, &xi);  

         printf("\n|-----------------------------------------------------------|");
         printf("\n|  Johnson-family parameters                                |");
         printf("\n|       type                    = %15s           |",john[itype-1]);
         printf("\n|       xi         (location)   = %15.4f           |",xi);
         printf("\n|       lambda      (scaling)   = %15.4f           |",xlam);
         printf("\n|       gamma         (shape)   = %15.4f           |",gam);
         printf("\n|       delta         (shape)   = %15.4f           |",del);
         printf("\n|  Specified tolerance-interval parameters                  |");
         printf("\n|       n       (sample size)   = %15d           |",n);
         printf("\n|       alpha   (reliability)   = %15.6f           |",alpha);
         printf("\n|-----------------------------------------------------------|\n");
      }

      jdata( n,itype,gam,del,xlam,xi,ianti,iseed,xbar,xs );
      return;
}
      
    
/***********************************************************************
** FUNCTION: jdata(n,itype,gamma,delta,xlam,xi,ianti,iseed,xbar,xs)   **
**                                                                    **
** Purpose:  generates sample mean and standard deviation from a      **
**           set of n independent johnson-family random variates      **
**                                                                    **
** Input:                                                             **
**   n:      sample size                                              **
**   itype:  indicator of johnson distribution type                   **
**   gamma:  confidence level                                         **
**   delta:  reliability level                                        **
**   xlam:   johnson parameter                                        **
**   xi:     johnson parameter                                        **
**   ianti:  indicator for antithetic random number seeds             **
**   iseed:  random number seed                                       **
**                                                                    **
** Output:                                                            **
**   xbar:   sample mean                                              **
**   xs:     sample standard deviation                                **
***********************************************************************/
void jdata(n,itype,gamma,delta,xlam,xi,ianti,iseed,xbar,xs)
     int   n,itype,ianti;
     int   *iseed;
     float gamma,delta,xlam,xi,*xbar,*xs;
{
   void    jrand();

   int     i;
   double  sum,sum2;

   float   *x;
   x = (float *)malloc(n*sizeof(*x));

   sum   = 0.;
   sum2  = 0.;

   for (i=0; i<n; i++)
   {
       jrand (itype,gamma,delta,xlam,xi,ianti,iseed,&x[i] );
       sum  = sum  + x[i];
   }

   *xbar = sum / n;

   for (i=0; i<n; i++)
       sum2 = sum2 + (x[i] - *xbar) * (x[i] - *xbar); 

   *xs = sqrt( sum2 / (float)(n-1) );
   free(x);

}

/***********************************************************************
** FUNCTION: jrand (itype,gamma,delta,xlam,xi,ianti,iseed,x)          **
**                                                                    **
** Purpose:  generate one johnson-family random variate, x            **
**           z is a standard normal random variate                    **
**                                                                    **
**           itype:  1 => lognormal                                   **
**                   2 => su (unbounded range)                        **
**                   3 => sb (bounded range)                          **
**                   4 => normal                                      **
**                   5 => degenerate (sd=0) or bernoulli line         **
**                                                                    **
** Input:                                                             **
**   itype:  indicator of johnson distribution type                   **
**   gamma:  johnson family parameter                                 **
**   delta:  johnson family parameter                                 **
**   xlam:   johnson family parameter                                 **
**   xi:     johnson family parameter                                 **
**   ianti:  indicator for antithetic random number seeds             **
**   iseed:  random number seed                                       **
**                                                                    **
** Output:                                                            **
**   x:      transformed johnson random variate                       **
***********************************************************************/
void jrand (itype,gamma,delta,xlam,xi,ianti,iseed,x)
     int   itype,ianti;
     int   *iseed;
     float gamma,delta,xlam,xi,*x;
{
   void  jnormal();
   float urand();
   float ppnd();
   float u,z;

   u   = urand( iseed );
   if (ianti != 0) u = 1. - u;
   z   = ppnd( u,&ifault );
   jnormal( itype,gamma,delta,xlam,xi,z,x );
}

/***********************************************************************
** FUNCTION: jnormal( itype,gamma,delta,xlam,xi,z,x )                 **
**                                                                    **
** Purpose:  transform the normal variate to johnson variate          **
**           by its type and parameters                               **
**                                                                    **
**           itype:  1 => lognormal                                   **
**                   2 => su (unbounded range)                        **
**                   3 => sb (bounded range)                          **
**                   4 => normal                                      **
**                   5 => degenerate (sd=0) or bernoulli line         **
**                                                                    **
** Input:                                                             **
**   gamma,delta,xlam,xi: johnson family parameters                   **
**   z:      standard normal random variate                           **
**                                                                    **
** Output:                                                            **
**   x:      transformed johnson random variate                       **
***********************************************************************/
void jnormal( itype,gamma,delta,xlam,xi,z,x )
     int   itype;
     float gamma,delta,xlam,xi,z,*x;
{
   float zp,y;

   zp = (z - gamma) / delta;

   if (itype == 1)
    y = exp(zp);
   else if (itype == 2)
    y = 0.5 * (exp(zp) - exp(-zp));
   else if (itype == 3)
    y = 1.0 / (1.0+exp(-zp));
   else if (itype == 4)
    y = zp;
   else
    printf("\nitype out of range in jrand");

   *x = xi + (xlam * y);
}


/***********************************************************************
** FUNCTION: urand( iseed )                                           **
**                                                                    **
** Purpose:  generate a u(0,1) random number.                         **
**           we use the fast generator u16807d if it works properly on**
**           this computer.  otherwise it uses the portable, but slow,**
**           version u16807h.                                         **
**                                                                    **
** Input:                                                             **
**   iseed:  random number seed                                       **
**                                                                    **
** Output:                                                            **
**  urand_r: random number                                            **
***********************************************************************/
float urand( iseed )
   int *iseed;
{
   float    u16807d();
   float    u16807h();
   float    urand_r;
   int      j;
   long int itest;

   while (once == TRUE)
   {
     test = TRUE;
     fast = FALSE;
     once = FALSE;
   }

   /*
   **.....check (once) whether the logic of u16807d works here.
   */
   if (test)
   {
    test  = FALSE;
    itest = 1;
    for (j=1; j<=100; j++)
     u16807d(&itest);

    if (itest == 892053144) fast = TRUE;
   }

   /*
   **.....generate the random number.
   */

   do
    {if (fast)
      urand_r = u16807d( iseed );
     else
      urand_r = u16807h( iseed );
    }while((urand_r >= 1.) || ((1.- urand_r) >= 1.));
     
   return (urand_r);
}


/***********************************************************************
** FUNCTION: u16807d( iseed )                                         **
**                                                                    **
** Purpose:  a linear congruential pseudorandom number generator      **
**           using constant 16807 and modulus (2**31)-1.              **
**           for implementations that don't require double precision, **
**           see s.k. park and k.w. miller, "random numbers           **
**           generators: good ones are hard to find," cacm, 31, 10    **
**           (October 1988), 1192-1201 in correct implementations,    **
**           starting with a seed value of 1 will result in a seed    **
**           value of 1043618065 on call number 10001.                **
**                                                                    **
** Input:                                                             **
**   iseed:  integer.                                                 **
**           chosen from [1,2147483646] on the first call.            **
**           thereafter, the value returned from the last call        **
**                                                                    **
** Output:                                                            **
**   iseed:  integer.                                                 **
**           to be used in the next call.                             **
**  u16807d: real.                                                    **
**           pseudorandom number in (0,1).                            **
***********************************************************************/
float u16807d( iseed )
   int  *iseed;
{
   *iseed = fmod((*iseed)*16807., 2147483647.);
   return( (*iseed) / 2147483647.);
}


/***********************************************************************
**FUNCTION: u16807h( ix )                                             **
**                                                                    **
** Purpose: uniform (0,1) random number generator                     **
**          multiplicative congruential method                        **
**          z(i)=(7**5*z(i-1))(mod 2**31 - 1)                         **
**                                                                    **
**          law & kelton, simulation modeling and analysis,           **
**          mcgrawhill, 1982, p. 227.  there this routine             **
**          is called rand.                                           **
**                                                                    **
**          in correct implementations, starting with a seed          **
**          value of 1 will                                           **
**          result in a seed value of 1043618065 on call number 10001.**
**                                                                    **
** Input:                                                             **
**   ix:    random number seed                                        **
**                                                                    **
** Output:                                                            **
**   ((float)(*ix)*4.656612875e-10)                                   **
***********************************************************************/
float u16807h( ix )
   int *ix;
{
   int a,p,b15,b16,xhi,xalo,leftlo,fhi,k;

   a      = 16807;
   b15    = 32768;
   b16    = 65536;
   p      = 2147483647;
   xhi    = *ix / b16;
   xalo   = (*ix-xhi*b16)*a;
   leftlo = xalo/b16;
   fhi    = xhi*a+leftlo;
   k      = fhi / b15;
   *ix    = (((xalo - leftlo * b16) - p)+(fhi - k * b15) * b16) + k;
   if((*ix) < 0) *ix = (*ix) + p;
   return((float)(*ix) * 4.656612875e-10);
}


/***********************************************************************
** FUNCTION: ppnd(p, ifault)                                          **
**                                                                    **
** Purpose:  Compute the inversed distribution function of a          **
**           standard normal distribution that is set to the          **
**           value of z satisfying P(Z<z) = p. therefore,             **
**           0 < p < 1. ifault = 0 means that all is well.            **
**                                                                    **
** Input:                                                             **
**           p:      the percentage point to evaluate                 **
**                                                                    **
** Output:                                                            **
**           ppnd:   the inverse cdf                                  **
**           ifault: error indicator                                  **
***********************************************************************/
float ppnd( p, ifault )
   float p;
   int   *ifault;
{
   float  ppnd1,
          q,
          zero   = 0.,
          split  = 0.42,
          half   = 0.5,
          one    = 1.;
   double r,
          a0     =   2.50662823884,
          a1     = -18.61500062529,
          a2     =  41.39119773534,
          a3     = -25.44106049637,
          b1     =  -8.47351093090,
          b2     =  23.08336743743,
          b3     = -21.06224101826,
          b4     =   3.13082909833,
          c0     =  -2.78718931138,
          c1     =  -2.29796479134,
          c2     =   4.85014127135,
          c3     =   2.32121276858,
          d1     =   3.54388924762,
          d2     =   1.63706781897;

   *ifault = 0;
   q       = p - half;
   if( fabs(q) > split )
    {
     r = p;
     if ( q > zero ) r = one - p;
     if ( r <= zero )
      {
       *ifault = 1;
       ppnd1   = zero;
       return(ppnd1);
      }
     else
      {
       r       = sqrt(-log(r));
       ppnd1   = ((( c3 * r + c2 ) * r + c1 ) * r + c0 );
       ppnd1   = ppnd1 / (( d2 * r + d1 ) * r + one );
       if ( q < 0 ) ppnd1 = -ppnd1;
        return(ppnd1);
      }
    }
   else
    {
     r     = q * q;
     ppnd1 = q * ((( a3 * r + a2 ) * r + a1 ) * r + a0 );
     ppnd1 = ppnd1 / (((( b4 * r + b3 ) * r + b2 ) * r + b1 ) * r + one );
     return( ppnd1 );
    }
}
