#include <stdio.h>
#include <math.h>

double ppnd();
void ndtr();
void finv(int id,double *parm,double u,double *x);
void rweibull(double *parm,double u,double *x);
void rtriangular(double *parm,double u,double *x);
void rlognormal(double *parm,double u,double *x);
void rgamma(double *parm,double u,double *x,int *ifault);
void normal(double *parm,double u,double *x);
void RT(double T,double DF,double DELTA,double *TNC,double *DENST,
        int *IFAULT);
void up_recur(double *a,double b,double *en,double *xodd,double *xeven,
              double *godd,double *geven,double x,double *p,double *q,
              double *beta,double *beta2,double amode,double *tnc,
              double *denst,double errmax,double itrmax);
void down_recur(double *a,double b,double *en,double *xodd,double *xeven,
                double *godd,double *geven,double x,double *p,double *q,
                double *beta,double *beta2,double amode,double *tnc,
                double *denst,double errmax,double itrmax);
double ppchi2(double p,double v,double g,int *ifault);
double gammad(double X,double P,int *ifault);
double gammln(double xx);
double tinv(double u,double df,double delta,int *ifault,int *i);
double anordf(double z);
double betai(double a,double b,double *gammln_a,double x);
double betacf(double a,double b,double x);
double xinbta(double p,double q,double beta,double alpha,int *ifault);
double betain(double,double,double,double,int *);
double F_inv(double u,double df1,double df2,int *ifault);



void finv(int id,double *parm,double u,double *x)
{
   int ifault, i;
   double df, delta, beta, y, g;

   /*  Generate marginal random variates. */
   if (id == 1)                              /* normal r.v. */
      normal(parm,u,x);
   if (id == 2)
      *x = parm[0] * (-log((double)1.-u));   /* exponential r.v. */
   if (id == 3)
      rgamma(parm,u,x,&ifault);              /* gamma r.v. */
   if ( id ==4)
   {
      y = xinbta(parm[2],parm[3],beta,u,&ifault);
      *x=parm[0] + (parm[1]-parm[0]) * y;    /* beta r.v. */
   }
   if (id == 5)
      rweibull(parm,u,x);                    /* weibull r.v. */
   if (id == 6)
      *x=F_inv(u,parm[0],parm[1],&ifault);   /* F r.v. */
   if (id == 7)
      *x=tinv(u,parm[0],parm[1],&ifault,&i); /* t r.v. */
   if (id == 8)
      rlognormal(parm,u,x);                  /* lognormal r.v. */
   if (id == 9)
      rtriangular(parm,u,x);                  /* triangular r.v. */
   if (id == 10)
   {
      g = gammln( parm[0] / 2.);      /* ln(gamma(parm[0]/2.0)) */
      *x = ppchi2(u, parm[0], g, &ifault);    /* chi-square r.v. */
   }
   if (id == 11)
   {
      *x = parm[0] + (parm[1]-parm[0]) * u;   /* uniform r.v. */
   }
}


void rweibull(double *parm,double u,double *x)

/*   Purpose: Use the Cumulative Distribute Function of Weibull
              distribution F(*x)=u to get the inverse function
              *x=inv(F(u)).
     Author : Huifen Chen, Department of Industrial  Engineering,
              Da-Yeh Institute of Technology,Chang-Hw,TAIWAN.
              Chung-Gong Jeng,Department of Industrial Engineering,
              Da-Yeh Research student,Chang-Hw,TAIWAN.
     Date   : August 23, 1995.
     Input:
            parm: weibull distribution's parameters; parm[0] is the shape
                  parameter and parm[1] is the scale parameters.  the
                  density function f(x) is proportional to
                       x**(parm[0]-1)*exp{-(x/parm[1])**alpha} .
            u:    percentage point to evaluate.
     Output:
            x:    100u% percentile of weibull distribution             */

{
     *x = parm[1] * pow(-log((double)(1.0-u)),(double)(1.0/parm[0])) ;
}


void rtriangular(double *parm,double u,double *x)

/*  Purpose: Generate triangular(l,m,u) random variates, where l, m, u
              are lower bound, mode, and upper bound respectively, using
              the inverse transfermation method, i.e., x=F^{-1}(u).
    Author : Huifen Chen and Chung-Gong Jeng, Department of Industrial
              Engineering, Da-Yeh Institute of Technology,Chang-Hw,TAIWAN.
    Date   : September 3, 1995.
    Input:
             parm: parm[0] is the lower bound l, parm[1] is the mode m,
                   and parm[2] is the upper bound u.
             u:    percentage point to evaluate.
    Output:
             x:    100u% percentile of Triangular distribution             */

{
     double left;

     left = (parm[1] - parm[0]) / (parm[2] - parm[0]);
     if (u <= left)
          *x = parm[0] + sqrt(u*(parm[2]-parm[0])*(parm[1]-parm[0]));
     else
          *x = parm[2] - sqrt((1.0-u)*(parm[2]-parm[0])*(parm[2]-parm[1]));
}


void normal(double *parm,double u,double *x)
{
    int ifault;
    *x = parm[0] + parm[1] * ppnd(u,&ifault);
}


void rlognormal(double *parm,double u,double *x)
/*  Purpose: Generate a lognormal univariate using the inverse transformation
              method, i.e., x = F^{-1}(u).
    Author : Huifen Chen and Chung-Gong Jeng, Department of Industrial
              Engineering, Da-Yeh Institute of Technology,Chang-Hwa,TAIWAN.
    Date   : September 3, 1995.
    Input:
            parm: Lognormal distribution's parameters where parm[0] is the
                  lower bound of lognormal and parm[1] and parm[2] are
                  the mean and standard deviation of ln(X - parm[0]).
            u:    percentage point to evaluate.
    Output:
            x:    100u% percentile of Lognormal distribution             */
{
     double z;
     int   ifault;

     z  = ppnd(u,&ifault);
     *x = parm[0] + exp( parm[1] + parm[2]*z);
}


void rgamma(double *parm,double u,double *x,int *ifault)

/*  Purpose: Compute the u*100% percentage point of gamma distributions,
               denoted by Gamma(alpha, beta), whose shape and scale
               parameters are alpha and beta, respectively.  The
               density function f(x) is proportional to
                       x**(alpha-1) * exp{-x/beta}.
    Author: Huifen Chen and Chung-Gong Jeng, Department of Industrial
            Engineering, Da-Yeh Institute of Technology., TAIWAN.
            September, 1995.
    Input:
        u:     percentage.
        parm:  array of gamma parameters, parm[0] = alpha and parm[1] = beta
    Output:
        x:      the u*100% percentage point of gamma(alpha, beta).
        ifault: error indicator:
                0 = no error,
                1 = infeasible parameter,
                2 = error from chi-square inverse.
    Routines called:
        gammln:  computing the logarithm of gamma function
        ppchi2:  computing percentage point of chi-square distributions  */

{
   int   ierror;
   double v, g, chi2;

   *ifault = 0;
   /* ...check the feasibility of alpha and beta. */
   if((parm[0] <= 0.) || (parm[1] <= 0.))  *ifault = 1;

   /* ...special case: exponential distribution */
   if (parm[0] == 1.)
   {
      *x = parm[1] * (-log((double)1.-u));
      return;
   }

   /* ...compute the gamma(alpha, beta) inverse.                   *
    *    ...compute the chi-square inverse with 2*alpha degrees of *
    *       freedom, which is equivalent to gamma(alpha, 2).       */
   v = 2.0 * parm[0];
   g = gammln( parm[0] );
   chi2 = ppchi2( u,v,g,&ierror );
   if (ierror != 0)  *ifault = 2 ;

   /* ...transfer chi-square to gamma. */
   *x = parm[1] * chi2 / 2.0;
   return;
}



double  ppchi2(double p,double v,double g,int *ifault)

/*  Algorithm AS 91   Appl. Statist. (1975) Vol.24, P.35

    To evaluate the percentage points of the chi-squared
    probability distribution function.

    p must lie in the range 0.000002 to 0.999998, /$ percentage $/
    v must be positive,   /$ degrees of freedom $/
    g must be supplied and should be equal to
      ln(gamma(v/2.0))

    Incorporates the suggested changes in AS R85 (vol.40(1),
    pp.233-5, 1991) which should eliminate the need for the limited
    range for p above, though these limits have not been removed
    from the routine.
    If IFAULT = 4 is returned, the result is probably as accurate as
    the machine will allow.

    Auxiliary routines required: PPND = AS 111 (or AS 241) and
                                 GAMMAD = AS 239.                    */
{
      int    i,maxit=500,if1;
      double aa, e, ppch, zero, half, one,
             two, three, six, pmin, pmax, c1, c2, c3, c4, c5, c6, c7,
             c8, c9, c10, c11, c12, c13, c14, c15, c16, c17, c18, c19,
             c20, c21, c22, c23, c24, c25, c26, c27, c28, c29, c30,
             c31, c32, c33, c34, c35, c36, c37, c38, a, b, c, ch, p1, p2,
             q, s1, s2, s3, s4, s5, s6, t, x, xx;

      aa      = 0.6931471806;
      e       = 0.0000005;
      pmin    = 0.000002;
      pmax    = 0.999998;
      zero    = 0.0;
      half    = 0.5;
      one     = 1.0;
      two     = 2.0;
      three   = 3.0;
      six     = 6.0;
      c1      = 0.01;
      c2      = 0.222222;
      c3      = 0.32;
      c4      = 0.4;
      c5      = 1.24;
      c6      = 2.2;
      c7      = 4.67;
      c8      = 6.66;
      c9      = 6.73;
      c10     = 13.32;
      c11     = 60.0;
      c12     = 70.0;
      c13     = 84.0;
      c14     = 105.0;
      c15     = 120.0;
      c16     = 127.0;
      c17     = 140.0;
      c18     = 1175.0;
      c19     = 210.0;
      c20     = 252.0;
      c21     = 2264.0;
      c22     = 294.0;
      c23     = 346.0;
      c24     = 420.0;
      c25     = 462.0;
      c26     = 606.0;
      c27     = 672.0;
      c28     = 707.0;
      c29     = 735.0;
      c30     = 889.0;
      c31     = 932.0;
      c32     = 966.0;
      c33     = 1141.0;
      c34     = 1182.0;
      c35     = 1278.0;
      c36     = 1740.0;
      c37     = 2520.0;
      c38     = 5040.0;

     /* ...test arguments and initialise  */
      ppch  = -one;
      *ifault = 1;
      if ((p < pmin) || (p > pmax))
          return(ppch);
      *ifault = 2;
      if (v <= zero)
          return(ppch);
      *ifault = 0;
      xx = half * v;
      c = xx - one;

      /* ...starting approximation for small chi-squared */

      if (v >= (-c5 * log(p)))
      {
         /*....starting approximation for v less than or equal to 0.32 */
         if (v > c3)
         {
            /* call to algorithm AS 111 - note that p has been tested above.
               AS 241 could be used as an alternative.   */
            x = ppnd(p, &if1);

            /* starting approximation using Wilson and Hilferty estimate */

            p1 = c2 / v;
            ch = v * pow((x * sqrt(p1) + one - p1),3.0);

            /* starting approximation for p tending to 1  */

            if (ch > (c6 * v + six))
               ch = -two * (log(one-p) - c * log(half * ch) + g);
         }
         else
         {
            ch = c4;
            a = log(one-p);
            do{  q = ch;
                 p1 = one + ch * (c7+ch);
                 p2 = ch * (c9 + ch * (c8 + ch));
                 t = -half + (c7 + two * ch) / p1 - (c9 + ch * (c10 +
                    three * ch)) / p2;
                 ch = ch - (one - exp(a + g + half * ch + c * aa) *
                      p2 / p1) / t;
            }while(fabs((double)q / ch - one) > c1);
         }
      }
      else
      {
         ch = pow( (p * xx * exp(g + xx * aa)),(one/xx) );
         if (ch < e)
         {
            ppch = ch;
            return(ppch);
         }
      }

      /*....call to algorithm AS 239 and calculation of seven term
            Taylor series    */
      for(i=1;i <= maxit;i++)
      {
         q = ch;
         p1 = half * ch;
         p2 = p - gammad(p1, xx, &if1);
         if( if1 != 0 )
         {
            *ifault=3;
            return(ch);
         }
         else
         {
            t  = p2 * exp(xx * aa + g + p1 - c * log(ch));
            b  = t / ch;
            a  = half * t - b * c ;
            s1 = (c19 + a * (c17 + a * (c14 + a * (c13 + a * (c12 +
                 c11 * a))))) / c24;
            s2 = (c24 + a * (c29 + a * (c32 + a * (c33 + c35 *
                 a)))) / c37 ;
            s3 = (c19 + a * (c25 + a * (c28 + c31 * a))) / c37;
            s4 = (c20 + a * (c27 + c34 * a) + c * (c22 + a * (c30 +
                 c36 * a))) / c38;
            s5 = (c13 + c21 * a + c * (c18 + c26 * a)) / c37;
            s6 = (c15 + c * (c23 + c16 * c)) / c38;
            ch = ch + t * (one + half * t * s1 - b * c * (s1 - b *
                 (s2 - b * (s3 - b * (s4 - b * (s5 - b * s6))))));
            if (fabs((double)q / ch - one) > e)
            {
               ppch = ch;
               return(ppch);
            }
         }
      }
      *ifault = 4;
      ppch = ch;
      return(ppch);
}



double F_inv(double u,double df1,double df2,int *ifault)
{
      double y,beta,x;

      *ifault=1;
      if ( (u < 0.) || (u > 1.) )
         return;
      *ifault=2;
      if ( (df1 <= 0.) || (df2 <= 0.) )
         return;
      *ifault=0;
      y = xinbta(df1/2,df2/2,beta,u,ifault);
      x = (df2/df1) * ( y /(1.-y) );
      return(x);
}


double  gammad(double X,double P,int *ifault)
/*  Revision: replace auxiliary functions ALNGAM by gammln and
              ALNORM by anordf, since ALNORM is written in
              FORTRAN 66.  huifen, 11/1/94.

    ALGORITHM AS239  APPL. STATIST. (1988) VOL. 37, NO. 3
    Computation of the Incomplete Gamma Integral
    /$ integral of function f(t)= t**(p-1) * exp{-t} in [0,x],
         where x >= 0 and p > 0.    fen, 11/1/94            $/

    Auxiliary functions required: ALNGAM = logarithm of the gamma
    function (AS245), and ALNORM = algorithm AS66                 */
{
   double PN1, PN2, PN3, PN4, PN5, PN6, TOL, OFLO,
          XBIG, ARG, C, RN, A, B, ONE, ZERO,GAMMADV,
          AN, TWO, ELIMIT, PLIMIT, THREE, NINE,d;
   double min;

   ZERO    = 0.0;
   ONE     = 1.0;
   TWO     = 2.0;
   OFLO    = pow(10.0,37.0);
   THREE   = 3.0;
   NINE    = 9.0;
   TOL     = pow(10.0,-14.0);
   XBIG    = pow(10.0,8.0);
   PLIMIT  = 1000.0;
   ELIMIT  = -88.0;
   GAMMADV = ZERO;

   /*... Check that we have valid values for X and P  */

   if ((P <= ZERO) || (X < ZERO))
   {
      *ifault = 1;
      return(GAMMADV);
   }
   *ifault = 0;
   if (X == ZERO)
      return(GAMMADV);

   /*... Use a normal approximation if P > PLIMIT    */

   if (P > PLIMIT)
   {
      PN1 = THREE * sqrt(P) * (pow((X / P) ,(ONE / THREE)) + ONE /
            (NINE * P) - ONE);
      ndtr(PN1,&P,&d);
      return(P);
   }

   /*... If X is extremely large compared to P then set GAMMAD = 1  */
   if (X > XBIG)
   {
      GAMMADV = ONE;
      return(GAMMADV);
   }
   if ((X <= ONE) || (X < P))
  /*....Use Pearson's series expansion.
        (Note that P is not large enough to force overflow in gammln).
        No need to test IFAULT on exit since P > 0.   */
   {
       ARG = P * log(X) - X - gammln(P + ONE);
       C = ONE;
       GAMMADV = ONE;
       A = P;
       do{  A = A + ONE ;
            C = C * X / A;
            GAMMADV = GAMMADV + C ;
       }while(C > TOL);
       ARG = ARG + log(GAMMADV);
       GAMMADV = ZERO;
       if (ARG >= ELIMIT) GAMMADV = exp(ARG);
   }
        else
        /*.... Use a continued fraction expansion */
        {
           ARG = P * log(X) - X - gammln(P);
           A = ONE - P;
           B = A + X + ONE;
           C = ZERO;
           PN1 = ONE;
           PN2 = X;
           PN3 = X + ONE;
           PN4 = X * B ;
           GAMMADV = PN3 / PN4;
           while(1)
           {
              A = A + ONE;
              B = B + TWO;
              C = C + ONE;
              AN = A * C ;
              PN5 = B * PN3 - AN * PN1;
              PN6 = B * PN4 - AN * PN2;
              if (fabs((double)PN6) > ZERO)
              {
                 RN = PN5 / PN6 ;
                 min = TOL * RN;
                 if (min > TOL) min = TOL;
                 if (fabs((double)GAMMADV - RN) <= min)
                    break;
                 GAMMADV = RN ;
              }
              PN1 = PN3;
              PN2 = PN4;
              PN3 = PN5;
              PN4 = PN6;
              if (fabs((double)PN5) >= OFLO)
         /*.... Re-scale terms in continued fraction if terms are large */
              {
                  PN1 = PN1 / OFLO;
                  PN2 = PN2 / OFLO;
                  PN3 = PN3 / OFLO;
                  PN4 = PN4 / OFLO;
              }
           }
           ARG = ARG + log(GAMMADV);
           GAMMADV = ONE;
           if (ARG >= ELIMIT)
               GAMMADV = ONE - exp(ARG);
         }
        return(GAMMADV);
}


double gammln(double xx)

/***********************************************************************
**   revised from "Numerical Recipes" by huifen, may, 1992            **
**   purpose: returns the logarithm of gamma function at xx.  the     **
**            internal arithmetic will be done in double precision.   **
**            if xx is less than one, the reflection formula (6.1.4)  **
**            in "Numerical Recipes" is used.                         **
**   reference: function gammln in "Numerical Recipes" by Press,      **
**              Flannery, Teukolsky and Vetterling                    **
***********************************************************************/
{
    int j;
    double cof[6];
    double half=0.5,one=1.0,fpf=5.5,stp=2.50662827465;
    double  x,tmp=0.0,ser=0.0,tt=0.0,tgammln=0.0;

    cof[0] =  76.18009173;
    cof[1] = -86.50532033;
    cof[2] =  24.01409822;
    cof[3] = -1.231739516;
    cof[4] =  0.001208580032;
    cof[5] = -0.000005363825;

    if (xx == 0.0)
    {
       printf(" Error in gammln(xx): xx can not be zero\n");
       return;
    }
    if ((xx == 1.0) || (xx == 2.0))
    return( tgammln );

    x   = xx - one;
    if (xx < one)
        x = -x;

    tmp = x + fpf;
    tmp = (x+half)*log(tmp) - tmp;
    ser = one;
    for(j = 0;j <= 5;j++)
    {
        x   = x + one;
        ser = ser + cof[j] / x ;
    }
    tgammln = tmp + log(stp * ser);
    if (xx < one)
    {
        tmp    = 3.141592654*(one - xx) ;
        tt     = sin(tmp);
        tmp    = fabs((double)tmp / tt);
        tgammln = log(tmp) - tgammln ;
    }
    return(tgammln);
}



/*.....bruce schmeise and huifen chen, june 1992
**     purpose: compute the inverse of the cdf of noncentral t dist.
**       input:
**         u    : cdf of noncentral t dist.  (value)
**         df   : degree of freedom of noncentral t dist.   (value)
**         delta: noncentral parameter of noncentral t dist.  (value)
**       output:
**         tinv_r: the inverse of cdf   (value)
**         ifault: fault indicator      (point)
**         i     : number of iterations (point)
**
**.....in the support routines, the original APPLIED STATISTICS code
**       is in UPPER CASE.  our modifications are in lower case.
*/

double tinv(double u,double df,double delta,int *ifault,int *i)
{
  double ppnd();
  void RT();
  int  itrmax,lower,upper,twobd,ibound;
  double tinv_r,rn,sq,funct, t_l,t_u,dt,tnc,denst,error;

      itrmax  = 1000;
      lower   = 1;
      upper   = 2;
      twobd   = 3;
      *i      = 0;
      *ifault = 0;

/*
**.....get the initial guess.  reference is "Continuous univariate
**       distributions-2" by johnson and kotz, p 207.
*/
      tinv_r = 0.;
      rn     = ppnd(u,ifault);
      sq     = 1. + .5*((delta*delta) - (rn*rn)) / df;
    if (sq >= 0.)
      tinv_r = (delta + rn*sqrt(sq)) / (1.- .5 * (rn*rn) / df);
    if (u > .5 && tinv_r < delta)
      tinv_r = delta;

    RT(tinv_r,df,delta,&tnc,&denst,ifault);
    funct = tnc - u;
/*
**....if the function value is close to zero, return.
*/
      if (fabs((double)funct) < 1.E-6) return(tinv_r);

/*
**.....define the bound indicator, ibound.
**        ibound = lower   ==> only lower bound exists
**               = upper   ==> only upper bound exists
**               = twobd   ==> have lower and upper bounds
*/
      if (funct < 0.)
       {
         ibound = lower;
         t_l    = tinv_r;
       }
      else
       {
         ibound = upper;
         t_u    = tinv_r;
       }

/*....Compute the next iterate  */
      if (denst != 0.)
      {
         /*...use newton's method.   */
         dt   = funct / denst;
         tinv_r = tinv_r - dt;
      }
      else
      {
         /*...tinv_r is either too big or too small.  set the next 
         **   iterate to be the average of delta and tinv_r
         */
         dt     = (delta - tinv_r) / 2.;
         tinv_r = (delta + tinv_r) / 2.;
      }

   for((*i)=1 ; (*i)<=itrmax ; (*i)++)
   {
         RT(tinv_r,df,delta,&tnc,&denst,ifault);
         funct = tnc - u;
/*
**........update ibound, lower bound and upper bound
*/
         if (funct < 0.)
         {
             if (ibound == upper)
             {
                 ibound = twobd;
                 t_l    = tinv_r;  
             }
             if (tinv_r > t_l)
                 t_l = tinv_r;
             tinv_r = t_l;
         } else { 
             if (ibound == lower)
             {
                 ibound = twobd;
                 t_u    = tinv_r;
             }
             if (tinv_r <= t_u)  t_u = tinv_r;
             tinv_r = t_u;
         }
/*
**........determine which method to use, either newton or bisection
*/
         if (ibound == twobd && ((denst*(tinv_r-t_l)-tnc)*
            (denst*(tinv_r-t_u)-tnc) >= 0.))
         {
/*...........if the solution is bounded and the next newton
**           iterate lies outside the bounds, use bisection method.
*/
            dt     = (t_u - t_l) / 2.;
            tinv_r = (t_u + t_l) / 2.;
         }
         else if(denst == 0.)   
         {
/*...........tinv_r is either too big or too small.  set the next
**           iterate to be the average of delta and tinv_r
*/
            dt     = (delta - tinv_r) / 2.;
            tinv_r = (delta + tinv_r) / 2.;
         }
         else
/*...........use newton's method */
         {
            dt     = funct / denst;
            tinv_r = tinv_r - dt;
         }

         error = dt / tinv_r;

         if (fabs(error) < 1.E-6 || fabs(funct) < 1.E-6) return(tinv_r);
   }
   return(tinv_r);
}


/*
**.....huifen chen and bruce schmeiser, june 1992
**       update: january 1994.
**               correct the computation of density function.
**     purpose: evaluate the cdf and density of non-central t dist.
**       input:
**         t    : the point to evaluate (value)
**         df   : degree of freedom     (value)
**         delta: non-central parameter (value)
**       output:
**         tnc: cumulative distribution at point t (point)
**         denst: the density at point t           (point)
**         ifault: the error indicator             (point)
**     reference: ALGORITHM AS 243  APPL. STATIST. (1989), VOL.38, NO. 1
*/

void RT(double T,double DF,double DELTA,double *TNC,double *DENST,int *IFAULT)
{
   double gammln();
   double betai();
   double anordf();
   void down_recur();
   void up_recur();
   double A, ALBETA, B,  DEL, EN, ERRMAX, PII, TMP, AMODE,
         GEVEN, GODD, HALF, ITRMAX, LAMBDA, ONE, P, PP, Q, QQ,
         TT, TWO, X, XEVEN, XODD, ZERO, RT_R, ALN_HALF, SQRT_TWO,
         GAMMLN_A, GAMMLN_J1, GAMMLN_B, ALBETA2, XX, BETA, BETA2,
         AA, BB, EEN, XXEVEN, XXODD, GGEVEN, GGODD, BBETA, BBETA2,
         ITR_LEFT;
   double jplus=0.;
   int NEGDEL, J;

/*
**     Note - ITRMAX and ERRMAX may be changed to suit one's needs.
*/
      ITRMAX  = 5000.1;
      ERRMAX = 1.E-07;
      ZERO   = 0.0;
      HALF   = 0.5;
      ONE    = 1.0;
      TWO    = 2.0;
      ALN_HALF = -.693147181;
      SQRT_TWO = 1.414213562;
      PII       = 3.141592654;

/*
**.....initialize the summation value
*/
      *TNC   = ZERO;
      *DENST = ZERO;
/*
**.....if the degree of freedom is not positive return
*/
      *IFAULT = 2;
      if (DF <= ZERO)
         return;
      *IFAULT = 0;
/*
**.....when t is zero
*/
    if (T == 0.)
    {
/*........if delta is less than tweleve, anordf is not negligible; */
        if (DELTA < 12.) *TNC = anordf( -DELTA );
        TMP    = -0.5*DELTA*DELTA + gammln((DF+1.)/2) - gammln(DF/2.);
        *DENST = exp( TMP ) / sqrt( DF * PII );
        return;
    }


      TT = T;
      DEL = DELTA;
      NEGDEL = 0;

      if (T < ZERO)
      {
         NEGDEL = 1;
         TT = -TT;
         DEL = -DEL;
      }
/*
**     Initialize twin series (Guenther, J. Statist. Computn. Simuln.
**     vol.6, 199, 1978).
*/
      X = T * T / (T* T + DF);
      LAMBDA = DEL * DEL;

/*.....start from the mode of poisson
*/
      AMODE = LAMBDA / TWO;
      J     = (int)AMODE;
      EN    = J;
      A     = J + HALF;
      B     = HALF * DF;
      jplus   = (double)(J + 1.);
      XODD  = betai(A, B, &GAMMLN_A, X);
      XEVEN = betai(jplus, B, &GAMMLN_J1, X);
      if (DEL == 0.)
         P = .5;
      else
         P = exp(ALN_HALF - AMODE + J*log(AMODE) - GAMMLN_J1);

      Q   = (P*DEL / (SQRT_TWO*A)) * exp(GAMMLN_J1 - GAMMLN_A);
      *TNC = P * XODD + Q * XEVEN;

      GAMMLN_B = gammln(B);

/*.....compute the tmp = logarithm of x**a * (1.-x)**b
*/
      TMP      = 2.* A * log(TT) + B * log(DF) - (A+B) * log(TT*TT+DF);
      ALBETA   = gammln(A + B) - gammln(A+1.) - GAMMLN_B;
      GODD     = exp(ALBETA + TMP);
      ALBETA2  = gammln(A+B+HALF) - gammln(A+1.5) - GAMMLN_B;
      GEVEN    = exp(ALBETA2 + TMP) * sqrt(X);

/*.....compute xx=log(x*(1-x)).  note 1-x = df / (tt**2+df)
*/
      XX       = 2.*log(TT)+log(DF) - 2. * log( (TT*TT) + DF);

/*.....compute beta = godd*a/(x*(1-x)); beta2 = geven*(a+.5)/(x*(1-x)).
*/
      BETA     = exp( ALBETA + TMP + log(A) - XX );
      BETA2    = exp( ALBETA2 + TMP + log(A+HALF) - XX );

      *DENST    = P * BETA + Q * BETA2;

      if (J > 0)
      {
       /*........sum the items left to jth item */

         AA = A;
         BB = B;
         EEN = EN;
         XXODD = XODD;
         XXEVEN = XEVEN;
         GGODD = GODD;
         GGEVEN = GEVEN;
         PP     = P;
         QQ     = Q;
         BBETA  = BETA;
         BBETA2 = BETA2;
         down_recur(&AA,BB,&EEN,&XXODD,&XXEVEN,&GGODD,&GGEVEN,X,&PP,&QQ,
                    &BBETA,&BBETA2,AMODE,TNC,DENST,ERRMAX,ITRMAX);
      }
/*
**.....sum the items right to jth item
*/
      ITR_LEFT = ITRMAX - (AMODE - EEN);
      up_recur(&A,B,&EN,&XODD,&XEVEN,&GODD,&GEVEN,X,&P,&Q,&BETA,&BETA2,
               AMODE,TNC,DENST,ERRMAX,ITR_LEFT);

      *IFAULT = 0;
      EN     = EN - EEN;
      if (EN > ITRMAX) (*IFAULT) = 1;

      *DENST = *DENST * 2.* (1.-X) * sqrt((X- (X*X) ) / DF);
/*
**.....if del is less than tweleve, anordf is not negligible
*/
      if (DEL < 12.) *TNC = *TNC + anordf( -DEL );

      if (NEGDEL) *TNC = ONE - *TNC;
      if (*TNC > 1.) *TNC = 1.;
      if (*TNC < 0.) *TNC = 0.;
         return;
}



void up_recur(double *a,double b,double *en,double *xodd,double *xeven,
              double *godd,double *geven,double x,double *p,double *q,double *beta,
              double *beta2,double amode,double *tnc,double *denst,
              double errmax,double itrmax)
{
 double half, one, c1, c2, rerror, add;
       half = 0.5;
       one  = 1.0;

/*
**     Repeat until convergence
*/
l10:
      *en    = (*en) + one;
      *xodd  = (*xodd) - (*godd);
      *xeven = (*xeven) - (*geven);
      *p     = (*p) * amode / (*en);
      *q     = (*q) * amode / ((*en) + half);
      add    = (*p) * (*xodd) + (*q) * (*xeven);
      *tnc   = *tnc + add;

      *a     = (*a) + one;
      c1     = x * ((*a) + b - one) / (*a);
      c2     = x * ((*a) + b - half) / ((*a) + half);
      *godd  = (*godd) * c1;
      *geven = (*geven) * c2;

      *beta  = (*beta) * ((*a) + b - one) / ((*a) - one);
      *beta2 = (*beta2) * ((*a) + b - half) / ((*a) - half);
      *denst = (*denst) + (*p) * (*beta) + (*q) * (*beta2);
      rerror = add / (*tnc);
      if ( (rerror > errmax) && (((*en) - amode) <= itrmax) ) goto l10;
         return;
}



void down_recur(double *a,double b,double *en,double *xodd,double *xeven,
                double *godd,double *geven,double x,double *p,double *q,
                double *beta,double *beta2,double amode,double *tnc,
                double *denst,double errmax,double itrmax)
{
  double half, one, c1, c2, add, rerror;
         half = 0.5;
         one  = 1.0;

/*
**     Repeat until convergence
*/
l10:
      c1     = (*a) / (((*a) + b - 1.) * x);
      c2     = ((*a) + half) / (((*a) + b - half) * x);
      *godd  = (*godd) * c1;
      *geven = (*geven) * c2;
      *xodd  = (*xodd) + (*godd);
      *xeven = (*xeven) + (*geven);
      *p     = (*p) * (*en) / amode;
      *q     = (*q) * ((*en) + half) / amode;
      add    = (*p) * (*xodd) + (*q) * (*xeven);
      *tnc   = (*tnc) + add;

      *beta  = (*beta) * ((*a) - one) / (((*a) + b - 1.) * x);
      *beta2 = (*beta2) * ((*a) - half) / (((*a) + b - half) * x);
      *denst = (*denst) + (*p) * (*beta) + (*q) * (*beta2);
      rerror = add / (*tnc);
      *en    = (*en) - one;
      *a     = (*a) - one;
      if ( ((*en) > 0.) && (rerror >= errmax)
          && ((amode - (*en)) <= itrmax) ) goto l10;
         return;
}



/*     standard normal cdf
**     ibm scientific subroutine package, 1967, page 78.
*/
double anordf( double z )
{
  double az,t,d,p,anordf_r;
      az = fabs(z);
      t = 1./(1.+.2316419*az);
      d = .3989423 * exp(-z*z*.5);
      p = 1. - d*t*((((1.330274*t - 1.821256)*t + 1.781478)*t
          - .3565638)*t + .3193815);
      if (z < 0.)  p = 1. - p;
      anordf_r = p;
      return(anordf_r);
}



/*     purpose: returns the incomplete beta(a,b) function, ie the cdf
**              of beta(a,b) at x.
**     from   : "Numberical Recipes" by Press, Flannery, Teukolsky
**              and Vetterling.
*/
double betai(double a,double b,double *gammln_a,double x)
{
  double betacf();
  double gammln();
  double betai_r,bt;
      if ((x < 0.) || (x > 1.))
        printf("\n bad argument x in betai; x is between 0. and 1.");
      *gammln_a = gammln(a);
      if ((x == 0.) || (x == 1))
          bt = 0.;
      else
      {   bt = exp(gammln(a + b) - (*gammln_a) - gammln(b) +
               a * log(x) + b * log(1.-x));
      }
      if (x < ((a + 1.)/(a + b + 2.)) )
      {
          betai_r = bt * betacf(a, b, x) / a;
          return (betai_r);
      }
      else
      {   betai_r = 1. - bt * betacf(b, a, (1.-x)) / b;
          return (betai_r);
      }
}



/*.....purpose: Returns continued fraction for incomplete beta function,
**              used by BETAI
**     from   : "Numberical Recipes" by Press, Flannery, Teukolsky
**              and Vetterling.
*/
double betacf(double a,double b,double x)
{
      int itmax, m, em, tem;
      double  eps, am, bm, az, qab, qap, qam, bz, betacf_r, d, ap, bp,
             app, bpp, aold;

      am = 1.;
      bm = 1.;
      az = 1.;
      qab = a + b;
      qap = a + 1.;
      qam = a - 1.;
      bz  = 1. - qab * x / qap;
      itmax = 100;
      eps = 3.e-7;

   for (m=1 ; m<=itmax ; m++)
     {
          em = m;
          tem = em + em;
          d   = em*(b - m)*x / ((qam+tem)*(a+tem));
          ap = az + d*am;
          bp = bz + d*bm;
          d  = -(a+em)*(qab+em)*x / ((a+tem)*(qap+tem));
          app = ap + d*az;
          bpp = bp + d*bz;
          aold = az;
          am = ap / bpp;
          bm = bp / bpp;
          az = app / bpp;
          bz = 1.;
          if (fabs(az-aold) < (eps*fabs(az))) goto l1;
     }

     printf("\n a or b too big, or itmax too small for function betacf");
l1:
      betacf_r = az;
      return(betacf_r);
}



/**********************************************************************
** Function:   xinbta(p,q,beta,alpha,ifault)                         **
**                                                                   **
** Purpose:    Compute the inverse of beta distributions with lower  **
**             bound 0, upper bound 1, and shape parameters p and q. **
**                                                                   **
** Precision:  Single precision                                      **
**                                                                   **
** Language:   C                                                     **
**                                                                   **
** Type:       double                                                 **
**                                                                   **
** Input:                                                            **
**             p, q:  shape parameters                               **
**             beta:  log of complete beta function                  **
**             alpha: percetage point to evaluate                    **
**                                                                   **
** Output:                                                           **
**             xinbta_r: the alpha percentile of beta distribution   **
**             ifault:   error indicator                             **
**                                                                   **
** Reference:
**             Algorithm AS 109 Applied Statistics (1977), v.26, no.1**
**             Remark AS R83 and the correction in vol40(1) p.236    **
**                have been incorporated in this version.            **
**             Note: If X~beta(p,q), then 1-X~beta(q,p).  Hence, if  **
**                   alpha > 0.5, the algorithm compute the (1-alpha)**
**                   percentile of beta(q,p) and then is substracted **
**                   by 1.                                           **
**                                                                   **
** Auxiliary function:
**              BETAIN = algorithm AS63
**********************************************************************/
 double xinbta(double p,double q,double beta,double alpha,int *ifault)
{

/*
     Define accuracy and initialise.
     SAE below is the most negative decimal exponent which does not
     cause an underflow; a value of -308 or thereabouts will often be
     OK in double precision.

     data acu/1.0d-14/                                            */

     int indx;
     double a,b,pp,qq,r,y,g,s,t,h,w,prev,yprev,sq,ACU,xin,adj,tx;
     double xinbta_r = alpha;
     double zero=0.0, one=1.0, two=2.0;
     double three=3.0, four=4.0, five=5.0, six=6.0;

     double IEX,SAE=-37.0, fpu = pow(10.,SAE);
     beta = gammln(p) + gammln(q) - gammln(p+q);       

/*   test for admissibility of parameters                            */

      *ifault = 1;
      if ((p <= zero) || (q <= zero)) return;
      *ifault = 2;
      if ((alpha < zero) || (alpha > one)) return;
      *ifault = 0;
      if ((alpha == zero) || (alpha == one)) return;

/*    change tail if necessary                                       */

      if (alpha <= 0.5)
      {
           a = alpha;
           pp = p;
           qq = q;
           indx = 0;
      }
      else
      {
         a = one-alpha;
         pp = q;
         qq = p;
         indx = 1;
      }

/*     calculate the initial approximation                          */

      r = sqrt(-log(a*a));
      y = r-(2.30753+0.27061*r)/(one+(0.99229+0.04481*r)*r);

      if( (pp > one) && (qq > one))
      {
           r = (y*y-three)/six;
           s = one/(pp+pp-one);
           t = one/(qq+qq-one);
           h = two/(s+t);
           w = y*sqrt(h+r)/h-(t-s)*(r+five/six-two/(three*h));
           xinbta_r = pp/(pp+qq*exp(w+w));
      }
      else
      {
           r = qq+qq;
           t = one/(9.0*qq);
           t = r*pow((one-t+y*sqrt(t)),3.);
           if(t <= zero)
           {
                xinbta_r = one-exp((log((one-a)*qq)+beta)/qq);
                goto L2;
           }
           t = (four*pp+r-two)/t;
           if(t <= one)
           {
                xinbta_r = exp((log(a*pp)+beta)/pp);
                goto L2;
           }
           xinbta_r = one-two/(t+one);
      }
/*     solve for x by a modified newton-raphson method,
       using the function betain                                 */

L2:   r = one-pp;
      t = one-qq;
      yprev = zero;
      sq = one;
      prev = one;
      if(xinbta_r < 0.0001) xinbta_r = 0.0001;
      if(xinbta_r > 0.9999) xinbta_r = 0.9999;
      if(((-5.0/(pp*pp)) - (1.0/(a*a)) - 13.0) > SAE)
         IEX=-5.0/(pp*pp) -1.0/(a*a) - 13.0;
      else
         IEX=SAE;
      ACU = pow(10.0,IEX);
      y = betain(xinbta_r,pp,qq,beta,ifault);

      while(*ifault == 0)
      {
            xin = xinbta_r;
            y = (y-a)*exp(beta+r*log(xin)+t*log(one-xin));
            if((y*yprev) <= zero)
            {
               if(sq > fpu)
                   prev = sq;
               else
                   prev = fpu; 
            } 
            g = one;
            adj = g*y;
            sq = adj*adj;
            while(sq >= prev)
            {
  L1:           g = g/three;
                adj = g*y;
                sq = adj*adj;
            }
            tx = xinbta_r-adj;
            if((tx >= zero) && (tx <= one))
            {
               if((prev <= ACU) || (y*y <= ACU))
               {
                   if (indx)  
                   {
                      xinbta_r = one-xinbta_r;
                   }
                   return((double) (xinbta_r));
               }
               if((tx == zero) || (tx == one))
               goto L1;
              if(tx == xinbta_r)
              {
                  if (indx) 
                  {
                     xinbta_r = one-xinbta_r;
                  }
                  return((double) (xinbta_r));
              }
              xinbta_r = tx;
              yprev = y;
              y = betain(xinbta_r,pp,qq,beta,ifault);
              continue;
            }
            else
               goto L1;
      }
      *ifault = 3;
      return((double) (xinbta_r));
}

 double betain(double x,double p,double q, double beta,int *ifault)
{
/*
     algorithm as 63  appl. statist. (1973), vol.22, no.3

     computes incomplete beta function ratio for arguments
     x between zero and one, p and q positive.
     log of complete beta function, beta, is assumed to be known
*/
/*
     define accuracy and initialise
*/
      int indx,ns;
      double  psq,cx,xx,pp,qq,term,ai,rx,temp,tt;
      double  zero=0.0, one=1.0;
      double acu=pow(10.,-15.);
      double  betain_r=x;
/*
     test for admissibility of arguments
*/
      *ifault=1;
      if((p <= zero) || (q <= zero)) return;
      *ifault=2;
      if((x < zero) || (x > one)) return;
      *ifault=0;
      if((x == zero) || (x == one)) return;
/*
     change tail if necessary and determine s
*/
      psq=p+q;
      cx=one-x;
      if(p >= (psq*x))
      {
           xx=x;
           pp=p;
           qq=q;
           indx=0;
      }
      else
      {
           xx=cx;
           cx=x;
           pp=q;
           qq=p;
           indx=1;
      }
      term=one;
      ai=one;
      betain_r=one;
      ns=(int) qq+cx*psq;
/*
     user soper's reduction formulae.
*/
      rx=xx/cx;
L3:   temp=qq-ai;
      if(ns == 0) rx=xx;
L4:   term=term*temp*rx/(pp+ai);
      betain_r=betain_r+term;
      temp=fabs(term);
      if((temp <= acu) && (temp <= (acu*betain_r)))
      {    
           tt=exp(pp*log(xx)+(qq-one)*log(cx)-beta)/pp;
           betain_r=betain_r*exp(pp*log(xx)+(qq-one)*log(cx)-beta)/pp;
           if(indx) 
           {   betain_r=one-betain_r;
           }
           return(betain_r);
      }
      else
      {
           ai=ai+one;
           ns=ns-1;
          if(ns >= 0) goto L3;
          temp=psq;
          psq=psq+one;
          goto L4;
      }
}
    


