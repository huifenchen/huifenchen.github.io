/***********************************************************************
**Function: rmultvar(iseed,n,np,idist,parm,rho,srfp,chol,rhoz,x,nobs) **
**                                                                    **
**  Purpose:    Generate multivariate random vectors X=(X1,...,Xn)    **
**              such that each Xi has the specified marginal          **
**              distribution Fi, 1<= i <=n, and the correlation       **
**              matrix of X is ( rho(i,j), 1<=i,j<=n ).               **
**                                                                    **
**  Author:     Huifen Chen                                           **
**              Department of Industrial Engineering                  **
**              Da-Yeh Institute of Technology                        **
**              Chang-Hwa, 51505, TAIWAN                              **
**                                                                    **
**  Date:       Febuary, 1996                                         **
**                                                                    **
**  Method:     Use the NORTA (or called 3-step) approach:            **
**                Step 1: Generate a multivariate standard normal     **
**                        vector z=(z1,...,zn) with the (given)       **
**                        correlation matrix rhoz.                    **
**                Step 2: Compute ui = Phi( zi ) for i=1,...,n,       **
**                        where Phi() is the cumulative distribution  **
**                        function of standard normal distributions.  **
**                Step 3: Compute xi = Fi^{-1}(ui), the (ui)*100%th   **
**                        percentile of Xi, for i=1,...,n.            **
**                                                                    **
**              To implement this approach, the Step-1 correlation    **
**              matrix rhoz is needed so that the generated random    **
**              vector X in Step 3 has correlation matrix rho.  We    **
**              solve this stochastic root-finding problem using      **
**              retrospective approximation algorithms proposed by    **
**              Chen and Schmeiser in 1994 (see reference 2).         **
**                                                                    **
**  Precision:  Single precision                                      **
**                                                                    **
**  Language:   C                                                     **
**                                                                    **
**  Type:       void                                                  **
**                                                                    **
**  Input:      Value of n, and pointers to the others are passed.    **
**      iseed:  Random-number seed                                    **
**      n:      Dimension of random vector X                          **
**      np:     Vector of dimension n,                                **
**              np[i] = the number of distribution parameters of      **
**              Fi, i=1,...,n                                         **
**      parm:   Two-dimensional array.  Each parm[i] contains (np[i]) **
**              parameter values of distribution Fi, i=1,...,n        **
**      rho:    The specified correlation matrix of X, nxn            **
**      srfp:   Indicator to stochastic root finding procedure:       **
**                Stochastic root finding, if srfp = 'T';             **
**                No root-finding, otherwise.                         **
**              The srfp is 'T' only when rmultvar() function is      **
**              called first time.                                    **
**      rhoz:   Step-1 correlation matrix, nxn, an input when         **
**              srfp = 'F' and an output otherwise.                   **
**      chol:   Cholesky decomposition of rhoz, nxn, an input when    **
**              srfp = 'F' and an output otherwise.                   **
**                                                                    **
**  Output:                                                           **
**      iseed:  Random-number seed                                    **
**      srfp:   Indicator to stochastic root finding.  Returned       **
**                value is 'F'.                                       **
**      rhoz:   Step-1 correlation matrix, nxn, computed only         **
**              when srfp = 'T'                                       **
**      chol:   Cholesky decomposition of rhoz, computed only         **
**              when srfp = 'T'.                                      **
**      x:      Generated random vector.                              **
**      nobs:   Number of random vectors generated to compute rhoz    **
**                                                                    **
**  Functions called:                                                 **
**      retro:     Stochastic root-finding by retrospective           **
**                 approximation                                      **
**      cholesky:  Cholesky decomposition                             **
**                                                                    **
**  Called by:  Main program                                          **
**                                                                    **
**  References:                                                       **
**           1. Chen, H. (1995).  Multivariate Generation.  In        **
**              Proceedings of the 1995 Chinese Industrial            **
**              Engineering Conference, 839-846.  (Chinese).          **
**           2. Chen, H. and B.W. Schmeiser (1994).  Retrospective    **
**              Approximation Algorithms for Stochastic Root Finding. **
**              Proceedings of the 1994 Winter Simulation Conference, **
**              255-261.                                              **
***********************************************************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
/*
#include <malloc.h>
*/


void rmultvar(long *iseed,int n,int *np,int *idist,double **parm,double **rho,
              char *srfp,double **chol,double **rhoz,double *x,int *nobs);

void rmultvar(long *iseed,int n,int *np,int *idist,double **parm,double **rho,
              char *srfp,double **chol,double **rhoz,double *x,int *nobs)
  {
      int    i,j,         /* Loop counters */
             ifault;      /* Outputs of cholesky function */
      double  **se_rhoz,   /* Estimated standard errors (s.e.) of   *
                           *   Step-1 correlation estimates        */
             se = 0.001,   /* Max. allowed s.e. of Step-1        *
                               correlation estimates, set as 0.01 */
             *z;          /* Multivariate normal generated in Step 1 */

      /**  Open local arrays  **/
     z = (double *)malloc(n*sizeof(*z));
     se_rhoz = (double **)malloc(n*sizeof(*se_rhoz));
     *se_rhoz = (double *)malloc((n*n)*sizeof(**se_rhoz));
     for(i=1;i < n;i++)
        *(se_rhoz+i) = *se_rhoz + i*n;

     /**  Stochastic root finding:                                 ** 
      **    Compute step1-correlation matrix rhoz when srfp = 'T'. **/
  
     if (*srfp == 'F')  goto L3;

     *srfp = 'F';          /*  No stochastic root finding next time */
     for(i=0;i<n;i++)      /*  Initialize matrix rhoz.  */
     {
         rhoz[i][i] = 1.;
         for(j=i+1;j<n;j++)
         {
             rhoz[i][j] = 0.; 
             rhoz[j][i] = 0.;
         }
     }       

     /**  Compute step-1 correlations by solving n(n-1)/2 equations
      **  simultaneously with retrospective approximation algorithms.
      **/ 

     for(i=0;i< n-1;i++)         /* Check whether X is a vector of */
         for(j=i+1;j<n;j++)    /*   independent random variables */
             if (rho[i][j] != 0.0)
                 goto L1;
     goto L2;

L1:  /**  ...If not independent, compute Step-1 correlations.  **/
     /* Solve n(n-1)/2 equations by retrospective appoximation */

     retro(rho,se,iseed,idist,parm,n,rhoz,se_rhoz,nobs);

     /* If corr(xi,xj)=0, set corr(zi,zj)=0. */
     for(i=0;i< n;i++)     
         for(j=i+1;j<n;j++)
             if ( rho[i][j] == 0.0 )  
             {
                 rhoz[i][j] = 0.0;
                 rhoz[j][i] = 0.0;
             }

    
     /**  End computation of rhoz  **/


L2:  /**  Compute the cholesky decomposition chol  **
      **  of rhoz, i.e., chol'*chol=rhoz .         **/

     choleskyf(n,rhoz,chol,&ifault);
     if (ifault != 0)
         printf("Cholesky decomposition has error indicator %d\n",ifault);

L3:
    /**  Given chol, use the NORTA approach to generate a random 
     **  vector X with the specified marginal distributions and  
     **  the specified correlation matrix.                       
     **/                                                         
    multvar(iseed,idist,parm,n,chol,z,x);

     /* free local arrays */    
     free( z );              
     free (*se_rhoz);        
         free (se_rhoz);     
    
     return;
}






