The C code generates random vectors with the specified 
marginal distribution and the correlation matrix.  The code's 
accurracy and efficiency depend on the dimension of the 
random vector and the marginal distribution shape.  The 
computing efficiency decreases substantially as the dimension 
increases.  

Our generation algorithm is based on the NORTA 
(NORmal-To-Anything) approach (see Reference 1).  Prior 
to using NORTA, n(n-1)/2 equations need to be solved, where 
n is the dimension of the random vector to generate; this is 
a stochastic root finding problem.  For computer application, 
our C code currently can generate random vecotrs with marginal 
distributions chosen from normal, exponential, gamma, beta, 
weibul, F, noncentral t, lognormal, triangular, chi-square, 
and uniform distributions.  The code is designed to run on a 
Sun SparcCenter workstation.  No running experience on 
personal computers or DEC workstations.

For proper inputs, please notice:
  1. The correlation matrix must be positive definite for the 
     program to work properly.  This is because the Cholesky 
     decomposition is required to generate multivariate normal
     random vector, the first step of the NORTA approach.
  2. The generated random vector by NORTA may not reach
     a correlation -1 or/and a correlation 1.  If the marginal 
     distributions are different, then the maximum correlation
     of the random vector that can be generated is very likely
     less than 1.  Even if the marginal distributions are the 
     same, the minimum correlation that can be generated is 
     very likely greater than -1.  For example, using NORTA
     we can only generate exponential random vectors with
     correlation greater than -.647.  (Notice that the correlation
     is not variant of the location and scale parameters.)

You will receive files:
    main.c       (a sample main program)
    rmultvar.c   (multivariate-generation subprogram)
    retro.c      (stochastic root-finding subprogram, called 
                     by rmultvar.c)
    yi.c         (subprogram called by retro.c)
    finv.c       (subprogram called by yi.c)
    cholesky.c   (cholesky decomposition, called by yi.c)
    main.h       (.h file called in main.c)
    Makefile     (make file)
    in           (a sample input file)
    out          (output file associated with in)

To execute these programs under a Sun workstation, use command 
make.  Then you will obtain an executable file, called go.

If you have any problem of using it, please let me know.
Comments, suggestions, etc. will be appreciated.

Reference:
   1. Chen, H. (2001).  Initialization for NORTA: Generation of 
       Random Vectors with Specified Marginals and Correlations.  
       INFORMS Journal on Computing, v. 13,  312-331.

   2. Chen, H. and B.W. Schmeiser (2001). Stochastic Root 
       Finding via Retrospective Approximation.  IIE Transactions 
       v. 33, 259-275.


