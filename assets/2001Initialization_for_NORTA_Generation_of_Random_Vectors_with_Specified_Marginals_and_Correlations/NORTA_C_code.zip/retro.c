/***********************************************************************
**Function: retro(gamma,se_x,iseed,idist,parm,n,xhat,se_xhat,         **
**                nobs)                                               **
**                                                                    **
**  Purpose:    Simultaneously solving n(n-1)/2 equations for         **
**              n(n-1)/2 Step-1 correlations by retrospective         **
**              approximation(RA) algorithms.                         **
**                                                                    **
**  Authors:    Huifen Chen                                           **
**              Department of Industrial Engineering                  **
**              Da-Yeh Institute of Technology                        **
**              Chang-Hwa, 51505, TAIWAN                              **
**              and                                                   **
**              Bruce Schmeiser                                       **
**              School of Industrial Engineering                      **
**              west lafayette, in  47907-1287                        **
**                                                                    **
**  Date:       August, 1994                                          **
**                                                                    **
**  Revision:   Huifen Chen and Chung-Gong Jeng, October 1995.        **
**              Change Chen and Schmeiser's origial RA code for       **
**              solving a one-dimensional equation to solving         **
**              n(n-1)/2 one-dimensional equations simultaneously.    **
**              Add an array "parm" of distribution-parameter and     **
**              convert the FORTRAN code to C.                        **
**                                                                    **
**  Precision:  Single precision                                      **
**                                                                    **
**  Language:   C                                                     **
**                                                                    **
**  Type:       void                                                  **
**                                                                    **
**  Input:                                                            **
**              gamma:   Desired function value                       **
**              se_x:    Desired standard error of xhat               **
**              iseed:   Random-number seed                           **
**              parm:    Vector with distribution properties of ghat  **
**              n:       Dimension of the random vector X             **
**                                                                    **
**  Output:                                                           **
**              iseed:   Random-number seed                           **
**              xhat:    Vector of estimated roots                    **
**              se_xhat: Estimated standard errors of xhat            **
**              nobs:    Number of random vectors generated to        **
**                        compute xhat                                **                                      **
**  Function called:                                                  **
**              search:   A deterministic regula-falsi line search    **
**                                                                    **
**  Called by:                                                        **
**              rmultvar: A multivariate generation routine           **
**                                                                    **
**  References:                                                       **
**              1. Chen, H. and B.W. Schmeiser (1994).                **
**                 Retrospective Approximation Algorithms for         **
**                 Stochastic Root Finding.  Proceedings of the 1994  **
**                 Winter Simulation Conference, 255-261.             **
**              2. Chen, H. (1994).  Sstochastic Root Finding in      **
**                 System Design.  PhD dissertation.  School of       **
**                 Industrial Engineering, Purdue university.         **
***********************************************************************/
/*/#pragma option -g0 */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
/*
#include <malloc.h>
*/


void retro(double **gamma,double se_x,long *iseed,int *idist,
           double **parm,int n,double **xhat,double **se_xhat,
           int *nobs);
void search( int n,double **gamma,int *idist,double **parm,long *iseed0,
             double **x,int *m,double **delta,int *k );
void array_retro(int n,double ***x0,double ***delta,double ***sigma,
                 double ***summx,double ***summx2);
void array_search(int n,double ***delta0,double ***xl,double ***xu,
                  double ***gl,double ***gu,double ***ghat,
                  double ***tmp);
void Initial(int n,double **gamma,double *delta1,double *c1,double *c2,
             int *m1,int *m,int *k,int *summ,int *nobs,
             int *retroi,double **x0,double **delta,double **sigma,
             double **summx,double **summx2,double **xhat,
             double **se_xhat);
void  update(double *x,double *xl,double *xu,double *gl,double *gu,
             double ghat,double gamma,double del);
void   retro(double **gamma,double se_x,long *iseed,int *idist,
             double **parm,int n,double **xhat,double **se_xhat,int *nobs)
{

      int   m,k,m1,summ,retroi,i,j;
      double delta1,c1,c2,v,tmp,
            **x0,**delta,**sigma,**summx,**summx2;

      /* open local arrays */
      array_retro(n,&x0,&delta,&sigma,&summx,&summx2);

      /* initialize */
      Initial(n,gamma,&delta1,&c1,&c2,&m1,&m,&k,&summ,nobs,&retroi,
              x0,delta,sigma,summx,summx2,xhat,se_xhat);

      while(1)                 /* begin RA iterations. */
      {
           retroi++;
           search( n,gamma,idist,parm,iseed,xhat,&m,delta,&k );
           *nobs = *nobs + m*k;  /*number of random vectors generated*/

           /* ...compute the root estimator as a weighted average. */
           summ = summ  + m;
           for(i=0;i < n;i++)
           {
               for(j=i+1;j < n;j++)
               {
                   summx[i][j]  = summx[i][j] + m * xhat[i][j];
                   summx2[i][j] = summx2[i][j] + m * xhat[i][j]*xhat[i][j];
                   xhat[i][j]   = summx[i][j] / summ;
                   xhat[j][i]   = xhat[i][j];    /* xhat is symmetric */
               }
               xhat[i][i] = 1.;                  /* diagonals equal 1 */
           }

           /* ...estimate the standard error of the root estimator.  */
           if (retroi > 1)
           {
               for(i=0;i < n;i++)
                   for(j=i+1;j < n;j++)
                   {
                       sigma[i][j] = 0.;
                       tmp = (summx2[i][j] -
                              summ*xhat[i][j]*xhat[i][j])/(retroi-1);
                       if (tmp > 0.)
                           sigma[i][j] = sqrt( tmp );
                       se_xhat[i][j] = sigma[i][j] / sqrt((double)summ);
                       se_xhat[j][i] = se_xhat[i][j];
                   }
           }

           /* print */
           printf("retroi = %d, k = %d, nobs = %d\n", retroi, k, *nobs);
           printf("  rhoz = ");
           for(i=0;i < n;i++)
           {
               printf("\n        %10.5f", xhat[0][i]); 
               for(j=1;j <= i;j++)
                   printf("%10.5f", xhat[j][i]);
           }
           printf("\n*****************************************************\n\n");

           /*  Check stopping rule:
               Return if (retroi>=4) and all se_xhat's < se_x  */

           if (retroi < 4)
               goto L1;  /* Don't return, if less than 4 iterations */

           for(i=0;i < n;i++)
               for(j=i+1;j < n;j++)
                   if (se_xhat[i][j] > se_x)
                       goto L1; /* Don't return, if any se_xhat > se_x*/

           /* Otherwise, free local arrays and return */

           free( *x0 );               /*  free local arrays  */
               free( x0 );
           free( *delta );
               free( delta );
           free( *sigma );
               free( sigma );
           free( *summx );
               free( summx );
           free( *summx2 );
               free( summx2 );

           return;                    /* return to main() */

 L1:      m = m * c1;      /* update m. */
          
           /* update delta. */
           if ( retroi == 1) continue;
           for(i=0;i < n;i++)
               for(j=i+1;j < n;j++)
               {
                   /* estimate standard deviation of xhat - x*(i). */
                   v           = sigma[i][j] * sqrt( 1.0/summ + 1.0/m );
                   delta[i][j] = c2 * v;
                   if (delta[i][j] == 0)
                      delta[i][j] = 0.000001;
               }
      }
}



/***********************************************************************
**  Function:   search( n,gamma,idist,parm,iseed0,x,m,delta,k )       **
**                                                                    **
**  Purpose:    Approximate the root via numerical search using a     **
**              fixed random-number string for all function estimates.**
**                                                                    **
**  Authors:    Huifen Chen                                           **
**              Department of Industrial Engineering                  **
**              Da-Yeh Institute of Technology                        **
**              Chang-Hwa, 51505, TAIWAN                              **
**              and                                                   **
**              Bruce Schmeiser                                       **
**              School of Industrial Engineering                      **
**              west lafayette, in  47907-1287                        **
**  Revision:   April, 95.  Huifen Chen.                              **
**                1. Add a parmeter array parm.                       **
**                2. Solve n(n-1)/2 correlation equations             **
**                   simultaneously.                                  **
**                                                                    **
**  Precision:  Single precision                                      **
**                                                                    **
**  Language:   C                                                     **
**                                                                    **
**  Type:       void                                                  **
**                                                                    **
**  Input:                                                            **
**           n:       Dimension of the random vector X                **
**           gamma :  Desired function value                          **
**           idist:   Vector of Distribution id's                     **
**           parm:    Vector with distribution properties of ghat     **
**           iseed0:  Random-number seed                              **
**           x:       Initial guess                                   **
**           m :      Number of evaluations of function value (global)**
**           delta:   Initial increment/decrement (global)            **
**                                                                    **
**  Output:                                                           **
**           iseed0:  random-number seed                              **
**           x:       approximated root                               **
**           k:       number of x values considered (global)          **
**                                                                    **
**  Called by:                                                        **
**              retro:   a retrospective approximation algorithm      **
**                                                                    **
**  Functions called:                                                 **
**              update:  a update procedure for x, xl, xu, gl, and gu **
**              yi:      a monte carlo estimator of g(x)              **
**                                                                    **
**  References:                                                       **
**              1. Chen, H. and B.W. Schmeiser (1994).                **
**                 Retrospective Approximation Algorithms for         **
**                 Stochastic Root Finding.  Proceedings of the 1994  **
**                 Winter Simulation Conference, 255-261.             **
**              2. Chen, H. (1994).  Sstochastic Root Finding in      **
**                 System Design.  PhD dissertation.  School of       **
**                 Industrial Engineering, Purdue university.         **
**                                                                   **
***********************************************************************/

void search( int n,double **gamma,int *idist,double **parm,long *iseed0,
             double **x,int *m,double **delta,int *k )

{
       /*  variable declaration */
       int     i,j,l;
       long    iseed;                  
       double   error,**gl,**gu,**xl,**xu,**ghat,**delta0,**tmp;

       /*  set parameters for numerical root finding  */
       double   err = 0.0000001;
       int     maxitr = 50;

       /*  open local arrays  */
       array_search(n,&delta0,&xl,&xu,&gl,&gu,&ghat,&tmp);

       /*    initialize    */
       for(i=0;i < n;i++)
           for(j=0;j < n;j++)
       {
               delta0[i][j] = delta[i][j];
               gl[i][j]     = gamma[i][j] + 1.0;
               gu[i][j]     = gamma[i][j] - 1.0;
               xl[i][j]     = x[i][j];
               xu[i][j]     = x[i][j];
               ghat[i][j]  = 0.;
       }
       *k = 1;

       iseed = *iseed0;
       yi(&iseed, *m, idist, parm, n, x, ghat);

       l     = 1;
       while (1)
       {
        /* Notice that the rootfinding function should lie            
           under the 45-degree straight line for positive  
           x and above the line for negative x.  And hence,
           the true root is at least gamma.  */            

           for(i=0;i < n;i++)
              for(j=i+1;j < n;j++)
              {
                 if (( (gamma[i][j] > 0)&&(x[i][j]<=gamma[i][j])&&
                                          (ghat[i][j]>gamma[i][j])) ||
                     ( (gamma[i][j] < 0)&&(x[i][j]>=gamma[i][j])&&
                                          (ghat[i][j]<gamma[i][j])) )
			/* If not, increase the sample size for more
                           accuracy.  */                            

                        goto L1;
              }
           goto L2;   /* Otherwise, continue. */  

 L1:       l++;
           yi(&iseed, *m,idist, parm, n, x, tmp);
           for(i=0;i < n;i++)
              for(j=i+1;j < n;j++)
                  ghat[i][j] = (l-1)*ghat[i][j]/l + tmp[i][j] / l;
       }

 L2:   *m = l * (*m);

       /*  start search for bounds [xl,xu] bracketing root        */
       while(1)
       {
           for(i=0;i < n;i++)
               for(j=i+1;j < n;j++)
                  if ((x[i][j]==-1. && ghat[i][j] > gamma[i][j]) ||
                      (x[i][j]== 1. && ghat[i][j] < gamma[i][j]))
                  {
                     printf("The desired correlation may not be reached.\n");
          /*           exit(0);*/
		     goto L5;	
                  }

           /* ...special cases: if x=0, then g(x) = 0 */
           for(i=0;i < n;i++)
               for(j=i+1;j < n;j++)
                  if (x[i][j] == 0.)
                  {
                     ghat[i][j]  = 0.;
                     delta[i][j] = 0.;
                  }

           /* print */
           printf("  k, m = %d %d\n", *k, *m);
           printf("    x = ");
           for(i=0;i < n;i++)
           {
               printf("\n        %10.5f", x[0][i]); 
               for(j=1;j <= i;j++)
                   printf("%10.5f", x[j][i]);
           }
           printf("\n    ghat = ");
           for(i=0;i < n;i++)
           {
               ghat[i][i] = 1.;
               printf("\n        %10.5f", ghat[0][i]);
               for(j=1;j <= i;j++)
                   printf("%10.5f", ghat[j][i]);
           }
           printf("\n");

           /*  update iterates  */
           for(i=0;i < n;i++)
               for(j=i+1;j < n;j++)
               { 
                  update(&x[i][j],&xl[i][j],&xu[i][j],&gl[i][j],
                          &gu[i][j],ghat[i][j],gamma[i][j],
                          delta[i][j]);
                  x[j][i] = x[i][j];
                }
            if (*k > maxitr)
            {
                /*  stop execution.  */
                printf("Exceed the maximal number of iterations.\n");
                exit(0);
            }

            /*  ...if bounds are not found for any equation, 
                   double delta and continue.  */
            for(i=0;i < n;i++)
                for(j=i+1;j < n;j++)
                    if ((gu[i][j]-gamma[i][j])*(gl[i][j]-gamma[i][j]) > 0.0)
                         goto L3;
            goto L4;

L3:         /* ...update delta and look at a new point x.  */
            for(i=0;i < n;i++)
                for(j=i+1;j < n;j++)
                    delta[i][j] = delta[i][j] + delta[i][j];

            /* ...compute function estimate at x. */
            iseed = *iseed0;
            yi(&iseed, *m, idist, parm, n, x, ghat);
            *k = *k + 1;
            continue;

L4:         /* otherwise, end search.  */
            /* take linear combination of the function estimates at
            **   the bounds. */
            for(i=0;i < n;i++)
            {
                x[i][i] = 1.;
                for(j=i+1;j < n;j++)
                {
                    x[i][j] = xl[i][j] + (xu[i][j] - xl[i][j]) * 
                             (gamma[i][j]-gl[i][j])/(gu[i][j]-gl[i][j]);
                    x[j][i] = x[i][j];
                }
            }

L5:         *iseed0 = iseed;                    /*  update */
            for(i=0;i < n;i++)
                for(j=0;j < n;j++)
                    delta[i][j] = delta0[i][j];
        
            free( *gl );                /*  free local arrays  */
                free( gl );
            free( *gu );
                free( gu );
            free( *xl );
                free( xl );
            free( *xu );
                free( xu );
            free( *delta0 );
                free( delta0 );
            free( *ghat );
                free( ghat );
            free( *tmp );
                free( tmp );

            return;
       }
}


/*****************************************************************
**  Purpose:  Open local arrays used in function retro().       **
******************************************************************/

void array_retro(int n,double ***x0,double ***delta,double ***sigma,
                 double ***summx,double ***summx2)
{

     int i;

     /*  open arrays.   */
     *x0 = (double **)malloc(n*sizeof(**x0));
     **x0 = (double *)malloc((n*n)*sizeof(***x0));
     for(i=1;i < n;i++)
         *(*x0+i) = **x0 + i*n;
     *delta = (double **)malloc(n*sizeof(**delta));
     **delta = (double *)malloc((n*n)*sizeof(***delta));
     for(i=1;i < n;i++)
         *(*delta+i) = **delta + i*n;
     *sigma = (double **)malloc(n*sizeof(**sigma));
     **sigma = (double *)malloc((n*n)*sizeof(***sigma));
     for(i=1;i < n;i++)
         *(*sigma+i) = **sigma + i*n;
     *summx = (double **)malloc(n*sizeof(**summx));
     **summx = (double *)malloc((n*n)*sizeof(***summx));
     for(i=1;i < n;i++)
         *(*summx+i) = **summx + i*n;
     *summx2 = (double **)malloc(n*sizeof(**summx2));
     **summx2 = (double *)malloc((n*n)*sizeof(***summx2));
     for(i=1;i < n;i++)
         *(*summx2+i) = **summx2 + i*n;
}



/*****************************************************************
**  Purpose:  Open local arrays used in function search().      **
******************************************************************/

void array_search(int n,double ***delta0,double ***xl,double ***xu,
                  double ***gl,double ***gu,double ***ghat,double ***tmp)
{

       int i;

       /*  open arrays   */
       *delta0 = (double **)malloc(n*sizeof(**delta0));
       **delta0 = (double *)malloc((n*n)*sizeof(***delta0));
       for(i=1;i < n;i++)
           *(*delta0+i) = **delta0 + i*n;
       *xl = (double **)malloc(n*sizeof(**xl));
       **xl = (double *)malloc((n*n)*sizeof(***xl));
       for(i=1;i < n;i++)
           *(*xl+i) = **xl + i*n;
       *xu = (double **)malloc(n*sizeof(**xu));
       **xu = (double *)malloc((n*n)*sizeof(***xu));
       for(i=1;i < n;i++)
           *(*xu+i) = **xu + i*n;
       *gl = (double **)malloc(n*sizeof(**gl));
       **gl = (double *)malloc((n*n)*sizeof(***gl));
       for(i=1;i < n;i++)
           *(*gl+i) = **gl + i*n;
       *gu = (double **)malloc(n*sizeof(**gu));
       **gu = (double *)malloc((n*n)*sizeof(***gu));
       for(i=1;i < n;i++)
           *(*gu+i) = **gu + i*n;
       *ghat = (double **)malloc(n*sizeof(**ghat));
       **ghat = (double *)malloc((n*n)*sizeof(***ghat));
       for(i=1;i < n;i++)
           *(*ghat+i) = **ghat + i*n;
       *tmp = (double **)malloc(n*sizeof(**tmp));
       **tmp = (double *)malloc((n*n)*sizeof(***tmp));
       for(i=1;i < n;i++)
           *(*tmp+i) = **tmp + i*n;
}



/*****************************************************************
**  Purpose:  Initialize values.                                **
******************************************************************/

void Initial(int n,double **gamma,double *delta1,double *c1,double *c2,
             int *m1,int *m,int *k,int *summ,int *nobs,
             int *retroi,double **x0,double **delta,double **sigma,
             double **summx,double **summx2,double **xhat,double **se_xhat)
{

     int i,j;

     /*  set algorithm parameters.  */
     *delta1 = 0.001,
     *c1     = 2.0,
     *c2     = 1.0;
     *m1     = 40;

     /* initialize retrospective approximation. */
     *m       = *m1,
     *k       = 0 ,
     *summ    = 0 ;
     
     for(i=0;i < n;i++)
         for(j=i+1;j < n;j++) 
         {
             delta[i][j]  = *delta1;
             sigma[i][j]  = 0.0;
             summx[i][j]  = 0.0;
             summx2[i][j] = 0.0;
         } 

     /*  set the initial guess as the desire correlation. */
     for(i=0;i < n;i++)
         for(j=0;j < n;j++)
             x0[i][j] = gamma[i][j];

      /* initilize retrospective approximation variables */
      *retroi = 0;             /* RA iteration counter */
      *nobs    = 0;
      for(i=0;i < n;i++)
          for(j=0;j < n;j++)
           {
               xhat[i][j]    = x0[i][j];
               se_xhat[i][j] = 0.0;
           }

     return;
}


/*****************************************************************
**  Purpose:  Update x, xl, xu, gl, and gu.                     **
******************************************************************/

void  update(double *x,double *xl,double *xu,double *gl,double *gu,double ghat,
             double gamma,double del)
{
   if (ghat < gamma)              /*   ...move up or down */
   {
       *xl    = *x;
       *gl    = ghat;
       *x     = *x + del;
    }
    else
    {
       *xu    = *x;
       *gu    = ghat;
       *x     = *x - del;
    }

    /** if bounds are found, set x to be the linear interpolate. **/
    if (((*gu)-gamma)*((*gl)-gamma) <= 0.0)
       *x = (*xl) + ((*xu) - (*xl)) * (gamma-(*gl))/((*gu)-(*gl));

    /** if x is less than -1, set x=-1 **/
    if (*x < -1) *x = -1;

    /** if x is greater than 1, set x=1 **/
    if (*x > 1) *x = 1;
}





