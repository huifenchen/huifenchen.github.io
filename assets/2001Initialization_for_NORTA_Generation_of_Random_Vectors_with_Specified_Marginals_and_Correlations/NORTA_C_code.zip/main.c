/***********************************************************************
**  Sample main program.                                              **
**                                                                    **
**  Purpose:    Generate multivariate random vectors X=(X1,...,Xn)    **
**              with specified marginal distributions and a           **
**              correlation matrix rho.                               **
**                                                                    **
**  Author:     Huifen Chen and Chung-Gong Jeng                       **
**              Department of Industrial Engineering                  **
**              Da-Yeh Institute of Technology, Chang-Hwa, TAIWAN.    **
**                                                                    **
**  Precision:  Single precision                                      **
**                                                                    **
**  Language:   C                                                     **
***********************************************************************/


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "main.h"
/*
#include <malloc.h>
*/

main()
{

   /*  Record the beginning clock time  */
/* 
   begin = clock();
*/
   /* Enter inputs */
   input();

   /* Initialize variables */
   initial();

   /* ...Compute marginal means and variances for verification   */
   stat();

   /*  Start micro-macro replications  */
   for(count=0; count < macro; count++)          /* Macro loop */
   {
       /*  .....initialize micro sums  */
       for(i=0;i < n;i++)
       {
           sum[i] = 0.0;
           for(j=i;j < n;j++)
               sum12[i][j] = 0.0;
       }

       srfp = 'T';  
       for(l=0;l < micro;l++)         /* Start micro replications */
       {
          rmultvar(&iseed,n,np,idist,parm,rho,&srfp,chol,rhoz,x,&nobs);

          if (l == 0)  
          {
              nsum  = nsum + nobs;
              nsum2 = nsum2 + (double)nobs * nobs; /* prevent overflow */
          }

          for(i=0;i < n;i++)
          {
              sum[i] = sum[i] + x[i];
              for(j=i;j < n;j++)
              {
                 sum12[i][j] = sum12[i][j] + 
                               (x[i]-xmean[i]) * (x[j]-xmean[j]);
              }

/*            printf("%10.3f", x[i]);  */
          }
/*        printf("\n");     */
       }

       /*  At each macro replication, compute sample means and sample */
       /*  variances, and sample correlation matrix.      */
       for(i=0;i < n;i++)
       {
           xbarsum[i] = xbarsum[i] + sum[i] / micro;
           s2         = sum12[i][i] / micro;
           s2sum[i]   = s2sum[i] + s2;
           s2sum2[i]  = s2sum2[i] + s2 * s2;
           dsum12[i][i]  = dsum12[i][i] + sum12[i][i];
           for(j=i+1;j < n;j++)
           {
               sumr[i][j]    = sumr[i][j] + rhoz[i][j];
               sumr2[i][j]   = sumr2[i][j] + rhoz[i][j] * rhoz[i][j];

               dsum12[i][j]  = dsum12[i][j] + sum12[i][j];
               rhohat        = sum12[i][j] /
                                  sqrt( sum12[i][i]*sum12[j][j] );
               rhosum[i][j]  = rhosum[i][j] + rhohat;
               rhosum2[i][j] = rhosum2[i][j] + rhohat * rhohat;
           }
       }
    }

    /*  Compute the final sample means, sample variances, and sample  */
    /*  correlation matrix, and estimate their standard errors.       */
    for(i=0;i < n;i++)
    {
       xbarb[i]    = xbarsum[i] /macro;
       s2bar[i]    = s2sum[i] /macro;
       se_barb[i]  = sqrt( s2bar[i]/(macro*micro) );
       se_s2bar[i] = 0;
       tmp         = s2sum2[i] / macro - s2bar[i]*s2bar[i];
       if (tmp > 0.) 
             se_s2bar[i] = sqrt( tmp / (macro-1) );
       rhat[i][i]    = 1.0;
       rhatse[i][i]  = 0.0;
       rhozbar[i][i] = 1.0;
       se_zbar[i][i] = 0.0;
       for(j=i+1;j < n;j++)
       {
           rhozbar[i][j] = sumr[i][j] / (double) macro;
           se_zbar[i][j] = 0.;
           tmp           = sumr2[i][j] / macro- 
                           rhozbar[i][j] * rhozbar[i][j] ;
           if (tmp > 0.)
                 se_zbar[i][j] = sqrt( tmp / (macro - 1) );
           rhozbar[j][i] = rhozbar[i][j]; 
           se_zbar[j][i] = se_zbar[i][j]; 

           rhat[i][j]    = dsum12[i][j] /
                            sqrt( dsum12[i][i]*dsum12[j][j] );
           rhatse[i][j]  = 0.;
           tmp = rhosum2[i][j] - rhosum[i][j]*rhosum[i][j] / macro;
           if (tmp > 0.)
                 rhatse[i][j] = sqrt( tmp / (macro * (macro-1)) );
           rhat[j][i]=rhat[i][j];
           rhatse[j][i]=rhatse[i][j];
       }
    }
    navg    = nsum / (double)macro;
    se_navg = 0.;
    tmp     = nsum2 / (double)macro - navg*navg;
    if (tmp > 0.) 
            se_navg  = sqrt( tmp / (macro - 1) );

    /* Print report */
    report();

    /* Record CPU execution time */
/*
    end = clock();
    printf("total cpu time is %.2f seconds\n",(end-begin)/(1.0e+6));
    printf("time for one macro replication is %.2f seconds\n",
            (end-begin)/(macro*1.0e+6));
    exit(0);
*/
}


/**********************************************************************
**  Purpose:  Input distribution properties and experiment variables **
***********************************************************************/

void input()
{

   /************************************
   **            Start input          **
   ************************************/
   printf("Enter the initial random seed \n");
   scanf("%ld", &iseed);
   printf("Enter the number of random vectors to generate \n");
   scanf("%d", &micro);
   printf("Enter dimension of the desired random vector \n");
   scanf("%d", &n);

   printf("Select the distribution family for each marginal random variable \n");
   printf("from the following list:\n");
   printf("    id      distribution family \n");
   printf("  ------   ------------------------- \n");
   printf("    1       normal distribution \n");
   printf("    2       exponential distribution \n");
   printf("    3       gamma distribution \n");
   printf("    4       beta distribution \n");
   printf("    5       weibull distribution \n");
   printf("    6       F distribution \n"); 
   printf("    7       noncentral T dsitribution \n"); 
   printf("    8       lognormal distribution \n");
   printf("    9       triangular distribution \n");
   printf("   10       chi-square distribution \n");
   printf("   11       uniform distribution \n");

   /* input: marginal distributions---distribution family and 
   **        distribution parameter values.
   */
   idist  =(int*)malloc(n*sizeof(*idist));  /** array declaration **/
   np =(int*)malloc(n*sizeof(*np));  
   parm  = (double **)malloc(n*sizeof(*parm));

   for(i = 0;i < n;i++)   /** for each marginal distribution: **/
   {
       /** ...input distribution id  **/
       printf("Enter the distribution id for random variable %d (enter a number 1 through 11) \n", i+1);
L1:
       scanf("%d",&idist[i]);
       if ((idist[i] < 1) || (idist[i] > 11))
       {
          printf("Wrong input.  Enter a number 1 through 11. \n");
          goto L1;
       }

       /** ...set the number of distribution parameters  **/
       setnpar();

       /** input: marginal-distribution parameter values **/
       parm[i] = (double *)malloc(np[i]*sizeof(double));
       inputpar();
   }


   /* input: desired correlation matrix */
   n2    = n * n;                           /*  array declaration  */ 
   rho   = (double **)malloc(n*sizeof(*rho));
   *rho  = (double *)malloc(n2*sizeof(**rho));
   for(i = 1;i < n;i++)
          *(rho+i) = *rho + i*n;
   printf(" Enter the desired correlation matrix of x:\n");
   printf("     Enter the upper triangle (NOT including diagonal) row by row.\n");
   for(i=0;i < n;i++)
   {
       rho[i][i] = 1.;
       for(j=i+1;j < n;j++)
       {
           scanf("%lf",&rho[i][j]);
           if(i != j)
               rho[j][i] = rho[i][j];  
       }
   }
   return;
}


/*****************************************************************
**  Purpose:  Open arrays and initialize variables              **
******************************************************************/

void initial()
{

   /*  array declaration  */ 
   x       = (double*)malloc(n*sizeof(*x));
   sum     = (double*)malloc(n*sizeof(*sum));
   xbarsum = (double*)malloc(n*sizeof(*xbarsum));
   s2sum   = (double*)malloc(n*sizeof(*s2sum));
   s2sum2  = (double*)malloc(n*sizeof(*s2sum2));
   xbarb   = (double*)malloc(n*sizeof(*xbarb));
   s2bar   = (double*)malloc(n*sizeof(*s2bar));
   se_barb = (double*)malloc(n*sizeof(*se_barb));
   se_s2bar= (double*)malloc(n*sizeof(*se_s2bar));

   rhoz  = (double **)malloc(n*sizeof(*rhoz));
   *rhoz = (double *)malloc(n2*sizeof(**rhoz));
   for(i = 1;i < n;i++)
          *(rhoz+i) = *rhoz + i*n;
   chol  = (double **)malloc(n*sizeof(*chol));
   *chol = (double *)malloc(n2*sizeof(**chol)); 
   for(i = 1;i < n;i++)
          *(chol+i) = *chol + i*n;
   sum12  = (double **)malloc(n*sizeof(*sum12));
   *sum12 = (double *)malloc(n2*sizeof(**sum12));
   for(i  = 1;i < n;i++)
          *(sum12+i) = *sum12 + i*n;
   rhosum  = (double **)malloc(n*sizeof(*rhosum));
   *rhosum = (double *)malloc(n2*sizeof(**rhosum));
   for(i = 1;i < n;i++)
          *(rhosum+i) = *rhosum + i*n;
   rhosum2 = (double **)malloc(n*sizeof(*rhosum2));
   *rhosum2= (double *)malloc(n2*sizeof(**rhosum2));
   for(i = 1;i < n;i++)
          *(rhosum2+i) = *rhosum2 + i*n;
   dsum12 = (double **)malloc(n*sizeof(*dsum12));
   *dsum12= (double *)malloc(n2*sizeof(**dsum12));
   for(i = 1;i < n;i++)
          *(dsum12+i) = *dsum12 + i*n;
   rhat    = (double **)malloc(n*sizeof(*rhat));
   *rhat   = (double *)malloc(n2*sizeof(**rhat));
   for(i = 1;i < n;i++)
          *(rhat+i) = *rhat + i*n;
   rhatse  = (double **)malloc(n*sizeof(*rhatse));
   *rhatse = (double *)malloc(n2*sizeof(**rhatse));
   for(i = 1;i < n;i++)
          *(rhatse+i) = *rhatse + i*n;
   sumr  = (double **)malloc(n*sizeof(*sumr));
   *sumr = (double *)malloc(n2*sizeof(**sumr));
   for(i  = 1;i < n;i++)
          *(sumr+i) = *sumr + i*n;
   sumr2  = (double **)malloc(n*sizeof(*sumr2));
   *sumr2 = (double *)malloc(n2*sizeof(**sumr2));
   for(i  = 1;i < n;i++)
          *(sumr2+i) = *sumr2 + i*n;
   rhozbar  = (double **)malloc(n*sizeof(*rhozbar));
   *rhozbar = (double *)malloc(n2*sizeof(**rhozbar));
   for(i = 1;i < n;i++)
          *(rhozbar+i) = *rhozbar + i*n;
   se_zbar  = (double **)malloc(n*sizeof(*se_zbar));
   *se_zbar = (double *)malloc(n2*sizeof(**se_zbar));
   for(i = 1;i < n;i++)
          *(se_zbar+i) = *se_zbar + i*n;

   /* ...initialize summation variables */
   nsum  = 0.;
   nsum2 = 0.;
  
   for (i=0; i<n; i++)
   {
       xbarsum[i] = 0.0;
       s2sum[i]   = 0.0;
       s2sum2[i]  = 0.0;
       for (j=i; j<n; j++)
       {
           dsum12[i][j]  = 0.0;
           rhosum[i][j]  = 0.0;
           rhosum2[i][j] = 0.0;
           sumr[i][j]    = 0.0;
           sumr2[i][j]   = 0.0;
       }
   }

   /*  Initialize the root-finding indicator srft so that function    **
   **  rmultvar compute the step-1 correlation matrix when rmultvar() **
   **  is called the first time.                                      
   */
   srfp='T';

   /*  Initialize the number of macro replicationsl  */
   macro  = 20;
   
   /*  Save the initial random-number seed  */
   iseed0 = iseed;
}


/*****************************************************************
**  Function: stat(id, parm, xmean, xvar)                       **
**                                                              **
**  Purpose:    Compute the marginal mean and variance          **
**                                                              **
**  Author:     Huifen Chen and Chung-Gong Jeng                 **
**              Department of Industrial Engineering            **
**              Da-Yeh Institute of Technology                  **
**              Chang-Hwa, 51505, TAIWAN                        **
**                                                              **
**  Precision:  Single precision                                **
**                                                              **
**  Language:   C                                               **
**                                                              **
**  Type:       void                                            **
**                                                              **
**  Input:                                                      **
**              idist: Vector of Distribution id's              **
**              parm:  Matrix of distribution parameters        **
**                                                              **
**  Output:                                                     **
**              xmean: Vector of marginal means                 **
**              xvar:  Vector of marginal variances             **
*****************************************************************/

void stat()
{

   /* Define arrays of marginal means and marginal variance */
   xmean   = (double*)malloc(n*sizeof(*xmean)); /* array declaration */
   xvar    = (double*)malloc(n*sizeof(*xvar));

   /**********************************************
   **       Compute means and variances         **
   **********************************************/

   for (i=0;i<n;i++)
   {
      if(idist[i] == 1)
      { 
         /* ...normal random variable with mean parm[i][0] and
         **    variance parm[i][1] 
         */
         xmean[i] = parm[i][0];
         xvar[i]  = parm[i][1] * parm[i][1];
      }

      if (idist[i] == 2)
      {
         /* ...exponential random variable with scale parameter parm[i][0].
         **    the density function proportional to exp{ -x/parm[i][0] }.
         */
         xmean[i] = parm[i][0];
         xvar[i]  = parm[i][0] * parm[i][0];
      }
 
      if(idist[i] == 3)
      {
         /* ...gamma random variable with shape parameter parm[i][0] and 
         **    scale parm[i][1].   the density function proportional to
         **             x**( parm[i][0]-1 ) * exp{ -x/parm[i][1] }.
         */
         xmean[i] = parm[i][0] * parm[i][1];
         xvar[i]  = parm[i][0] * parm[i][1] * parm[i][1];
      } 
      if (idist[i] == 4)
      {
         /* ...beta random variable with lower bound parameter a=parm[i][0]
         **    , upper bound parameter b=parm[i][1], shape1 parameter 
         **    p=parm[i][2], shape2 parameter q=parm[i][3].
         */
         xmean[i] = parm[i][0] + (parm[i][1] - parm[i][0]) * 
                     (parm[i][2] / (parm[i][2] + parm[i][3]));
         xvar[i]  = (parm[i][1] - parm[i][0])*(parm[i][1] - parm[i][0])
                 *( (parm[i][2]*parm[i][3])/( (parm[i][2]+parm[i][3])
                 *(parm[i][2]+parm[i][3])*(parm[i][2]+parm[i][3]+1) ));
      }
      if (idist[i] == 5)
      { 
         /* ...weibull random variable with shape parameter alpha=parm[i][0] 
         **    and scale parameter beta=parm[i][1].  the density function is 
         **    proportional to exp{-(x/beta)^alpha}
         */
         tmp      = exp( gammln( 1.0/parm[i][0]) );
         xmean[i] = ( parm[i][1] / parm[i][0]) * tmp;
         xvar[i]  = ( parm[i][1]*parm[i][1]/parm[i][0] )*( 2.0 *
                    exp(gammln(2.0/parm[i][0]))-tmp*tmp/parm[i][0]); 
      }  
      if( idist[i] == 6)
      {
          /* ...F random variable with the first degrees of freedom : parm[0]
          *     and the second degrees of freedom : parm[1]
          */
         if ( parm[i][1] <= 2. )
            xmean[i] = 9999999.;
         else
            xmean[i] = parm[i][1] / (parm[i][1] - 2.);
         if ( parm[i][1] <= 4. )
            xvar[i] = 9999999.;
         else
            xvar[i]=((2.*parm[i][1]*parm[i][1])*(parm[i][0]+parm[i][1]-2.))
                     / (parm[i][0]*(parm[i][1] - 2.)*(parm[i][1] - 2.)
                     * (parm[i][1] - 4.));
      }

      if( idist[i] == 7)
      {
         /* ...noncentral t random variable with parm[i][0] degrees of
         *     freedom and the noncentrality parameter is parm[i][1]
         */
         df     = parm[i][0];
         del    = parm[i][1];
         xmean[i] = 1.e+30;
         xvar[i]  = 1.e+30;
         if (df > 1.)
         {
            tmp      = exp( gammln(.5*(df - 1)) );
            tmp2     = exp( gammln(.5*df) );
            xmean[i] = sqrt(.5*df)*tmp*del / tmp2;
         }
         if (df > 2.)
            xvar[i] = df*(1. + del*del)/(df-2) - (xmean[i])*(xmean[i]);
      }
      if (idist[i] == 8)
      {
         /* ...lognormal random variable with lower bound parm[i][0] and
         **  parm[i][1] and parm[2] are mean and standard deviation of
         **  ln(X3 - parm[i][0])  
         */
         xmean[i] = parm[i][0] + exp(parm[i][1]+parm[i][2]*parm[i][2]/2.);
         xvar[i]  = exp(2.*parm[i][1] + parm[i][2]*parm[i][2])*
                 ( exp(parm[i][2]*parm[i][2]) - 1. ); 
      }
      if( idist[i] == 9)
      {
         /* ...triangular random variable with lower bound parm[i][0], 
         **    mode parm[i][1], and upper bound parm[i][2].
         */
         xmean[i] = (parm[i][0]+parm[i][1]+parm[i][2])/3.0;
         xvar[i]  = (parm[i][0]*parm[i][0]+parm[i][1]*parm[i][1]+
                     parm[i][2]*parm[i][2]-parm[i][0]*parm[i][1]-
                     parm[i][1]*parm[i][2]-parm[i][2]*parm[i][0])/18.0; 
      } 
      if( idist[i] == 10)
      {
         /* chi-square random variable with degrees of freedom parm[i][0]. 
         */
         xmean[i] = parm[i][0];
         xvar[i]  = 2.* parm[i][0];
      } 
      if( idist[i] == 11)
      {
         /* ...uniform random variable with lower bound parm[i][0] and 
         **    upper bound parm[i][1].
         */
         xmean[i] = (parm[i][0] + parm[i][1]) /2.;
         xvar[i]  = (parm[i][1] - parm[i][0])*(parm[i][1]-parm[i][0])/12.; 
      } 
   } 
}
        

/*********************************************************************
**  Function: setnpar(idist, np)                                    **
**                                                                  **
**  Purpose:    set the number of marginal-distribution parameters  **
**                                                                  **
**  Author:     Huifen Chen and Chung-Gong Jeng                     **
**              Department of Industrial Engineering                **
**              Da-Yeh Institute of Technology                      **
**              Chang-Hwa, 51505, TAIWAN                            **
**                                                                  **
**  Precision:  Single precision                                    **
**                                                                  **
**  Language:   C                                                   **
**                                                                  **
**  Type:       void                                                **
**                                                                  **
**  Input:                                                          **
**              idist: Distribution id                              **
**                                                                  **
**  Output:                                                         **
**              np: number of parameters of i^th marginal           **
**                   distribution                                   **
*********************************************************************/

setnpar()
{

   if (idist[i] == 1)
        np[i] = 2;
   else if(idist[i] == 2)
        np[i] = 1;
   else if(idist[i] == 3)
        np[i] = 2;
   else if(idist[i] == 4)
        np[i] = 4;
   else if(idist[i] == 5)
        np[i] = 2;
   else if(idist[i] == 6)
        np[i] = 2;
   else if(idist[i] == 7)
        np[i] = 2;
   else if(idist[i] == 8)
        np[i] = 3;
   else if(idist[i] == 9)
        np[i] = 3;    
   else if(idist[i] == 10)
        np[i] = 1;
   else if(idist[i] == 11)
        np[i] = 2;
}


/*********************************************************************
**  Function:   inputpar(idist, parm)                               **
**                                                                  **
**  Purpose:    Input marginal-distribution parameter values        **
**                                                                  **
**  Author:     Huifen Chen and Chung-Gong Jeng                     **
**              Department of Industrial Engineering                **
**              Da-Yeh Institute of Technology                      **
**              Chang-Hwa, 51505, TAIWAN                            **
**                                                                  **
**  Precision:  Single precision                                    **
**                                                                  **
**  Language:   C                                                   **
**                                                                  **
**  Type:       void                                                **
**                                                                  **
**  Input:                                                          **
**              idist:   Distribution id                            **
**                                                                  **
**  Output:                                                         **
**              parm:    Matrix of distribution-parameter values    **
*********************************************************************/

inputpar()
{

    if (idist[i] == 1)
    {
       /** normal distribution **/
       printf("Enter normal's mean and standard deviation.\n");
       scanf("%lf %lf",&parm[i][0],&parm[i][1]);
    } else if (idist[i] == 2)
    {
       /** exponential distribution **/
       printf("Enter parameter lambda.  Note: mean = lambda. \n");
       scanf("%lf", &parm[i][0]);
    } else if (idist[i] == 3)
    {
       /** gamma distribution **/
       printf("Enter the shape parameter alpha and scale parameter beta \n");
       printf("Note: density function is proportional to x**(alpha-1 )*exp{-x/beta}.\n");
       scanf("%lf %lf",&parm[i][0],&parm[i][1]);
    } else if (idist[i] == 4)
    {
        /** beta distribution **/
        printf("Enter the lower bound parameter a and upper bound parameter b\n");
        scanf("%lf %lf",&parm[i][0],&parm[i][1]);

        printf("Enter the shape1 parameter p and shape2 parameter q\n");
        scanf("%lf %lf",&parm[i][2],&parm[i][3]);
    } else if (idist[i] == 5)
    {
       /** weibull distribution **/
       printf("Enter the shape parameter alpha and scale parameter beta \n");
       printf("Note: density function is proportional to exp{-(x/beta)^alpha}.\n");
       scanf("%lf %lf",&parm[i][0],&parm[i][1]);
    } else if (idist[i] == 6)
    {
        /**  F distribution **/
       printf("Enter the first degrees of freedom and second degrees of freedom \n");
       scanf("%lf %lf",&parm[i][0],&parm[i][1]);
       if (parm[i][1] <=2)
          printf("The mean may be not exist \n");
       if (parm[i][1] <=4)
          printf("The variance may be not exist \n");
    } else if (idist[i] == 7)
    {
       /** noncentral T distribution **/
       printf("Enter the degrees of freedom and noncentrality \n");
       scanf("%lf %lf",&parm[i][0],&parm[i][1]);
    } else if (idist[i] == 8)
    {
       /** lognormal distribution **/
       printf("Enter the lower bound a, and the mean and standard \n");
       printf(" deviation of ln(X-a) \n");
       scanf("%lf %lf %lf",&parm[i][0],&parm[i][1],&parm[i][2]);
    } else if (idist[i] == 9)
    {
       /** triangular distribution **/
       printf("Enter the lower bound, mode, and upper bound \n");
       scanf("%lf %lf %lf",&parm[i][0],&parm[i][1],&parm[i][2]);
    } else if (idist[i] == 10)
    {
       /** chi-square distribution **/
       printf("Enter the degrees of freedom.  Positive but not necessary integer. \n");
       scanf("%lf",&parm[i][0]);
    } else if (idist[i] == 11)
    {
       /** uniform distribution **/
       printf("Enter the lower and upper bounds. \n");
       scanf("%lf %lf",&parm[i][0], &parm[i][1]);
    }
    return;
}


/*****************************************************************
**  Purpose:  Print final report                                **
******************************************************************/

void report()
{

    /*  print report.  */
    printf("\n****************************************************\n");
    printf("Specified values:\n\n");
    printf("  Mean     = [");
    for(i=0;i < n;i++)
        printf("%10.3lf",xmean[i]);
    printf(" ]\n");
    printf("  Variance = [");
    for(i=0;i < n;i++)
        printf("%10.3lf",xvar[i]);
    printf(" ]\n");
    printf("  Correlation matrix:");
    for(i=0;i < n;i++)
    {
        printf("\n    %10.5lf",rho[i][0]);
        for(j=1;j < n;j++)
            printf("%10.5lf",rho[i][j]);
    }

    printf("\n\n ********************************************************\n");
    printf(" **************       RESULT        *********************\n");
    printf(" ********************************************************\n\n");
    printf("          Sample statistics from generated data          \n\n");
    printf("  Mean     = [");
    for(i=0;i < n;i++)
        printf("%10.4lf",xbarb[i]);
    printf(" ]\n");
    printf(" (std error)    ");
    for(i=0;i < n;i++)
        printf("(%7.5lf) ",se_barb[i]);
    printf("\n\n");
    printf("  Variance = [");
    for(i=0;i < n;i++)
        printf("%10.4lf",s2bar[i]);
    printf(" ]\n");
    printf(" (std error)    ");
    for(i=0;i < n;i++)
        printf("(%7.5lf) ",se_s2bar[i]);
    printf(" \n\n");

    printf("  Correlation Matrix: (():standard error)");
    for(i=0;i < n;i++)
    {
        printf("\n\n    %11.5lf",rhat[i][0]);
        for(j=1;j < n;j++)
            printf("%11.5lf",rhat[i][j]);
        printf("\n      (%8.5lf) ",rhatse[i][0]);
        for(j=1;j < n;j++)
            printf("(%8.5lf) ",rhatse[i][j]);
    }
    printf("\n\n *******************************************************\n");
    printf("\n              ESTIMATION OF THE STEP1 CORRELATION:\n");
    printf("\n ********************************************************\n");

    printf("\n\n *******************************************************\n");
    printf("  Estimated step1 correlation matrix: (():standard error) ");
    for(i=0;i < n;i++)
    {
        printf("\n\n       %11.5lf",rhozbar[i][0]);
        for(j=1;j < n;j++)
            printf("%11.5lf",rhozbar[i][j]);
        printf("\n         (%8.5lf) ", se_zbar[i][0]);
        for(j=1;j < n;j++)
            printf("(%8.5lf) ", se_zbar[i][j]);
    }
    printf("\n\n  Mean # of random vectos generated for rootfinding = %10.2lf (%8.2lf) ", navg,se_navg);
    printf("\n\n ********************************************************\n");

    printf("\n Experiment paramaters                              \n");
    printf("    no. of macro replications= %d \n", macro);
    printf("    no. of micro replications= %d \n", micro);
/*  printf("    no. of IRA iterations    = %d \n", itr);       */ 
    printf("    initial seed             = %ld \n", iseed0);
    printf("    final   seed             = %ld \n", iseed);
/*  printf("\n Root estimate with all micro/macro rep.: \n");
    printf("    estimated root           = %f (%f) \n", rzhat,se_rzhat);
    printf("\n Quality of root estimate via IRA algorithms: \n");
    printf("    bias(Xibar)              = %f (%f) \n", bias,se_b);
    printf("    var(Xibar)               = %f (%f) \n", var,se_v);
    printf("    mse(Xibar) (ie, bias+var)= %f (%f) \n", mse,se_mse);
    printf("    E( varhat(Xibar) )       = %f (%f) \n", vhatbb,se_vhat);
    printf("    E(# of samples generated)= %f (%f) \n", navg,se_navg);
    printf("\n Auxilliary information \n");
    printf("    true root                = %f \n", root);
    printf("\n ********************************************************\n");
*/

}
