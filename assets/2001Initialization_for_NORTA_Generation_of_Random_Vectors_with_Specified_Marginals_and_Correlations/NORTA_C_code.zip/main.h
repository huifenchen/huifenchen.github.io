void  input();
void  initial();
void  stat();
void  rmultvar();
void  report();
float gammln();

long     iseed,iseed0;
int      i,j,k,l,n,n2,micro,macro,count,nobs,
         *np,*idist;

double   begin,end,df,del,rhohat,s2,
         *x,**rho,**rhoz,**chol,**parm;

double   tmp,tmp2,nsum,nsum2,navg,se_navg,
         **sum12,**rhosum,**rhosum2,**dsum12,*xbarsum,*s2sum,
         *s2sum2,*xbarb,*s2bar,*sum,*se_barb,*se_s2bar,
         **rhat,**rhatse,*xmean,*xvar,**rhozbar,**se_zbar,
         **sumr,**sumr2;

char     srfp;
