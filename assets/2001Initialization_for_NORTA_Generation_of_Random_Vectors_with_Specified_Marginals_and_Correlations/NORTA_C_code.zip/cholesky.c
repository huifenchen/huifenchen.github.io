/******************************************************************
**  Purpose:  Finding the cholesky decompositon matrix of a      **
**            nxn symmetric positive definite matrix P, so that  **
**                     P = CHOL' * CHOL ,                        **
**            where CHOL is a lower triangular matrix.           **
**                                                               **
**  Input:                                                       **
**            p:      nxn symmetric positive definite matrix     **
**            n:      order of matrix p                          **
**                                                               **
**  Output:                                                      **
**            chol:   cholesky decompositon                      **
**            ifault: error indicator                            **
**                                                               **
*******************************************************************/

#include <stdio.h>
#include <math.h>

void choleskyf(int n,double **p,double **chol,int *ifault);
void cholesky(double *a,int n,int nn,double *u,int *nullty,int *ifault);

void choleskyf(int n,double **p,double **chol,int *ifault)
{

       int i,j,k,nn,nullty;
       double *a,*upp;

       nn = (n*(n+1)/2);
       a = (double *)malloc(nn*sizeof(*a));
       upp=(double *)malloc(nn*sizeof(*upp));

       k=0;
       for(i=0;i < n;i++)
           for(j=0;j < i+1;j++)
           {
               a[k] = p[i][j];
               k    = k + 1;
           }

       cholesky(a,n,nn,upp,&nullty,ifault);

       /* ...convert outputs to an upper triangular matrix chol.
             then, p = chol' * chol.     */
       k = 0;
       for(i = 0;i < n;i++)
           for(j = 0;j < i+1;j++)
           {
               chol[i][j] = 0.0;
               chol[j][i] = upp[k];
               k = k + 1;
            }

       free( a );
       free( upp );
}



void   cholesky(double *a,int n,int nn,double *u,
                int *nullty,int *ifault)

/*
          Algorithm as 6 appl. statist. (1968) vol.17 p.195

          Given a symmetric matrix order n as lower triangle in A( )
          calculates an upper triangle, U(), such that Uprime*U = A.
          A must be positive semi-definite.  ETA is set to multiplying
          factor determining effective zero for pivot.                 
          Input: 
             A: the lower triangle of the decomposed matrix, say P,
                stored as a one-dimensional array in the sequence
                p11, p21, p22, p31, p32, p33,.....
             n: order of A

          Output:
             U: the result matrix, stored as a one-dimensional array 
                in the sequence u11, u12, u22, u13, u23, u33,....
             nullty: the nullty of P.  that is, number of u(ii) set
                     to zero.
             ifault: error indicator:
                       0 if no error.
                       1 if n < 1.
                       2 if a is not positive semi-definite.
                       3 if the dimensions of A and P do not match
*/
{
          int    irow,icol,i,j,k,l,m,ii,kk;
          double  eta=0.000000001, eta2, x, w, zero=0.0;

/*      The value of ETA will depend on the work-length of the
          computer being used.  See introductory text.        */

          if(n <= 0)
          {
             *ifault = 1;
             return;
          }
          if( nn != (n*(n+1)/2) )
          {
             *ifault = 3;
             return;
          }
          *ifault=2;
          *nullty = 0;
          j=0;
          k=-1;
          eta2 = eta * eta;
          ii = -1;
          for(icol=0;icol<n;icol++)
          {
             ii = ii + icol + 1;
             x = eta2 * a[ii];
             l = -1;
             kk = -1;
             for(irow=0; irow <= icol;irow++)
             {
                 kk = kk + irow + 1;
                 k = k + 1;
                 w = a[k];
                 m = j;
                 for( i = 0; i<=irow;i++)
                 {
                    l++;
                    if (i == irow)
                       break;
                    w = w - u[l] * u[m];
                    m++;
                  }
                  if(irow == icol) break;
                  if(u[l] == zero)
                  {
                     if((w*w) > fabs(x*a[kk]))  return;
                     u[k] = zero;
                  }
                  else
                  {
                     u[k] = w/u[l];
                  }
              }
              if(fabs(w) <= fabs(eta * a[k]))
              {
                 u[k] = zero;
                 *nullty++;
              }
              else
              {
                 if(w < zero)  return;
                 u[k] = sqrt(w);
              }
              j = j + icol + 1;
          }
          *ifault=0;
          return;
}


