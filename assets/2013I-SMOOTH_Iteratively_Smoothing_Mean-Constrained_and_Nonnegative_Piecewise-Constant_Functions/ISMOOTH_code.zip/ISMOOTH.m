%
%    huifen chen and bruce schmeiser, may 12, 2011.  
%    purpose: driver test programm for i-smooth.     
%

function main
    
	%I/O part
	%Input
    
    infile = fopen('input.txt','r');
	outfile = fopen('output.txt','wt');
        
	nl = 0;
    nr = 0;
	
	fprintf(outfile,' enter k, the number of rates \n');
    k = fscanf(infile,'%d',1);

	time = zeros(k+1,1);
    rate = zeros(k,1);
	
	fprintf(outfile,' enter the rate values ');
    
    for i = 1 : k
		rate(i) = fscanf(infile,'%lf',1);
    end
        
	fprintf(outfile,' enter context: 1 for finite horizon, 0 for cyclic \n');
    ifinite = fscanf(infile,'%d',1);

	frate(1) = -1.0;
    frate(2) = -1.0;
    frate(3) = -1.0;
    frate(4) = -1.0;
    
    if (ifinite == 1)
        fprintf(outfile,'how many terminal fixed rates on the left and right \n');
        nl = fscanf(infile,'%d',1);
        nr = fscanf(infile,'%d',1);
    end

    if (nl==1)
        fprintf(outfile,' enter the rate on the left \n');
        frate(2) = fscanf(infile,'%lf',1);
    elseif (nl==2)
        fprintf(outfile,' enter the two rates on the left ');
        frate(1) = fscanf(infile,'%lf',1);
        frate(2) = fscanf(infile,'%lf',1);
    end
    if (nr==1)
        fprintf(outfile,' enter the rate on the right \n');
        frate(3) = fscanf(infile,'%lf',1);
    elseif (nr==2)
        fprintf(outfile,' enter the two rates on the right \n');
        frate(3) = fscanf(infile,'%lf',1);
        frate(4) = fscanf(infile,'%lf',1);
    end
    fprintf(outfile,'enter time(0) and the end time for each interval \n');
    for i = 1 : k+1
        time(i) = fscanf(infile,'%lf',1);
    end

    
    while 1==1
        fprintf(outfile,' enter number of ismooth iterations \n');
        niter = fscanf(infile,'%lf',1);
        k2pn = k*(2^niter);
        if (k2pn > 2147483647)
            fprintf(outfile,' Warning:  The arrays ratenew and timenew are \n');
            fprintf(outfile,'     dimensioned for no more than 2147483647 \n\n');
        else
            break
        end
    end
    
    ratenew = zeros(k2pn+1,1);
    timenew = zeros(k2pn+1,1);
	
    fclose(infile);
	
    %output initial function
	figure
    subplot(1,niter+1,1);
    stairs(time(1:k+1),[rate(1:k);rate(k)]);
    xlabel('time t');
    ylabel('rate function');
    title('The Rate Function Plot');
	
	% ...compute the smoothed rates and associated times
    [timenew,ratenew,obj] = ...
        ismooth(k,time,rate,ifinite,frate,niter,timenew,ratenew,outfile);
    fprintf(outfile,'\n ..... I-SMOOTH Results ..... \n');
    fprintf(outfile,' # of rates, k = %d \n', k);
    fprintf(outfile,' rates = ');
    for i = 1 : k
        fprintf(outfile,'%.16f ',rate(i));
    end
    fprintf(outfile,'\n');
    if (ifinite==0)
        fprintf(outfile,' cyclic context \n');
    else
        fprintf(outfile,' finite-horizon context \n');
        if (nl > 0)
            fprintf(outfile,' left-side fixed rates: %.16f %.16f \n', frate(1), frate(2));
        end
        if (nr > 0) 
            fprintf(outfile,' right-side fixed rates: %.16f %.16f \n', frate(3), frate(4));
        end
    end
    fprintf(outfile,' objective-function value = %.16f \n', obj);
    k2pn = k*(2^niter);
    fprintf(outfile,' number of new intervals = %d \n', k2pn);
    fprintf(outfile,' new intervals: number, begin time, end time, rate... \n\n');

    for i = 1 : k2pn
        fprintf(outfile,'%d %.16f %.16f %.16f \n', i,timenew(i),timenew(i+1),ratenew(i));
    end

    %update the range of all plots
    for i = 1 : niter+1
        subplot(1,niter+1,i);
        xlim([time(1) time(k+1)]);
        ylim([min(ratenew) max(ratenew)+0.1]);
    end
    
    fclose(outfile);
end

function [time,rate,obj] = ...
    ismooth(k0,time0,rate0,ifinite0,frate0,niter,time,rate,outfile)
%
%     huifen chen and bruce schmeiser, may 12, 2011.
%     purpose: execute niter iterations of the i-smooth algorithm.
%     input:  k0       = number of initial time intervals
%             time0    = vector of initial times
%             rate0    = vector of initial rates
%             ifinite0 = 0 if cyclic, 1 if finite-horizon context
%             frate0   = vector of four initial terminal fixed rates
%             niter    = number of i-smooth iterations
%     output: time     = vector of (k  2^niter) new times
%             rate     = vector of (k  2^niter) new rates
%             obj      = objective function (from the last iteration)
%
    frate = zeros(4,1);
    gamma = zeros(k0*(2^niter),1);
    fprintf(outfile,' ...beginning ismooth\n');
    k = k0;
    ifinite = ifinite0;
    time0(0+1) = time0(0+1);
    for i = 1 : k
        rate(i) = rate0(i);
        time(i+1) = time0(i+1);
    end
    for i = 1 : 4
        frate(i) = frate0(i);
    end
    
    %...i-smooth's main loop
    for j = 1 : niter
        fprintf(outfile,'\n    ISMOOTH: ITERATION = %d \n', j);
        
        %  ...smooth the rates by doubling the number of intervals 
        [gamma,obj] = ...
            smooth(k,rate,ifinite,frate,gamma,outfile);
        gamma      % fen
        
        % ...compute the 2k new rates and times 
        for i = 1 : k
            rate(2*(k-i)+2) = rate(k-i+1) + gamma(k-i+1);
            rate(2*(k-i)+1) = rate(k-i+1) - gamma(k-i+1);
            time(2*(k-i)+2  +1) = time(k-i+1  +1);
            time(2*(k-i)+1  +1) = ( time(k-i+1  +1) + time(k-i  +1) ) / 2.;
        end
		
        % ...update the terminal fixed rates on both ends
        if ((ifinite == 1) && (j == 1))
            frate(1) = frate(2);
            frate(4) = frate(3);
        end
        k = 2*k;
        
        for i = 1 : k
            fprintf(outfile,'%d %.16f %.16f %.16f \n', i, time(i-1 +1), time(i +1), rate(i));
        end
		%plot figure
        subplot(1,niter+1,j + 1);
		stairs(time(1:k+1),[rate(1:k);rate(k)]);
        xlabel('time t');
        ylabel('rate function');
        title('The Rate Function Plot');
    end
end

function [gamma0,obj] = ...
    smooth(k0,rate0,ifinite0,frate0,gamma0,outfile)
%
%     huifen chen and bruce schmeiser, may 12, 2011.
%     purpose: one iteration of the i-smooth algorithm.
%     input:  k0       = number of initial time intervals
%             rate0    = vector of initial rates
%             ifinite0 = 0 if cyclic, 1 if finite-horizon context
%             frate0   = vector of four initial terminal fixed rates
%     output: gamma0   = vector of k0 rates increments
%             obj      = objective-function value
%
    
    ibegin = 0;
    iend = 0;
    nl = 0;
    nr = 0;

    frate = zeros(4,1);
    
    rate = zeros(k0,1);
    gamma = zeros(k0,1);
    ilocked = zeros(k0,1);
    isolved = zeros(k0,1);
    
    fprintf(outfile,' ...beginning smooth \n');
    
    % ...initialize the ilocked vector: 1 implies locked, else 0
    nlocked = 0;
    for i = 1 : k0
        ilocked(i) = 0;
        if (rate0(i) <= 0)
            gamma0(i) = 0;
            ilocked(i) = 1;
            nlocked = nlocked + 1;
        end
    end
    
    while 1 == 1
        % ...outer loop.  constrained optimization.
        for i = 1 : k0
            isolved(i) = 0;
            if (ilocked(i) == 1)
                isolved(i) = 1;
            end
        end
        nsolved = nlocked;
        
        while(nsolved < k0)
            % ...determine ibegin and iend
            [ibegin,iend] = ...
                scan(k0,ifinite0,isolved,nsolved,ibegin,iend,outfile);
            
            
            % ...set up the problem from ibegin to iend
            [k,ifinite,rate,frate,nl,nr] = ...
                problem(k0,ifinite0,rate0,frate0,isolved,gamma0,...
                        ibegin,iend,rate,frate,nl,nr,outfile);
                    
            % ...perform unconstrained (negative is ok) smoothing
            if (ifinite == 0)
                gamma = csmooth(k,rate,gamma,outfile);
            else
                gamma = fsmooth(k,rate,frate,nl,nr,gamma,outfile);
            end
            
            % ...set the gamma values and indicate solved
            j = 1;
            i = ibegin;
            while 1 == 1
                gamma0(i) = gamma(j);
                isolved(i) = 1;
                nsolved = nsolved + 1;
                if (i ~= iend)
                    j = j + 1;
                    i = i + 1;
                    if (i > k0)
                        i = i - k0;
                    end
                    continue;
                end
                break;
            end
            %
            %fprintf(outfile,'\n');
            %fprintf(outfile,' in smooth...\n');
            %fprintf(outfile,'    k0, ifinite0 = %d %d \n', k0, ifinite0);
            %fprintf(outfile,'    frate0  = ');
            %for i = 1 : 4
            %    fprintf(outfile,'%.16f ', frate0(i));
            %end
            %fprintf(outfile,'\n');
            %fprintf(outfile,'    rate0   =');
            %for i = 1 : k0
            %    fprintf(outfile,'%.16f ', rate0(i));
            %end
            %fprintf(outfile,'\n');
            %fprintf(outfile,'    gamma0  =');
            %for i = 1 : k0
            %	 fprintf(outfile,'%.16f ', gamma(i));
            %end
            %fprintf(outfile,'\n');
            %fprintf(outfile,'    isolved =');
            %for i = 1 : k0
            %    fprintf(outfile,' %d', isolved(i));
            %end
            %fprintf(outfile,'\n');
            %fprintf(outfile,'    ilocked =');
            %for i = 1 : k0
            %fprintf(outfile,' %d', ilocked(i));
            %end
            %fprintf(outfile,'\n');
        end
        
        % ...push the most-negative rate to zero.  update gamma and lock.
        [rate0,gamma0,ipush] = pushup1(k0,rate0,gamma0,outfile);
        % pushup2( k0, rate0, ifinite0, frate0, gamma0,outfile);
        if (ipush > 0)
            ilocked(ipush) = 1;
            nlocked = nlocked + 1;
            
            %
            %fprintf(outfile,'\n');
            %fprintf(outfile,' in smooth, after pushup...\n');
            %fprintf(outfile,'    gamma0 =');
            %for i = 1 : k0
            %    fprintf(outfile,' %,16f', gamma0(i));
            %end
            %fprintf(outfile,'\n');
            %fprintf(outfile,'    isolved =');
            %for i = 1 : k0
            %    fprintf(outfile,' %,16f', isolved(i));
            %end
            %fprintf(outfile,'\n');
            %fprintf(outfile,'    ilocked =');
            %for i = 1 : k0
            %    fprintf(outfile,' %,16f', ilocked(i));
            %end
            %fprintf(outfile,'\n');
            %
            if (nlocked < k0)
                continue
            end
        end
        break;
    end
    obj = objfunc(k0,rate0,ifinite0,frate0,gamma0,outfile);
end

function [ibegin,iend] = ...
    scan(k,ifinite,isolved,nsolved,ibegin,iend,outfile)
%
%     huifen chen and bruce schmeiser, may 12, 2011.
%     purpose: scan isolved for the first sequence of unsolved intervals
%     input:   k       = number of intervals
%              ifinite = 0 if cyclic, 1 if finite-horizon context
%              isolved = vector of indicators: 1 if solved, 0 if unsolved
%              nsolved = the number of intervals that are solved: less than k
%     output:  ibegin  = intervals ibegin through interval iend are unsolved
%              iend    = see ibegin
%                        (if cyclic context, then possibly iend < ibegin.)
%
    fprintf(outfile,'   ...beginning scan \n');
    %fprintf(outfile,'        k, ifinite, nsolved = %d, %d, %d\n', k,ifinite,nsolved);
    %fprintf(outfile,'        isolved    = ');
    %for i = 1 : k
    %    printf(' %d', isolved(i));
    %end
    %printf('\n');
    
    if (nsolved == 0)
        % ...no intervals are solved
        ibegin = 1;
        iend = k;
    elseif (nsolved == k)
        % ...all intervals are solved.  should not have called "scan".
        %fprintf(outfile,' *****error: nsolved, k = %d, %d', nsolved, k); 
        return
    else
		% ...1 .le. nsolved .lt. k.  determine the left-most solved interval
        i = 0;
        while 1 == 1
            i = i + 1;
            if (isolved(i) == 0)
                continue
            end
            isolve1 = i;
            nfound = 1;
            iend = isolve1 - 1;
            if (isolve1 == 1)
                iend = k;
            end
            if (nsolved == 1)
                if (isolve1 == 1)
                    ibegin = 2;
                elseif (isolve1 == k)
                    ibegin = 1;
                else
                    if (ifinite == 0)
                        ibegin = isolve1 + 1;
                    else
                        ibegin = 1;
                    end
                end
            else
                % ...1 < nsolved.  repeatedly determine the next solved interval
                while 1 == 1
                    i = i + 1;
                    if (isolved(i) == 0)
                        continue
                    end
                    isolve2 = i;
                    nfound = nfound + 1;
                    if (isolve2 == isolve1 + 1)
                        isolve1 = isolve2;
                        if (nfound < nsolved)
                            continue
                        end
                        %...isolve2 is the right-most solved interval
                        if (isolve2 == k)
                            ibegin = 1;
                        else
                            ibegin = isolve2 + 1;
                            if (ifinite == 1)
                                iend = k;
                            end
                        end
                    else
                        ibegin = isolve1 + 1;
                        iend = isolve2 - 1;
                    end
                    break;
                end
            end
            break;
        end
    end
    fprintf(outfile,'          isolved =');
    for i = 1 : k
        fprintf(outfile,' %d ', isolved(i));
    end
    fprintf(outfile,'\n');
    fprintf(outfile,'          ibegin, iend = %d %d \n', ibegin, iend);
end

function [k,ifinite,rate,frate,nl,nr ] = ...
    problem(k0,ifinite0,rate0,frate0,...
    ilock,gamma0,ibegin,iend,rate,frate,nl,nr,outfile) 
%
%     huifen chen and bruce schmeiser, may 12, 2011.
%     purpose: set up the next problem
%     input:  k0       = number of initial time intervals
%             ifinite0 = 1 if finite horizon, 0 if cyclic
%             rate0    = vector of initial rates
%             frate0   = vector of four initial terminal fixed rates
%             ilock    = vector of locked/unlocked indicators
%             gamma0   = current interval increments
%             ibegin   = first interval of the next problem
%             iend     = last interval of the next problem
%     output: k        = number of intervals in the new problem
%             ifinite  = 1 if finite horizon, 0 if cyclic
%             rate     = vector of rates for the new problem
%             frate    = vector of fixed rates
%             nl       = number of fixed rates on the left side
%             nr       = number of fixed rates on the right side
%
    
    fprintf(outfile,'   ...beginning problem  \n');
    
    % ...create the rate vector and determine k
    k = 1;
    i = ibegin;
    while 1 == 1
        rate(k) = rate0(i);
        if (i ~= iend)
            i = i + 1;
            if (i > k0)
                i = i - k0;
            end
            k = k + 1;
            continue;
        end
        break;
    end
    %fprintf(outfile,'        k, ibegin, iend = %d %d %d \n', k, ibegin, iend); 
    
    % ...determine horizon context.  if cyclic, create problem and return
    if ( (ifinite0 == 0) && (k == k0))
        ifinite = 0;
        return;
    end
    ifinite = 1;
    
    %
    %      ...determine fixed rates for the finite-horizon problem
    % 
    %      ...left-side fixed rates
    %
    nl = 0;
    if ( (ibegin == 1) && (ifinite0 == 1))
        frate(1) = frate0(1);
        frate(2) = frate0(2);
        if (frate(2) >= 0)
            nl = 1;
        end
        if ((nl == 1) && (frate(1) >= 0))
            nl = 2;
        end
    else
        ibeginm1 = ibegin - 1;
        if (ibeginm1 < 1)
            ibeginm1 = k0;
        end
        if (ilock(ibeginm1) == 1)
            frate(1) = rate0(ibeginm1) - gamma0(ibeginm1);
            frate(2) = rate0(ibeginm1) + gamma0(ibeginm1);
            nl = 2;
        end
    end
    
    % ...right-side fixed rates
    nr = 0;
    if ((iend == k0) && (ifinite0 == 1))
        frate(3) = frate0(3);
        frate(4) = frate0(4);
        if(frate(3) >= 0)
            nr = 1;
        end
        if ((nr == 1) && (frate(4) >= 0))
            nr = 2;
        end
    else
        iendp1 = iend + 1;
        if (iendp1 > k0)
            iendp1 = 1;
        end
        if (ilock(iendp1) == 1)
            frate(3) = rate0(iendp1) - gamma0(iendp1);
            frate(4) = rate0(iendp1) + gamma0(iendp1);
            nr = 2;
        end
    end
end

function gamma = ...
    fsmooth(k,rate,frate,nl,nr,gamma,outfile)
%
%     huifen chen and bruce schmeiser, may 15, 2011.
%     purpose: compute the optimal gamma value for the finite-horizon
%              context without considering the nonnegativity constraint.
%     input:  k     = the number of time intervals
%             rate  = vector of initial rates
%             frate = vector of four initial terminal fixed rates
%             nl    = number of fixed rates on the left side
%             nr    = number of fixed rates on the right side
%     output: gamma = the optimal gamma vector
%

    kexact = 100;
    fourth = 0.25;
    half = 0.5;
    threef = 0.75;
    two = 2.0;
    three = 3.0;
    eight = 8.0;
    third = 1.0/3.0;
    
    p3 = zeros(k+3+1,1); %NOTE: indice should +1 to match the C code
    fprintf(outfile,'\n ...beginning fsmooth\n');
    
    %...define fixed-rate indicators
    I_L1 = 0;
    if (nl == 1)
        I_L1 = 1;
    end
    I_L2 = 0;
    if (nl == 2)
        I_L2 = 1;
    end
    I_Lge1 = 0;
    if (nl >= 1) 
        I_Lge1 = 1;
    end
    I_R1 = 0;
    if (nr == 1)
        I_R1 = 1;
    end
    I_R2 = 0;
    if (nr == 2)
        I_R2 = 1;
    end
    I_Rge1 = 0;
    if (nr >= 1)
        I_Rge1 = 1;
    end
    
    if (k == 1)
        %...compute the optimal gamma for k = 1 and return
        if ((nl == 0) && (nr == 0))
            gamma(1) = 0.0;
        else
            const1 = 1.0 / (9.0*( I_Lge1 + I_Rge1 ) + ( I_L2 + I_R2 ) );
            gamma(1) = const1 * ( ...
                                               I_L2           *  frate(1) ...
                  - ( 3 * I_Lge1 +        2 *  I_L2 )         *  frate(2) ...
                  + ( 3 *(I_Lge1 - I_Rge1 ) +  I_L2 - I_R2 )  *   rate(1) ...
                  + ( 3 *          I_Rge1 +      2  * I_R2 )  *  frate(3) ...
                  -                                   I_R2    *  frate(4) );
        end
        return;
    end
    
    %
    %   ...otherwise, k > 1...
    % 
    %   ...compute k_ring: the number of complete time intervals 
    %        (including the fixed rates at both ends)
    %
    k_ring = k + I_L2 + I_R2;
    
    % ...compute and save powers of three
    p3(0 +1) = 1.0;
    for i = 1 : (k_ring+1)
        p3(i +1) = 3.0* p3(i-1 +1);
    end
    
    % ...compute denominator
    if (k > kexact)
        % ...for k > kexact, use the large-k approximation
        const1 = fourth / 17.0^(I_L1 + I_R1);
    else
        % ...use the exact computation
        tmp1 = 17.0^( (I_L1 + I_R1)) * p3(k_ring - 1  +1);
        tmp2 = (-1.0)^( (I_Lge1 + I_Rge1)) / p3(k_ring -1 +1);
        const1 = fourth / (tmp1 - tmp2);
    end
    
    % ...compute the optimal gamma vector.  
    for i = 1 : k
        gamma(i) = 0.0;
        i_tilde = i + I_L2;
        I_one = 0;
        if (i == 1)
            I_one = 1;
        end
        I_k = 0;
        if (i == k)
            I_k = 1;
        end
        
        %
        %  ...lambda_{-1} = frate(1), the outer-left fixed rate
        %     the weight is zero when nl is not equal to 2.
        %
        if (k > kexact)
            weight = const1 * two * I_L2 * (-1.0)^(i-1) ...
                            * (17.0^I_R1)/p3(i_tilde +1);
            %if (i == 1)
            %    fprintf(outfile,' -1 approx: k, weight = %d %.16f \n', k, weight);
            %end
        else
            if (k_ring - i_tilde - 1 < 0)
                tmp1 = 17.0^I_R1 / p3(i_tilde - k_ring + 1  +1);
            else
                tmp1 = 17.0^I_R1 * p3(k_ring - i_tilde - 1  +1);
            end
            tmp2 = (-1.0)^I_Rge1 / p3(k_ring - i_tilde + 1  +1);
            weight = const1 * two * I_L2 *(-1.0)^(i-1) * (tmp1+tmp2);
            %fprintf(outfile,'  -1 exact: weight = %.16f\n',weight);
        end
        gamma(i) = gamma(i) + frate(1) * weight;
        
        %
        %   ...lambda_0 = frate(2), the inner-left fixed rate
        %   the weight is zero when nl = 0.   
        %
        if (k > kexact)
            weight = const1 * (-1.0)^i * 17.0^I_R1 ...
                     *  (   threef * I_Lge1  +  half *  I_L2) ...
                     *  (   17.0   ^ I_L1    *  3.0  ^  I_L2 ...
                         + (-1.0)  ^ I_Lge1 *  3.0  ^(-I_L2) ) ...
                                  / p3(i_tilde -1  +1);
            %if (i == 1)
            %    fprintf(outfile,'  0 approx: k, weight = %d %.16f\n',k,weight);
            %end
        else
            weight = const1 * (threef*I_Lge1 + half*I_L2) * (-1.0)^i ...
                  * (  17.0  ^ I_L1    *  3.0  ^   I_L2 ...
                      +(-1.0) ^ I_Lge1 *  3.0  ^ (-I_L2) )...
                  * (  17.0  ^ I_R1    *  p3(k_ring-i_tilde  +1) ...
                      +(-1.0) ^ I_Rge1 / p3(k_ring-i_tilde  +1));
            %fprintf(outfile,'  0 exact: weight = %.16f\n',weight);
        end
        gamma(i) = gamma(i) + frate(2) * weight;
        
        % ...lambda_1 = rate(1)
        if (k > kexact)
            tmp1 = threef * I_Lge1 + fourth * I_L2;
            weight = const1 * (-1.0)^i * 17.0^I_R1 ...
                * ( 1 - ( third + tmp1 ) * I_one) ...
                  * (       17.0^I_L1 * 3.0^I_L2 ...
                  * ( 1 - ( three + tmp1 ) * (1-I_one) ) ...
                  + (-1.0)^I_Lge1 ...
                  * ( 1 - ( third + tmp1 ) * (1-I_one) ) / 3.0^I_L2 ...
                )  /p3(i_tilde - 1  +1);
            %if (i == 1)
            %    fprintf(outfile,'  1 approx: k, weight = %d %.16f\n',k,weight);
            %end
        else
            weight = const1 * (-1.0)^i ...
                ...
                * (  17.0^I_L1 * 3.0^I_L2 ...
                  * ( 1 - (three + threef*I_Lge1 + fourth*I_L2) * (1-I_one) ) ...
                  + (-1.0)^I_Lge1 ...
                  * ( 1 - (third + threef*I_Lge1 + fourth*I_L2) * (1-I_one) ) ...
                                         /(3.0^I_L2)                     ) ...
                ...                         
                * (  17.0^I_R1 * p3(k_ring - i_tilde  +1) ...
                    * ( 1 - (third + threef*I_Lge1 + fourth*I_L2) * I_one) ...
                    + (-1.0)^I_Rge1 ...
                    * ( 1 - (three + threef*I_Lge1 + fourth*I_L2) * I_one) ...
                                         /p3(k_ring - i_tilde  +1) ) ;
            %fprintf(outfile,'  1 exact: weight = %.16f\n',weight);
        end
        gamma(i) = gamma(i) + rate(1) * weight;
            
        % ...lambda_2 to lambda_{i-1}
        for m = 2 : (i-1)
            if (k > kexact)
                m_tilde = m + I_L2;
                weight = const1* (-1.0) ^ (m-i) * eight ...
                     *( 17.0^(I_R1 + I_L1) / p3(i_tilde - m_tilde + 1  +1) ...
                      - 17.0^ I_R1 * (-1.0)^I_Lge1 ...
                         /(p3(i_tilde  +1)*p3(m_tilde - 1  +1)) ...
                      + 17.0^ I_L1 * (-1.0)^I_Rge1 ...
                         /(p3(k_ring-m_tilde  +1) * p3(k_ring-i_tilde + 1  +1) ) );
                %fprintf(outfile,' m approx:m,k,weight = %d %d %.16f\n', m, k, weight);
            else
                tmp1 =   17.0^I_R1    * p3(k_ring-i_tilde  +1) ...
                      +(-1.0)^I_Rge1  / p3(k_ring-i_tilde  +1);
                tmp2 =   17.0^I_L1    * p3(m - 2 + I_L2  +1) ...
                      -(-1.0)^I_Lge1  / p3(m     + I_L2  +1);
                weight = const1 * eight * (-1.0)^(m-i) * tmp1 * tmp2;
                %fprintf(outfile,'  2--i-1 exact: weight = %.16f\n', weight);
            end
            gamma(i) = gamma(i) + rate(m) * weight;
        end
        
        if ( (i ~= 1) && (i ~= k))
            % ...lambda_i = rate(i), when i is neither 1 nor k
            if (k > kexact)
                
                weight = const1 * eight * ...
                    ( 17.0^I_L1 * (-1.0)^I_Rge1 ...
                        / ( p3(k_ring - i_tilde  +1) * p3(k_ring - i_tilde + 1  +1) ) ...
                    - 17.0^I_R1 * (-1.0)^I_Lge1...
                        / ( p3(i_tilde  +1) * p3(i_tilde - 1  +1) ) );
                %fprintf(outfile,'  i approx: k, weight = %d %.16f\n',k, weight);
            else
                if (2*i_tilde - k_ring - 2 > 0)
                    tmp1 =       p3(2*i_tilde - k_ring - 2  +1); 
                else
                    tmp1 = 1.0 / p3(k_ring - 2*i_tilde + 2  +1);
                end
                
                if (k_ring - 2*i_tilde > 0)
                    tmp2 =       p3(k_ring - 2*i_tilde  +1); 
                else
                    tmp2 = 1.0 / p3(2*i_tilde - k_ring  +1);
                end
                weight = const1 * eight ...
                      *( 17.0^I_L1  *(-1.0)^I_Rge1 * tmp1 ...
                        -17.0^I_R1 *(-1.0)^I_Lge1 * tmp2 );
                %fprintf(outfile,'  i exact: weight = %.16f \n', weight);
            end
            gamma(i) = gamma(i) + rate(i) * weight;
        end
        
        % ...lambda_{i+1} to lambda_{k-1}
        for m = (i+1) : (k-1)
            if (k > kexact)
                m_tilde = m + I_L2;
                weight = const1 * (-1.0)^(m-i-1) * 8 ...
                    * ( 17.0^(I_R1 + I_L1) / p3(m_tilde - i_tilde + 1  +1) ...
                      + 17.0^I_R1 * (-1.0)^I_Lge1 ...
                         / (p3(i_tilde  +1)* p3(m_tilde - 1  +1) ) ...
                      - 17.0^I_L1 * (-1.0)^I_Rge1 ...
                         / (p3(k_ring - i_tilde  +1) * p3(k_ring - m_tilde + 1  +1) ) );
                %if (i == 1)
                %    fprintf(outfile,' m approx: m, k,weight = %d %d %.16f \n', m, k, weight);
                %end
            else
                tmp1 =    17.0 ^I_L1    *p3(i_tilde - 1  +1) ...
                       + (-1.0)^I_Lge1  / p3(i_tilde - 1  +1);
                tmp2 =    17.0 ^I_R1    *p3(k - m - 1 + I_R2  +1) ...
                       - (-1.0)^I_Rge1  / p3(k - m + 1 + I_R2  +1);
                weight = const1 * eight * (-1.0)^(m-i-1) * tmp1 * tmp2;
                %fprintf(outfile,'  i+1--k-1 exact: weight = %.16f \n', weight);
            end
            gamma(i) = gamma(i) + rate(m) * weight;
        end
         
        % ...lambda_k = rate(k)
        if (k > kexact)
            weight = const1 * (-1.0)^(k-i) * 17.0^I_L1 ...
                  *  ( 1 - (third + threef*I_Rge1 + fourth*I_R2) * I_k) ...
                  *  ( 17.0^I_R1 * 3.0^I_R2 ...
                  *  ( 1 - (three + threef*I_Rge1 + fourth*I_R2) * (1 - I_k) ) ...
                + (-1.0)^I_Rge1 ...
                  *  ( 1 - (third + threef*I_Rge1 + fourth*I_R2)  * (1 - I_k) ) ...
                   / 3.0^I_R2) ...
                / 3.0^(k_ring - i_tilde);
            %if (i == 1)
            %    fprintf(outfile,'  k approx: k, weight = %d %.16f\n',k,weight);
            %end
        else
            weight = const1 * (-1.0)^(k-i) ...
                ...
                * (         17.0 ^ I_L1 * p3(i_tilde-1  +1) ...
                    * ( 1 - ( third + threef*I_Rge1 + fourth*I_R2)* I_k ) ...
                         + (-1.0)^ I_Lge1 ...
                    * ( 1 - ( three + threef*I_Rge1 + fourth*I_R2)* I_k ) ...
                                        /p3(i_tilde - 1  +1) ) ...
                ...
                 *(         17.0 ^ I_R1 * 3.0^I_R2 ...
                    *( 1 - ( three + threef*I_Rge1 + fourth*I_R2)* (1-I_k) ) ...
                         + (-1.0)^ I_Rge1 ...
                    *( 1 - ( third + threef*I_Rge1 + fourth*I_R2)* (1-I_k) ) ...
                                        /3.0^I_R2 ) ;
            %fprintf(outfile,'  k exact: weight = %.16f\n',weight);
        end
        gamma(i) = gamma(i) + rate(k) * weight;
        
        % ...lambda_{k+1} = frate(3), the inner-right fixed rate
        if (k > kexact)
            weight = const1 * (-1.0)^(k-i) * 17.0^I_L1 ...
                * (threef *I_Rge1+half*I_R2) * (17.0^I_R1 ...
                *  3.0^I_R2 + (-1.0)^I_Rge1 / 3.0^I_R2 ) ...
                     / 3.0^(k_ring - i_tilde);
            %if (i == 1)
            %    fprintf(outfile,'  k+1 approx: k, weight = %d %.16f\n',k,weight);
            %end
        else
            weight = const1* (threef*I_Rge1+half*I_R2) * (-1.0)^(k-i) ...
                * (   17.0 ^ I_L1   * p3(i_tilde-1  +1) ...
                   + (-1.0)^ I_Lge1 / p3(i_tilde-1  +1) ) ...
                * (   17.0 ^ I_R1   * 3.0^I_R2 ...
                   + (-1.0)^ I_Rge1 / 3.0^I_R2 );
            %fprintf(outfile,'  k+1 exact: weight = %.16f\n', weight);
        end
        gamma(i) = gamma(i) + frate(3) * weight;
        
        % ...lambda_{k+2} = frate(4), the outer-right fixed rate
        if (k > kexact)
            weight = const1 * two * I_R2 *(-1.0)^(k-i-1) ...
                * 17.0 ^ I_L1 / p3(k_ring - i_tilde+1  +1);
            %if (i == 1)
            %    fprintf(outfile,'  k+2 approx: k, weight = %d %.16f\n', k, weight);
            %end
        else
            if (i_tilde < 2)
                tmp1 = 17.0^I_L1 / p3(2 - i_tilde  +1);
            else
                tmp1 = 17.0^I_L1 * p3(i_tilde - 2  +1);
            end
            tmp2 = (-1.0)^I_Lge1 / p3(i_tilde  +1);
            weight = const1 * two *I_R2 * (-1.0)^(k-i-1)*(tmp1+tmp2);
            %fprintf(outfile,'  k+2 exact: weight = %.16f\n',weight);
        end
        gamma(i) = gamma(i) + frate(4) * weight;
    end
end

function gamma = csmooth(k,rate,gamma,outfile)
%
%     huifen chen and bruce schmeiser, may 14, 2011.
%     purpose: compute the optimal gamma values for the cyclic 
%              context, ignoring the nonnegativity constraints.
%     input:  k     = dimension of gamma
%             rate  = vector of initial rates
%     output: gamma = optimal gamma vector 
%
    kexact = 100;
    
    fprintf(outfile,'\n   ...beginning csmooth\n');
    
    if (k <= kexact)
        % ...exact formula
        power1 = (-3.0)^(k-2);
        power2 = 1.0;
        const1 = 2.0 / (9.0 * power1 - power2);
    else
        % ...approximation to avoid overflow when k is large
        power1 = 1.0;
        power2 = 0.0;
        const1 = 2.0/9.0;
    end
    
    for i = 1 : k
        gamma(i) = 0.0;
    end
    
    for j = 1 : floor((k-1)/2)
        weight = const1 * (power1 - power2);
        for i = 1 : k
            ipj = i + j;
            imj = i - j;
            if (ipj > k)
                ipj = ipj - k;
            end
            if (imj < 1)
                imj = imj + k;
            end
            gamma(i) = gamma(i) + weight * (rate(ipj) - rate(imj));
        end
        power1 = power1 / (-3.0);
        power2 = power2 *(-3.0);
    end
end

function objfunc1 = ...
    objfunc(k,rate,ifinite,frate,gamma,outfile)
%
%     huifen chen and bruce schmeiser, may 14, 2011.
%     purpose: compute the objective-function value
%     input:  ifinite  = 1 if finite horizon, 0 if cyclic
%             k        = dimension of gamma
%             rate     = vector of initial rates
%             frate    = four fixed rates, left to right
%             gamma    = vector of rate increments
%     output: objfunc1 = objective-function value
%
    objfunc1 = 0.0;
    for i = 1 : (k-1)
        tmp1 = rate(i) - rate(i+1) + 3.0*gamma(i) + gamma(i+1);
        tmp2 = rate(i) - rate(i+1) + gamma(i) + 3.0*gamma(i+1);
        objfunc1 = objfunc1 + tmp1^2 + tmp2^2;
    end
    
    if (ifinite == 0)
        % ...cyclic context
        tmp1 = rate(k) - rate(1) + 3.0*gamma(k) + gamma(1);
        tmp2 = rate(k) - rate(1) + gamma(k) + 3.0*gamma(1);
        objfunc1 = objfunc1 + tmp1^2 + tmp2^2;
    else
		% ...finite-horizon context (left- and right-side fixed rates)
        if (frate(2) >= 0.0)
            tmp1     = frate(2) - rate(1) + 3.0*gamma(1);
            objfunc1 = objfunc1 + tmp1^2;
            if (frate(1) >= 0.0)
                tmp2 =     -frate(1) + 2.0*frate(2) - rate(1) + gamma(1);
                objfunc1 = objfunc1 + tmp2^2;
            end
        end
        
        if (frate(3) >= 0.0)
            tmp1 =     rate(k) - frate(3) + 3.0*gamma(k);
            objfunc1 = objfunc1 + tmp1^2;
            if (frate(4) >= 0.0)
                tmp2 =     rate(k) - 2.0*frate(3) + frate(4) + gamma(k);
                objfunc1 = objfunc1 + tmp2^2;
            end
        end
    end
end

function [rate,gamma,ipush] = pushup1(k,rate,gamma,outfile)
%
%     huifen chen and bruce schmeiser, may 12, 2011.
%     purpose: push the most-negative rate up to zero.
%     input:  k, the number of time intervals.
%             rate: vector of rates
%             gamma: vector of rate shifts
%     output: gamma: updated gamma vector
%             ipush: index of the pushed gamma value, 0 if none
%
    fprintf(outfile,'   ...beginning pushup\n');
    ratemin = 0.0;
    ipush = 0;
    for i = 1 : k
        rmag = rate(i) - abs(gamma(i));
        if (rmag < ratemin)
            ratemin = rmag;
            ipush = i;
            fprintf(outfile,' ratemin=%.16f, ipush = %d \n', ratemin, ipush);
        end
    end
    
    % ...push the most-negative rate, if any, to zero
    if (ipush > 0)
        if (gamma(ipush) < 0.0)
            gamma(ipush) = -rate(ipush);
        else
            gamma(ipush) = rate(ipush);
        end
    end
    
    %fprintf(outfile,'                                   ipush = %d \n', ipush);
    %if (ipush > 0)
    %    fprintf(outfile,'          gamma(ipush) = %.16f \n', gamma(ipush));
    %end
end

function [rate,ifinite,frate,gamma,ipush] = ...
    pushup2(k,rate,ifinite,frate,gamma,outfile) %#ok<DEFNU>
%
%     huifen chen and bruce schmeiser, may 14, 2011.
%     purpose: push a negative new rate up to zero.
%              choose the rate that provides the 
%              smallest objective-function value.
%     input:  k, the number of time intervals.
%             rate: vector of rates
%             ifinite: 1 if finite horizon, 0 if cyclic
%             frate: fixed rates
%             gamma: vector of rate shifts
%     output: gamma: updated gamma vector
%             ipush: index of the pushed gamma value, 0 if none
%
    objmin = 0.0;
    bestg = 0.0;
    
    fprintf(outfile,'   ...beginning pushup\n');
    
    % ...if any, find the potential negative new rate to push up
    ipush = 0;
    for i = 1 : k
        % ...check the ith interval
        if (rate(i) - abs(gamma(i)) < 0.0)
            % ...the ith new rate would be negative
            saveg = gamma(i);
            if (gamma(i) < 0.0)
                gamma(i) = -rate(i);
            else
                gamma(i) = rate(i);
            end
            obj = objfunc(k,rate,ifinite,frate,gamma,outfile);
            if (ipush == 0)
                objmin = obj - 1.0;
            end
            if (obj > objmin)
                % ...looking for the interval with the largest obj
                objmin = obj;
                bestg = gamma(i);
                ipush = i;
            end
            gamma(i) = saveg;
        end
    end
    if (ipush > 0) 
        gamma(ipush) = bestg;
    end
end

