
/******************************************************/
/*    huifen chen and bruce schmeiser, may 12, 2011.  */
/*    purpose: driver test programm for i-smooth.     */
/******************************************************/

# include <stdio.h>
# include <math.h>
# include <malloc.h>

void smooth(int k0, double rate0[], int *ifinite0, double frate0[], 
      double gamma0[], double *obj);
void ismooth(int k0, double time0[], double rate0[], int *ifinite0, 
      double frate0[], int *niter, double time[], double rate[], 
      double *obj);
void scan(int k, int *ifinite, int isolved[], int *nsolved, 
      int *ibegin, int *iend );
void problem(int k0, int *ifinite0, double rate0[], double frate0[], 
      int *ilock, double gamma0[], int *ibegin, int *iend, int *k, 
      int *ifinite, double rate[], double frate[], int *nl, int *nr );
void fsmooth(int k, double *rate, double *frate, int *nl, int *nr,double *gamma );

void csmooth(int k,double *rate, double *gamma );
void pushup1(int k,double *rate,double *gamma,int *ipush );
void pushup2(int k,double *rate,int *ifinite,double *frate,double *gamma,
        int *ipush);
double objfunc(int k,double *rate,int *ifinite,double *frate,double *gamma );

int main()
{ 
      int    k, nl, nr, ifinite, niter, k2pn, i;
      double *rate, *ratenew, frate[5], *time, *timenew; 
      double obj = 0.;

      nl = 0;
      printf (" enter k, the number of rates \n");
      scanf("%d", &k);
      
      time = (double*)calloc(k+1,sizeof(double));
      rate = (double*)calloc(k+1,sizeof(double));

      printf (" enter the rate values \n");
      for (i=1; i<=k; i++)
      {
         scanf("%lf", &rate[i]);
      }
      printf (" enter context: 1 for finite horizon, 0 for cyclic \n");
      scanf("%d", &ifinite);
      frate[1] = -1.0;
      frate[2] = -1.0;
      frate[3] = -1.0;
      frate[4] = -1.0;    
      if (ifinite==1) 
      {
         printf("how many terminal fixed rates on the left and right \n");
         scanf("%d %d", &nl, &nr);
      }
      if (nl==1) 
      {
         printf(" enter the rate on the left \n");
         scanf("%lf", &frate[2]);
      } 
      else if(nl==2) 
      {
         printf(" enter the two rates on the left \n");
         scanf("%lf %lf", &frate[1], &frate[2] );
      }
      if (nr==1) 
      {
         printf(" enter the rate on the right \n");
         scanf("%lf", &frate[3]);
      } 
      else if(nr==2) 
      {
         printf(" enter the two rates on the right \n");
         scanf("%lf %lf", &frate[3], &frate[4] );
      }
      
      printf(" enter time(0) and the end time for each interval \n");
      for (i=0; i<=k; i++)
      {
         scanf("%lf", &time[i]);
      }
      
L10:  printf(" enter number of ismooth iterations \n");
      scanf("%d", &niter);
      k2pn = (int)(k * (pow(2.0, niter)));
      if (k2pn > 2147483647) 
      {
         printf(" Warning:  The arrays ratenew and timenew are \n");
         printf("    dimensioned for no more than 2147483647 \n\n");
         goto L10;
      }

      ratenew = (double*)calloc(k2pn+1,sizeof(double));
      timenew = (double*)calloc(k2pn+1,sizeof(double));
      
      // ...compute the smoothed rates and associated times
      ismooth(k,time,rate,&ifinite,frate,&niter,timenew,ratenew,&obj);
    

      printf("\n ..... I-SMOOTH Results ..... \n");
      printf(" # of rates, k = %d \n", k);
      printf(" rates = ");
      for (i=1; i<=k; i++)
      {
         printf("%lf ", rate[i]);
      }
      printf("\n");
      if (ifinite==0) 
      {
         printf(" cyclic context \n");       
      }
      else
      {
         printf(" finite-horizon context \n");
         if (nl > 0)
            printf(" left-side fixed rates: %lf %lf \n", frate[1], frate[2]);
         if (nr > 0) 
            printf(" right-side fixed rates: %lf %lf \n", frate[3], frate[4]);
      }
      printf(" objective-function value = %lf \n", obj);
      k2pn = k * ((int) pow(2., (double) niter) );
      printf(" number of new intervals = %d \n", k2pn);
      printf(" new intervals: number, begin time, end time, rate... \n\n");
      for (i=1; i<=k2pn; i++)
      {
         printf("%d %lf %lf %lf \n", i,timenew[i-1],timenew[i],ratenew[i]);
      }

      free(ratenew);
      free(timenew);
      return 0;
}


void ismooth(int k0, double time0[], double rate0[], int *ifinite0, 
      double frate0[], int *niter, double time[], double rate[], 
      double *obj)
/**********************************************************************
*     huifen chen and bruce schmeiser, may 12, 2011.
*     purpose: execute niter iterations of the i-smooth algorithm.
*     input:  k0       = number of initial time intervals
*             time0    = vector of initial times
*             rate0    = vector of initial rates
*             ifinite0 = 0 if cyclic, 1 if finite-horizon context
*             frate0   = vector of four initial terminal fixed rates
*             niter    = number of i-smooth iterations
*     output: time     = vector of (k * 2^niter) new times
*             rate     = vector of (k * 2^niter) new rates
*             obj      = objective function (from the last iteration)
***********************************************************************/
{
      int    k, ifinite, i, j;
      double frate[5], *gamma;
      gamma  =  (double*)calloc(k0*(int)pow(2.0,*niter),sizeof(double));
      printf(" ...beginning ismooth\n");
      k = k0;
      ifinite = *ifinite0;
      time[0] = time0[0];
      for(i=1; i<=k; i++)
      {
         rate[i] = rate0[i];
         time[i] = time0[i];
      }
      for(i=1; i<=4; i++)
         frate[i] = frate0[i];
      
      //...i-smooth's main loop
      for(j=1; j<=*niter; j++)
      {
         printf("\n    ISMOOTH: ITERATION = %d \n", j);

         // ...smooth the rates by doubling the number of intervals  
         smooth( k, rate, &ifinite, frate, gamma, obj );

         // ...compute the 2k new rates and times  
         for(i=1; i<=k; i++)
         {
            rate[2*(k-i)+2] = rate[k-i+1] + gamma[k-i+1];
            rate[2*(k-i)+1] = rate[k-i+1] - gamma[k-i+1];
            time[2*(k-i)+2] = time[k-i+1];
            time[2*(k-i)+1] = ( time[k-i+1] + time[k-i] ) / 2.;
         }

         // ...update the terminal fixed rates on both ends  
         if ((ifinite == 1) && (j == 1)) 
         {
            frate[1] = frate[2];
            frate[4] = frate[3];
         }
         k = 2*k;

         for(i=1; i<=k; i++)
         {
            printf("%d %lf %lf %lf \n", i, time[i-1], time[i], rate[i]);
         }
      }
      free(gamma);
}


void smooth(int k0, double rate0[], int *ifinite0, double frate0[], 
      double gamma0[], double *obj)
/**********************************************************************
*     huifen chen and bruce schmeiser, may 12, 2011.
*     purpose: one iteration of the i-smooth algorithm.
*     input:  k0       = number of initial time intervals
*             rate0    = vector of initial rates
*             ifinite0 = 0 if cyclic, 1 if finite-horizon context
*             frate0   = vector of four initial terminal fixed rates
*     output: gamma0   = vector of k0 rates increments
*             obj      = objective-function value
**********************************************************************/
{
      int    ifinite, nlocked, nsolved, ibegin, iend, nl, nr, ipush, i, j;
      double *rate, frate[5], *gamma;
      int *ilocked, *isolved;
      int k;

      rate   =  (double*)calloc((k0+1),sizeof(double));
      gamma  =  (double*)calloc((k0+1),sizeof(double));
      ilocked = (int*)calloc((k0+1),sizeof(int));
      isolved = (int*)calloc((k0+1),sizeof(int));
      ipush=0;
      printf(" ...beginning smooth \n");
 
      // ...initialize the ilocked vector: 1 implies locked, else 0
      nlocked = 0;
      for(i=1; i<=k0; i++)
      {
         ilocked[i] = 0;
         if (rate0[i] <= 0.) 
         {
             gamma0[i]  = 0.;
             ilocked[i] = 1;
             nlocked    = nlocked + 1;
         }
      }

L10:    

      // ...outer loop.  constrained optimization.
      for(i=1; i<=k0; i++)       
      {
         isolved[i] = 0;
         if (ilocked[i] == 1) 
            isolved[i] = 1;
      }
      nsolved = nlocked;

      while (nsolved < k0) 
      {
        // ...determine ibegin and iend
        scan( k0, ifinite0, isolved, &nsolved, &ibegin, &iend );

        // ...set up the problem from ibegin to iend
        problem( k0, ifinite0, rate0, frate0, isolved, gamma0, 
                &ibegin, &iend, &k, &ifinite, rate, frate, &nl, &nr );

        // ...perform unconstrained (negative is ok) smoothing
        if( ifinite == 0 ) 
        {
            csmooth( k, rate, gamma );
        } else {
            fsmooth( k, rate, frate, &nl, &nr, gamma );
        }

        // ...set the gamma values and indicate solved
        j = 1;
        i = ibegin;
L20:    gamma0[i]  = gamma[j];     
        isolved[i] = 1;        
        nsolved    = nsolved + 1;
        if (i != iend) 
        {
           j = j + 1;
           i = i + 1;
           if (i > k0) i = i - k0;
           goto L20;
        }

        /*
        printf("\n");
        printf(" in smooth...\n");
        printf("    k0, ifinite0 = %d %d \n", k0, *ifinite0);
        printf("    frate0  = ");
        for(i=1;i<=4;i++)
           printf("%lf ", frate0[i]);
        printf("\n");
        printf("    rate0   =");
        for(i=1;i<=k0;i++)
           printf(" %lf", rate0[i]);
        printf("\n");
        printf("    gamma0  =");
        for(i=1;i<=k0;i++)
           printf(" %lf", gamma0[i]);
        printf("\n");
        printf("    isolved =");
        for(i=1;i<=k0;i++)
           printf(" %d", isolved[i]);
        printf("\n");
        printf("    ilocked =");
        for(i=1;i<=k0;i++)
           printf(" %d", ilocked[i]);
        printf("\n");
        */

      }

      // ...push the most-negative rate to zero.  update gamma and lock.
      pushup1( k0, rate0, gamma0, &ipush );
      // pushup2( k0, rate0, ifinite0, frate0, gamma0, &ipush );
      if (ipush > 0) 
      {
         ilocked[ipush] = 1;
         nlocked        = nlocked + 1;

         /*
         printf("\n");
         printf(" in smooth, after pushup...\n");
         printf("    gamma0 =");
         for(i=1;i<=k0;i++)
            printf(" %lf", gamma0[i]);
         printf("\n");
         printf("    isolved =");
         for(i=1;i<=k0;i++)
            printf(" %d", isolved[i]);
         printf("\n");
         printf("    ilocked =");
         for(i=1;i<=k0;i++)
            printf(" %d", ilocked[i]);
         printf("\n");
         */

         if (nlocked < k0) goto L10;
      }
      *obj = objfunc( k0, rate0, ifinite0, frate0, gamma0 );
      free(rate);
      free(gamma);
      free(ilocked);
      free(isolved);
      return;
}



void scan(int k, int *ifinite, int isolved[], int *nsolved, 
          int *ibegin, int *iend )
/****************************************************************************
*     huifen chen and bruce schmeiser, may 12, 2011.
*     purpose: scan isolved for the first sequence of unsolved intervals
*     input:   k       = number of intervals
*              ifinite = 0 if cyclic, 1 if finite-horizon context
*              isolved = vector of indicators: 1 if solved, 0 if unsolved
*              nsolved = the number of intervals that are solved: less than k
*     output:  ibegin  = intervals ibegin through interval iend are unsolved
*              iend    = see ibegin
*                        (if cyclic context, then possibly iend < ibegin.)
*****************************************************************************/
{
      int i, nfound, isolve1, isolve2;

      printf("   ...beginning scan \n");
      
      /*
      printf("        k, ifinite, nsolved = %d, %d, %d\n", k,*ifinite,*nsolved);
      printf("        isolved    = ");
      for(i=1;i<=k;i++)
         printf(" %d", isolved[i]);
      printf("\n");
      */ 

      if (*nsolved == 0) 
      {
         // ...no intervals are solved
         *ibegin = 1;
         *iend   = k;
      } else if (*nsolved == k) {
         // ...all intervals are solved.  should not have called "scan".
         // printf(" *****error: nsolved, k = %d, %d', *nsolved, k); 
         return;
      } 
      else 
      {
         // ...1 .le. nsolved .lt. k.  determine the left-most solved interval
         i = 0;
L10:     i = i + 1;
         if (isolved[i] == 0)  goto L10;
         isolve1 = i;
         nfound  = 1;
         *iend    = isolve1 - 1;
         if (isolve1 == 1) *iend = k;
         if (*nsolved == 1) 
         {
            if (isolve1 == 1) 
               *ibegin = 2;
            else if (isolve1 == k) 
               *ibegin = 1;
            else
            {
               if (*ifinite == 0) 
                   *ibegin = isolve1 + 1;
               else
                   *ibegin = 1;
            }
         } else {
            // ...1 < nsolved.  repeatedly determine the next solved interval
L20:        i = i + 1;
            if (isolved[i] == 0) goto L20;
            isolve2 = i;
            nfound = nfound + 1;
            if (isolve2 == isolve1 + 1) 
            {
               isolve1 = isolve2;
               if (nfound < *nsolved) goto L20;
               //...isolve2 is the right-most solved interval
               if (isolve2 == k) 
                  *ibegin = 1;
               else
               {
                   *ibegin = isolve2 + 1;
                   if (*ifinite == 1) *iend = k;
               }
            } else {
               *ibegin = isolve1 + 1;
               *iend   = isolve2 - 1;
            }
         }
      }
      printf("          isolved =");
      for(i=1; i<=k; i++)
      {
         printf(" %d ", isolved[i]);
      }
      printf("\n");
      printf("          ibegin, iend = %d %d \n", *ibegin, *iend);
      return;
}



void problem(int k0, int *ifinite0, double rate0[], double frate0[], 
      int *ilock, double gamma0[], int *ibegin, int *iend, int *k, 
      int *ifinite, double rate[], double frate[], int *nl, int *nr )
/*********************************************************************
*     huifen chen and bruce schmeiser, may 12, 2011.
*     purpose: set up the next problem
*     input:  k0       = number of initial time intervals
*             ifinite0 = 1 if finite horizon, 0 if cyclic
*             rate0    = vector of initial rates
*             frate0   = vector of four initial terminal fixed rates
*             ilock    = vector of locked/unlocked indicators
*             gamma0   = current interval increments
*             ibegin   = first interval of the next problem
*             iend     = last interval of the next problem
*     output: k        = number of intervals in the new problem
*             ifinite  = 1 if finite horizon, 0 if cyclic
*             rate     = vector of rates for the new problem
*             frate    = vector of fixed rates
*             nl       = number of fixed rates on the left side
*             nr       = number of fixed rates on the right side
*********************************************************************/
{
      int i=0;
      int ibeginm1=0;
      int iendp1=0;

      printf("   ...beginning problem \n");

      // ...create the rate vector and determine k
      *k = 1;
      i = *ibegin;
L10:  rate[*k] = rate0[i];
      if (i != *iend) 
      {
         i = i + 1;
         if (i > k0) i = i - k0;
         *k = *k + 1;
         goto L10;
      }
      // printf("        k, ibegin, iend = %d %d %d \n", *k, *ibegin, *iend); 

      // ...determine horizon context.  if cyclic, create problem and return
      if ( (*ifinite0 == 0) && (*k == k0) ) 
      {
         *ifinite = 0;
         return;
      }
      *ifinite = 1;

      /*
      *     ...determine fixed rates for the finite-horizon problem
      *
      *     ...left-side fixed rates
      */
      *nl = 0;
      if ( (*ibegin == 1) && (*ifinite0 == 1) ) 
      {
         frate[1] = frate0[1];
         frate[2] = frate0[2];
         if (frate[2] >= 0.) *nl = 1;
         if ((*nl == 1) && (frate[1] >= 0.))  *nl = 2;
      } else {
         ibeginm1 = *ibegin - 1;
         if (ibeginm1 < 1) ibeginm1 = k0;
         if (ilock[ibeginm1] == 1) 
         {
            frate[1] = rate0[ibeginm1] - gamma0[ibeginm1];
            frate[2] = rate0[ibeginm1] + gamma0[ibeginm1];
            *nl = 2;
         }
      }

      // ...right-side fixed rates
      *nr = 0;
      if((*iend == k0) && *ifinite0 == 1)
      {
         frate[3]=frate0[3];
         frate[4]=frate0[4];
         if(frate[3] >= 0.0) *nr=1;
         if((*nr==1) && frate[4]>=0.0) *nr=2;
      }
      else
      {
         iendp1=*iend+1;
         if(iendp1 > k0) iendp1=1;
         if(ilock[iendp1] == 1) 
         {
            frate[3] = rate0[iendp1] - gamma0[iendp1];
            frate[4] = rate0[iendp1] + gamma0[iendp1];
            *nr=2;
         }
      }
      return;
}



void fsmooth(int k,double *rate, double *frate, int *nl, int *nr,double *gamma )
/************************************************************************
*     huifen chen and bruce schmeiser, may 15, 2011.
*     purpose: compute the optimal gamma value for the finite-horizon
*              context without considering the nonnegativity constraint.
*     input:  k     = the number of time intervals
*             rate  = vector of initial rates
*             frate = vector of four initial terminal fixed rates
*             nl    = number of fixed rates on the left side
*             nr    = number of fixed rates on the right side
*     output: gamma = the optimal gamma vector
************************************************************************/
{
      int    I_L1, I_L2, I_R1, I_R2, I_Lge1, I_Rge1, I_one, I_k, 
             k_ring, i_tilde, m_tilde, i, m;
      double *p3, tmp1, tmp2, weight, const1;

      int    kexact = 100;
      double fourth = 0.25, half = 0.5, threef = 0.75,
             two = 2.0, three = 3.0, eight = 8.0,
             third = 1.0/3.0;


      p3 = (double*)calloc(k+3+1,sizeof(double));
      printf("\n ...beginning fsmooth\n");

      //...define fixed-rate indicators
      I_L1   = 0;
      if (*nl == 1) I_L1   = 1;
      I_L2   = 0;
      if (*nl == 2) I_L2   = 1;
      I_Lge1 = 0;
      if (*nl >= 1) I_Lge1 = 1;
      I_R1   = 0;
      if (*nr == 1) I_R1   = 1;
      I_R2   = 0;
      if (*nr == 2) I_R2   = 1;
      I_Rge1 = 0;
      if (*nr >= 1) I_Rge1 = 1;
     
      if (k == 1)
      {
         //...compute the optimal gamma for k = 1 and return
         if ((*nl == 0) && (*nr == 0)) 
         {
            gamma[1] = 0.0;
         }
         else
         {
            const1 = 1.0 / ( 9.0*( I_Lge1 + I_Rge1 ) + ( I_L2 + I_R2 ) );
            gamma[1] = const1 * (         
                                             I_L2          * frate[1] 
               - ( 3 *   I_Lge1 +        2 * I_L2 )        * frate[2] 
               + ( 3 * ( I_Lge1 - I_Rge1 ) + I_L2 - I_R2 ) *  rate[1]
               + ( 3 *            I_Rge1 +      2 * I_R2 ) * frate[3] 
               -                                    I_R2   * frate[4] );
         }
         return;
      }

      /*
       *  ...otherwise, k > 1...
       *
       *  ...compute k_ring: the number of complete time intervals 
       *       (including the fixed rates at both ends)
       */
      k_ring = k + I_L2 + I_R2;
      
      // ...compute and save powers of three
      p3[0] = 1.0;
      for(i=1;i<=k_ring+1;i++)
         p3[i] = 3.0*p3[i-1];
      
      // ...compute denominator
      if (k > kexact) 
      {
         // ...for k > kexact, use the large-k approximation
         const1 = fourth / pow(17.0, (I_L1+I_R1));
      }
      else
      {
         // ...use the exact computation
         tmp1  = pow( 17.0, (I_L1   + I_R1)) * p3[k_ring - 1];
         tmp2  = pow( -1.0, (I_Lge1 + I_Rge1)) / p3[k_ring - 1];
         const1 = fourth / ( tmp1 - tmp2 );
      }
      
      // ...compute the optimal gamma vector.  
      for(i=1;i<=k;i++)
      {
        gamma[i] = 0.0;
        i_tilde = i + I_L2;
        I_one = 0;
        if (i == 1) I_one = 1;
        I_k = 0;
        if (i == k) I_k = 1;
        
        /*
         * ...lambda_{-1} = frate(1), the outer-left fixed rate
         *    the weight is zero when nl is not equal to 2.
         */
        if (k > kexact) {
           weight = const1 * two * I_L2 * pow( -1.0, i-1 ) 
                           * pow( 17.0, I_R1 ) / p3[i_tilde];
           // if(i==1) printf(" -1 approx: k, weight = %d %lf \n", k, weight);
        }
        else
        {
           if (k_ring - i_tilde - 1 < 0) 
           {
              tmp1 = pow( 17.0, I_R1 ) / p3[i_tilde - k_ring + 1];
           }
           else
           {
              tmp1 = pow( 17.0, I_R1 ) * p3[k_ring - i_tilde - 1];
           }
           tmp2   = pow( -1.0, I_Rge1 ) / p3[k_ring - i_tilde + 1];
           weight = const1 * two * I_L2 * pow( -1.0, i-1 ) * (tmp1+tmp2);
           // printf("  -1 exact: weight = %lf\n",weight);
        }
        gamma[i] = gamma[i] + frate[1] * weight;

        /*
         *  ...lambda_0 = frate(2), the inner-left fixed rate
         *  the weight is zero when nl = 0.   
         */
        if (k > kexact) {
            weight = const1 * pow( -1.0, i ) * pow( 17.0, I_R1 ) 
                      * (threef * I_Lge1 + half * I_L2) 
                      * (  pow( 17.0, I_L1 )   * pow( 3.0,  I_L2 ) 
                         + pow( -1.0, I_Lge1 ) * pow( 3.0, -I_L2 )  ) 
                                    / p3[i_tilde - 1];
            // if(i==1) printf("  0 approx: k, weight = %d %lf\n",k,weight);
        } 
        else
        {
            weight = const1 * (threef*I_Lge1 + half*I_L2)*pow( -1.0, i ) 
                  * (   pow( 17.0, I_L1)   * pow( 3.0,  I_L2 ) 
                      + pow( -1.0, I_Lge1) * pow( 3.0, -I_L2 )   )
                  * (   pow( 17.0, I_R1)   * p3[k_ring-i_tilde] 
                      + pow( -1.0, I_Rge1) / p3[k_ring-i_tilde] );
            // printf("  0 exact: weight = %lf\n",weight);
        }
        gamma[i] = gamma[i] + frate[2] * weight;
        
        // ...lambda_1 = rate(1)
        if (k > kexact) {
           tmp1 = threef * I_Lge1 + fourth * I_L2;
           weight = const1 * pow( -1.0, i ) * pow( 17.0, I_R1 )
              * ( 1 - ( third + tmp1 ) *I_one )
              * (       pow( 17.0, I_L1 ) * pow( 3.0, I_L2 )
              * ( 1 - ( three + tmp1 ) * (1-I_one) )
               + pow( -1.0, I_Lge1 ) 
              * ( 1 - ( third + tmp1 ) * (1-I_one) ) / pow( 3.0, I_L2 ) 
                                                   )    / p3[i_tilde - 1];
           // if(i==1) printf("  1 approx: k, weight = %d %lf\n",k,weight);
        }
        else
        {
           weight = const1 * pow( -1.0, i )

           * (    pow( 17.0, I_L1 ) * pow( 3.0, I_L2 )
             * ( 1 - (three + threef*I_Lge1 + fourth*I_L2) *(1-I_one) )
               + pow( -1.0, I_Lge1 ) 
             * ( 1 - (third + threef*I_Lge1 + fourth*I_L2) *(1-I_one) )
                                  / pow( 3.0, I_L2 )               )
 
           * (    pow( 17.0, I_R1 ) * p3[k_ring - i_tilde]
             * ( 1 - (third + threef*I_Lge1 + fourth*I_L2) * I_one )
               + pow( -1.0, I_Rge1 )
             * ( 1 - (three + threef*I_Lge1 + fourth*I_L2) * I_one )  
                                  / p3[k_ring - i_tilde]          );
           // printf("  1 exact: weight = %lf\n",weight);
        }
        gamma[i] = gamma[i] + rate[1] * weight ;

        // ...lambda_2 to lambda_{i-1}
        for(m=2;m<=i-1;m++)
        {
           if (k > kexact) 
           {
              m_tilde = m + I_L2;
              weight = const1 * pow(-1.0, m-i) * eight
              * ( pow(17.0, I_R1+ I_L1) / p3[i_tilde - m_tilde + 1]
                - pow(17.0, I_R1)*pow(-1.0, I_Lge1) 
                     / (p3[i_tilde] * p3[m_tilde - 1])
                + pow(17.0, I_L1)*pow(-1.0, I_Rge1) 
                     / ( p3[k_ring-m_tilde] * p3[k_ring-i_tilde+1] ) );
              // printf(" m approx:m,k,weight = %d %d %lf\n", m, k, weight);
           } else {
              tmp1 =   pow( 17.0, I_R1 )   * p3[k_ring-i_tilde] 
                     + pow( -1.0, I_Rge1 ) / p3[k_ring-i_tilde];
              tmp2 =   pow( 17.0, I_L1 )   * p3[m - 2 + I_L2] 
                     - pow( -1.0, I_Lge1 ) / p3[m     + I_L2];
              weight = const1 * eight * pow( -1.0, m-i ) * tmp1 * tmp2;
              //  printf("  2--i-1 exact: weight = %lf\n", weight);
           }
           gamma[i] = gamma[i] + rate[m] * weight;
        }

        if ( (i != 1) && (i != k) )
        {
          // ...lambda_i = rate(i), when i is neither 1 nor k
          if (k > kexact) 
          {

             weight = const1 * eight * 
                    ( pow(17.0, I_L1) * pow( -1.0, I_Rge1 ) 
                         / ( p3[k_ring - i_tilde] * p3[ k_ring - i_tilde+1]   )
                    - pow( 17.0, I_R1 ) * pow( -1.0, I_Lge1 ) 
                         / ( p3[i_tilde] * p3[i_tilde - 1] )  );
             // printf("  i approx: k, weight = %d %lf\n",k, weight);
          } else {
             if (2*i_tilde - k_ring - 2 > 0) 
             {
                 tmp1 =       p3[2*i_tilde - k_ring - 2];
             } else {
                 tmp1 = 1.0 / p3[k_ring - 2*i_tilde + 2];
             }

             if (k_ring - 2*i_tilde > 0)
             {
                 tmp2 =       p3[k_ring - 2*i_tilde];
             } else {
                 tmp2 = 1.0 / p3[2*i_tilde - k_ring];
             }
             weight = const1 * eight
                 * (  pow( 17.0, I_L1 ) * pow( -1.0, I_Rge1 ) * tmp1 
                    - pow( 17.0, I_R1 ) * pow( -1.0, I_Lge1 ) * tmp2 );
             // printf("  i exact: weight = %lf \n", weight);
          }
          gamma[i] = gamma[i] + rate[i] * weight;
        }
  
        // ...lambda_{i+1} to lambda_{k-1}
        for( m = i+1;m<=k-1;m++)
        {
           if (k > kexact) 
           {
              m_tilde = m + I_L2;
              weight = const1 * pow(-1.0, m-i-1) * 8
                * (   pow(17.0, I_R1+ I_L1) / p3[m_tilde - i_tilde + 1]
                +  pow(17.0, I_R1) * pow(-1.0, I_Lge1) 
                    / ( p3[i_tilde] * p3[m_tilde-1] )
                - pow(17.0, I_L1) * pow(-1.0, I_Rge1) 
                    / ( p3[k_ring-i_tilde] * p3[k_ring-m_tilde+1] ) );
              // if(i==1) printf(" m approx: m, k,weight = %d %d %lf \n", m, k, weight);
           } else {
              tmp1 =   pow( 17.0, I_L1 )   * p3[i_tilde-1]
                     + pow( -1.0, I_Lge1 ) / p3[i_tilde-1];
              tmp2 =   pow( 17.0, I_R1 )   * p3[k - m - 1 + I_R2] 
                     - pow( -1.0, I_Rge1 ) / p3[k - m + 1 + I_R2];
              weight = const1 * eight * pow(-1.0, m-i-1) * tmp1 * tmp2;
              // printf("  i+1--k-1 exact: weight = %lf \n", weight);
           }
           gamma[i] = gamma[i] + rate[m] * weight;
        }
    
        // ...lambda_k = rate(k)
        if (k > kexact) 
        {
           weight = const1 * pow(-1.0, k-i) * pow(17.0, I_L1) 
                  * ( 1 - (third + threef*I_Rge1 + fourth*I_R2) * I_k )   
                  * ( pow( 17.0, I_R1 ) * pow( 3.0, I_R2 )
                  * ( 1- (three + threef*I_Rge1 + fourth*I_R2) * (1 - I_k) )
               + pow( -1.0, I_Rge1 )
                  * ( 1 - (third + threef*I_Rge1 + fourth*I_R2) *(1 - I_k) ) 
                  / pow( 3.0, I_R2 )  ) / pow( 3.0, k_ring - i_tilde );
           // if(i==1) printf("  k approx: k, weight = %d %lf\n",k,weight);
        }
        else
        {
           weight = const1 * pow( -1.0, k-i ) 

             * (      pow( 17.0, I_L1 ) * p3[i_tilde-1]
                * ( 1 - (third + threef*I_Rge1 + fourth*I_R2) * I_k )      
                      + pow( -1.0, I_Lge1 )
                * ( 1 - (three + threef*I_Rge1 + fourth*I_R2) * I_k ) 
                                     / p3[i_tilde-1]                  )
            
             * (      pow( 17.0, I_R1 ) * pow( 3.0, I_R2 )
                * ( 1 - (three + threef*I_Rge1 + fourth*I_R2)*(1-I_k) ) 
                      + pow( -1.0, I_Rge1 )
                * ( 1 - (third + threef*I_Rge1 + fourth*I_R2)*(1-I_k) ) 
                                     / pow( 3.0, I_R2 )               );
           // printf("  k exact: weight = %lf\n",weight);
        }
        gamma[i] = gamma[i] + rate[k] * weight ;
        
        // ...lambda_{k+1} = frate(3), the inner-right fixed rate
        if (k > kexact) {
           weight = const1 * pow(-1.0, k-i) * pow(17.0, I_L1) 
               * (threef * I_Rge1+half*I_R2) * ( pow(17.0, I_R1)
               * pow(3.0,I_R2) + pow(-1.0, I_Rge1) / pow(3.0,I_R2) )
                         / pow(3.0,k_ring - i_tilde);
           // if(i==1) printf("  k+1 approx: k, weight = %d %lf\n",k,weight);
        }
        else
        {
           weight = const1 * (threef*I_Rge1+half*I_R2) * pow(-1.0, k-i) 
               * (   pow( 17.0, I_L1   ) * p3[i_tilde-1] 
                   + pow( -1.0, I_Lge1 ) / p3[i_tilde-1]      )
               * (   pow( 17.0, I_R1   ) * pow( 3.0, I_R2 ) 
                    + pow( -1.0, I_Rge1 ) / pow( 3.0, I_R2 )   );
           // printf("  k+1 exact: weight = %lf\n", weight);
        }
        gamma[i] = gamma[i] + frate[3] * weight;
        
        // ...lambda_{k+2} = frate(4), the outer-right fixed rate
        if (k > kexact)
        {
           weight = const1 * two * I_R2 * pow( -1.0, k-i-1 ) 
                     * pow( 17.0, I_L1 ) / p3[k_ring - i_tilde+1];
           // if(i==1) printf("  k+2 approx: k, weight = %d %lf\n", k, weight);
        }
        else
        {
           if (i_tilde < 2) 
           {
              tmp1 = pow( 17.0, I_L1 ) / p3[2 - i_tilde];
           }
           else
           {
              tmp1 = pow( 17.0, I_L1 ) * p3[i_tilde - 2];
           }
           tmp2 = pow( -1.0, I_Lge1 ) / p3[i_tilde];
           weight = const1 * two * I_R2 * pow( -1.0, k-i-1 )*(tmp1+tmp2);
           // printf("  k+2 exact: weight = %lf\n",weight);
        }
        gamma[i] = gamma[i] + frate[4] * weight;
       
      }
      free(p3);
      return;
}


void  csmooth(int k,double *rate, double *gamma )
/***********************************************************************
*     huifen chen and bruce schmeiser, may 14, 2011.
*     purpose: compute the optimal gamma values for the cyclic 
*              context, ignoring the nonnegativity constraints.
*     input:  k     = dimension of gamma
*             rate  = vector of initial rates
*     output: gamma = optimal gamma vector 
************************************************************************/
{
      int    kexact, i, j, ipj, imj;
      double weight, const1, power1, power2;

      kexact=100;

      printf("\n   ...beginning csmooth\n");
     
      if (k <= kexact) 
      {
         // ...exact formula
         power1 =pow((-3.0),(k-2));
         power2 = 1.0;
         const1  = 2.0 / ( 9.0 * power1 - power2 );
      }
      else
      {
         // ...approximation to avoid overflow when k is large
         power1 = 1.0;
         power2 = 0.0;
         const1  = 2.0 / 9.0;
      }
      
      for(i=1;i<=k;i++)
      {
         gamma[i] = 0.0;
      }
      
      for(j = 1;j<=(int)((k-1)/2);j++)
      {
         weight = const1 * ( power1 - power2 );
         for( i = 1;i<=k;i++)
         {
            ipj = i + j;
            imj = i - j;
            if (ipj > k) ipj = ipj - k;
            if (imj < 1) imj = imj + k;
            gamma[i] = gamma[i] + weight * ( rate[ipj] - rate[imj]);
         }
         power1 = power1 / (-3.0);
         power2 = power2 * (-3.0);
      }
      return;
}


double objfunc(int k,double *rate,int *ifinite,double *frate,double *gamma )
/***********************************************************
*     huifen chen and bruce schmeiser, may 14, 2011.
*     purpose: compute the objective-function value
*     input:  ifinite  = 1 if finite horizon, 0 if cyclic
*             k        = dimension of gamma
*             rate     = vector of initial rates
*             frate    = four fixed rates, left to right
*             gamma    = vector of rate increments
*     output: objfunc1 = objective-function value
************************************************************/
{
      int    i;
      double tmp1, tmp2, objfunc1;

      objfunc1 = 0.0;
      for(i = 1;i<=k-1;i++)
      {
         tmp1     = rate[i] - rate[i+1] + 3.0*gamma[i] + gamma[i+1];
         tmp2     = rate[i] - rate[i+1] + gamma[i] + 3.0*gamma[i+1];
         objfunc1 = objfunc1 + pow(tmp1,2) + pow(tmp2,2);
      }
      
      if (*ifinite == 0)
      {
         // ...cyclic context
         tmp1     = rate[k] - rate[1] + 3.0*gamma[k] + gamma[1];
         tmp2     = rate[k] - rate[1] + gamma[k] + 3.0*gamma[1];
         objfunc1 = objfunc1 + pow(tmp1,2) + pow(tmp2,2);
      }
      else
      {
         // ...finite-horizon context (left- and right-side fixed rates)
         if (frate[2] >= 0.0) 
         {
            tmp1     = frate[2] - rate[1] + 3.0*gamma[1];
            objfunc1 = objfunc1 + pow(tmp1,2);
            if (frate[1] >= 0.0)
            {
               tmp2     = -frate[1] + 2.0*frate[2] - rate[1] + gamma[1];
               objfunc1 = objfunc1 + pow(tmp2,2);
            }
         }
         
         if (frate[3] >= 0.0)
         {
            tmp1     = rate[k] - frate[3] + 3.0*gamma[k];
            objfunc1 = objfunc1 + pow(tmp1,2);
            if (frate[4] >= 0.0)
            {
               tmp2     = rate[k] - 2.0*frate[3] + frate[4] + gamma[k];
               objfunc1 = objfunc1 + pow(tmp2,2);
            }
         }
      }
      return objfunc1;
}


void pushup1(int k,double *rate,double *gamma,int *ipush )
/***************************************************************
*     huifen chen and bruce schmeiser, may 12, 2011.
*     purpose: push the most-negative rate up to zero.
*     input:  k, the number of time intervals.
*             rate: vector of rates
*             gamma: vector of rate shifts
*     output: gamma: updated gamma vector
*             ipush: index of the pushed gamma value, 0 if none
****************************************************************/
{
      int    ilock, i;
      double ratemin, rmag;

      printf("   ...beginning pushup\n");
      ratemin = 0.0;
      *ipush   = 0;
      for( i = 1;i<=k;i++)
      {
         rmag = rate[i] - fabs(gamma[i]);
         if (rmag < ratemin) 
         {
            ratemin = rmag;
            *ipush   = i;
            printf(" ratemin=%lf, ipush = %d \n", ratemin, *ipush);
         }
      }
      
      // ...push the most-negative rate, if any, to zero
      if (*ipush > 0)
      {
         if (gamma[*ipush] < 0.0)
         {
            gamma[*ipush] = - rate[*ipush];
         }
         else
         {
            gamma[*ipush] = rate[*ipush];
         }
      }
      /*
      printf("                                   ipush = %d \n", *ipush);
      if(*ipush > 0) printf("          gamma(ipush) = %lf \n", gamma[*ipush]);
      */
      return;
}


void pushup2(int k,double *rate,int *ifinite,double *frate,
             double *gamma,int *ipush)
/***************************************************************
*     huifen chen and bruce schmeiser, may 14, 2011.
*     purpose: push a negative new rate up to zero.
*              choose the rate that provides the 
*              smallest objective-function value.
*     input:  k, the number of time intervals.
*             rate: vector of rates
*             ifinite: 1 if finite horizon, 0 if cyclic
*             frate: fixed rates
*             gamma: vector of rate shifts
*     output: gamma: updated gamma vector
*             ipush: index of the pushed gamma value, 0 if none
****************************************************************/
{
      int    ilock, i;
      double saveg, obj, objmin, bestg;

      objmin = 0.0;
      bestg  = 0.0;
      saveg  = 0.0;
      obj    = 0.0;

      printf("   ...beginning pushup\n");

      // ...if any, find the potential negative new rate to push up
      *ipush = 0;
      for(i = 1;i<= k;i++)
      {
         // ...check the ith interval
         if (rate[i] - fabs(gamma[i] ) < 0.0)
         {
            // ...the ith new rate would be negative
            saveg = gamma[i];
            if (gamma[i] < 0.0)
            {
               gamma[i] = -rate[i];
            }
            else
            {
               gamma[i] = rate[i];
            }
            obj = objfunc( k, rate, ifinite, frate, gamma );
            if (*ipush == 0) objmin = obj - 1.0;
            if (obj > objmin) 
            {
               // ...looking for the interval with the largest obj
               objmin = obj;
               bestg  = gamma[i];
               *ipush = i;
            }
            gamma[i] = saveg;
         }
      }
      if (*ipush > 0) gamma[*ipush] = bestg;
      return;
}



